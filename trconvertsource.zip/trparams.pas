unit trparams;

interface

uses AutoFormat;

const cHelp : array [0..29] of String =
('Trace converter version 1.00 usage examples (see help.txt for more details):',
'trconvert trace_filename',
'   e.g. trconvert out.tr',
'trconvert trace_filename output_filename -mixed13 -hex -ip',
'   e.g. trconvert out.tr outconv.tr -mixed13 -hex -ip',
'trconvert trace_filename -ip',
'   e.g. trconvert out.tr -ip',
'trconvert trace_filename -ip IPs_with_node_numbers_filename',
'   e.g. trconvert out.tr -ip iptonode.ip',
'trconvert trace_filename_mask -batch',
'   e.g. trconvert *out*.tr -batch',
'trconvert trace_filename_mask -batch -ip',
'   e.g. trconvert *out*.tr -batch -ip',
'available parameters (case insensitive):',
'   -batch   batch conversion for all the trace files matching the filename mask',
'   -ip      extracts IP addresses from the trace file if IP file doesn''t exist',
'            otherwise forces IP addresses to node numbers conversion',
'   -ip FN   extracts IP addresses from the trace file if FN file doesn''t exist',
'            otherwise forces IP addresses to node numbers conversion using FN',
'            file containing node numbers to IP addresses assignements',
'   -hex     forces hexadecimal to decimal node numbers conversion',
'   -mixed12 forces wired-old wireless format to Trace graph format conversion',
'   -mixed13 forces wired-new trace format to Trace graph format conversion',
'   -old     forces old wireless format to Trace graph format conversion',
'   -new     forces new trace format to Trace graph format conversion',
'   -max X   maximum number of the beggining trace file lines to parse for',
'            automatic trace file format recognition (default 10000),',
'            e.g. trconvert out.tr -max 50000',
'Copyright (c) 2005 by Jaroslaw Malek, jaroslaw_malek@interia.pl; wido@o2.pl',
'http://www.tracegraph.com/traceconverter.html');

ETraceFormat = 'Invalid trace format parameters';

procedure ProcessTrace;

implementation

uses SysUtils, Classes, ipconversion, TraceParsing;

//checks commmand line parameters
function CommandLineParameters(var TraceFileName, OutPutFileName, IPFileName : String;
  var TraceFormat : TTraceFormat; var HEX, IP, BATCH : Boolean; var MaxLineNr : Integer) : Boolean;
var i : Integer;
    tmpStr : String;
begin
  Result := False;
  try
    if ParamCount < 1 then
      Raise Exception.Create('Wrong number of parameters');
    IP := False;
    HEX := False;
    BATCH := False;
    TraceFormat := trfNone;
    MaxLineNr := 10000;
    TraceFileName := ParamStr(1);
    OutPutFileName := '';
    IPFileName := '';
    i := 2;
    while i <= ParamCount do
    begin
      tmpStr := LowerCase(ParamStr(i));
      if tmpStr = '-ip' then
      begin
        Inc(i);
        if i > ParamCount then Break;
        IP := True;
        tmpStr := LowerCase(ParamStr(i));
        if (tmpStr <> '-batch') and (tmpStr <> '-hex') and (tmpStr <> '-max')
        and (tmpStr <> '-old') and (tmpStr <> '-new') and (tmpStr <> '-mixed12')
        and (tmpStr <> '-mixed13')
        then
        begin
          IPFileName := ParamStr(i);
          Inc(i);
          Continue;
        end;
      end;  
      if tmpStr = '-batch'
      then BATCH := True
      else if tmpStr = '-hex'
      then HEX := True
      else if tmpStr = '-max'
      then begin
             Inc(i);
             try
               MaxLineNr := StrToInt(ParamStr(i));
             except
               Raise Exception.Create('Invalid maximum number of the beggining trace file lines: ' + ParamStr(i));
             end;
           end
      else if tmpStr = '-old'
      then
        if TraceFormat=trfNone
        then TraceFormat := trfOldWireless
        else Raise Exception.Create(ETraceFormat)
      else if tmpStr = '-new'
      then
        if TraceFormat=trfNone
        then TraceFormat := trfNewTrace
        else Raise Exception.Create(ETraceFormat)
      else if tmpStr = '-mixed12'
      then
        if TraceFormat=trfNone
        then TraceFormat := trfWiredOldWireless
        else Raise Exception.Create(ETraceFormat)
      else if tmpStr = '-mixed13'
      then
        if TraceFormat=trfNone
        then TraceFormat := trfWiredNewTrace
        else Raise Exception.Create(ETraceFormat)
      else if i = 2
      then
        OutPutFileName := ParamStr(i)
      else
        Raise Exception.Create('Unrecognized option');
      Inc(i);
    end;
    if (OutPutFileName <> '') and BATCH and not IP
    then
      Raise Exception.Create('output_filename cannot be used with -batch option')
    else if (OutPutFileName = '') and not BATCH
    then OutPutFileName := ChangeFileExt(TraceFileName, '_tg.tr');
    Result := True;
  except
    on E : Exception do
      writeln('Invalid command line parameters: ' + E.Message);
  end;
end;

procedure ProcessTrace;
var TraceFileName, OutPutFileName, IPFileName, tmpFileDir, tmpFileCount : String;
    TraceFormat, tmpTraceFormat : TTraceFormat;
    HEX, IP, BATCH, HexAuto, IPAuto : Boolean;
    MaxLineNr, i, FileCount : Integer;
    sr : TSearchRec;
    FileList : TStringList;

  procedure ConvertFile;
  var OK : Boolean;
  begin
    if TraceFormat=trfNone then
    begin
      writeln('Trying to recognize format of ' + TraceFileName + ' trace file...');
      if not GetTraceFormat(TraceFileName, TraceFormat, HEX, IP, MaxLineNr)
      or (TraceFormat = trfNone) or (TraceFormat=trfWired) or (TraceFormat=trfTracegraph)
      then Exit;
    end;
    if HexAuto then HEX := True;
    if IPAuto then IP := True;
    OK := False;
    writeln('Converting ' + TraceFileName + ' trace file...');
    case TraceFormat of
      trfOldWireless      : if IP
                            then
                              OK := IPConvertOldWireless(TraceFileName, OutPutFileName, HEX, IPFileName)
                            else
                              OK := ConvertOldWireless(TraceFileName, OutPutFileName, HEX);
      trfNewTrace         : if IP
                            then
                              OK := IPConvertNewTrace(TraceFileName, OutPutFileName, HEX, IPFileName)
                            else
                              OK := ConvertNewTrace(TraceFileName, OutPutFileName, HEX);
      trfWiredOldWireless : if IP
                            then
                              OK := IPConvertWiredOldWireless(TraceFileName, OutPutFileName, HEX, IPFileName)
                            else
                              OK := ConvertWiredOldWireless(TraceFileName, OutPutFileName, HEX);
      trfWiredNewTrace    : if IP
                            then
                              OK := IPConvertWiredNewTrace(TraceFileName, OutPutFileName, HEX, IPFileName)
                            else
                              OK := ConvertWiredNewTrace(TraceFileName, OutPutFileName, HEX);
    end;
    if OK
    then
      writeln(TraceFileName + ' has been converted to ' + OutPutFileName)
    else
      writeln(TraceFileName + ' has not been converted.');
  end;

begin
  if ParamCount = 0 then
  begin
    for i := 0 to High(cHelp) do
      writeln(cHelp[i]);
    Exit;
  end;
  BATCH := False;
  if not CommandLineParameters(TraceFileName, OutPutFileName, IPFileName,
    TraceFormat, HexAuto, IPAuto, BATCH, MaxLineNr) then Exit;
  if not BATCH
  then ConvertFile
  else try
         writeln('Creating trace files list...');
         tmpTraceFormat := TraceFormat;
         tmpFileDir := ExtractFileDir(TraceFileName);
         FileList := TStringList.Create;
         try
           if FindFirst(TraceFileName, faAnyFile, sr) = 0
           then
             repeat
               FileList.Append(tmpFileDir + sr.Name);
             until FindNext(sr) <> 0
           else begin
                  writeln('There are no trace files matching ' + TraceFileName + ' mask.');
                  Exit;
                end;  
           FindClose(sr);
           FileCount := FileList.Count;
           tmpFileCount := IntToStr(FileCount);  
           for i := 0 to FileCount - 1 do
           begin
             writeln('File ' + IntToStr(i+1) + '/' + tmpFileCount);
             TraceFileName := FileList[i];
             OutPutFileName := ChangeFileExt(TraceFileName, '_tg.tr');
             if tmpTraceFormat <> trfNone
             then TraceFormat := tmpTraceFormat
             else TraceFormat := trfNone;
             ConvertFile;
           end;
         finally
           FindClose(sr);
           FileList.Free;
         end;
       except
         on E : Exception do
           writeln('Error processing batch: ' + E.Message);
       end;
end;

end.
