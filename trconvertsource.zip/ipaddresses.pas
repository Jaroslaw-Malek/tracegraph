unit ipaddresses;

interface

uses
  Classes, SysUtils;

procedure GetOldWirelessIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');
procedure GetNewTraceIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');
procedure GetWiredOldWirelessIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');
procedure GetWiredNewTraceIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');

implementation

uses trglobal;

procedure RemoveNodeNumbers(IPList : TStringList; const TraceFileName,
  IPFileName : String);
var i, j, dotcount : Integer;
    tmpStr : String;
    tmpList : TStringList;
begin
  tmpList := TStringList.Create;
  try
    tmpList.Duplicates := dupIgnore;
    tmpList.CaseSensitive := True;
    tmpList.Sorted := False; //FreePascal bug Sorted na koncu musi byc ustawione
    for i := 0 to IPList.Count - 1 do
    begin
      tmpStr := IPList[i];
      dotcount := 0;
      if length(tmpStr)<7 then //99.255
        for j := 0 to length(tmpStr) do
          if tmpStr[j]='.' then Inc(dotcount);
      if dotcount <> 1 then //is IP
      begin
        j := length(tmpStr);
        while (j > 0) and (tmpStr[j]<>':') and (tmpStr[j]<>'.') do
          Dec(j);
        if j > 0 then
          Delete(tmpStr, j, length(tmpStr));
        with tmpList do if not Find(tmpStr, j) then
          Insert(j, tmpStr);
      end;
    end;
    IPList.Assign(tmpList);
    if IPList.Count > 0
    then
    begin
      IPList.SaveToFile(IPFileName);
      writeln('IP addresses have been saved to ' + IPFileName);
      writeln('IP addresses to node numbers manual conversion is needed (see help).');
    end
    else writeln(TraceFileName + ' contains no IP addresses.');
  finally tmpList.Free;
  end;    
end;

procedure GetOldWirelessIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');
var InputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, tmp, sppos : Integer;
    event : Char;
    HasSlash : Boolean;
    sp : array of Integer;
    newIP : String;

  procedure addIP(const startpos, endpos : Integer);
  var j : Integer;
  begin
    if (Buf[startpos]='-') or (Buf[startpos+1]=':') or (Buf[startpos+2]=':') then Exit; //-1.0, 0:x, .. 99:x
    tmp := 1;
    SetLength(newIP, endpos-startpos+1);
    for j := startpos to endpos do
    begin
      newIP[tmp] := Buf[j];
      Inc(tmp);      
    end;
    with IPList do if not Find(newIP, tmp) then
      Insert(tmp, newIP);  
  end;

begin
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    if OutPutFileName = '' then
      OutPutFileName := TraceFileName + '.ip';
    IPList.Clear;
    IPList.Duplicates := dupAccept;
    IPList.CaseSensitive := True;
    IPList.Sorted := False;
    SetLength(sp, spSize);
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          event := Buf[i];
          if (Buf[i+1]=#32) and ((event='s') or (event='r') or (event='f') or (event='D'))
          then
          begin
            sppos := 0; //number of spaces in the line
            HasSlash := False;
            while (i <= tmppos) and (Buf[i]<>#10) do
            begin
              if Buf[i]=#32
              then
              begin
                Inc(sppos);
                sp[sppos] := i;
              end
              else if not HasSlash and (Buf[i]='/')
              then
                HasSlash := True;
              Inc(i);
            end;
            if not HasSlash and (sppos>15) then
            begin
              if sp[4]<>(sp[5]-1) then // if there are 2 spaces between columns c4 and c5
              begin
                for tmp := sppos downto 1 do
                  sp[tmp+1] := sp[tmp];
                sp[1] := 1;
              end;
              if Buf[sp[14]+1]='['
              then begin
                     addIP(sp[14]+2,sp[15]-1);
                     addIP(sp[15]+1,sp[16]-1);
                     if sp[18]-2-sp[17] > FWDLENGTH then
                       addIP(sp[17]+1,sp[18]-2);
                   end
              else begin
                     addIP(sp[15]+2,sp[16]-1);
                     addIP(sp[16]+1,sp[17]-1);
                     if sp[19]-2-sp[18] > FWDLENGTH then
                       addIP(sp[18]+1,sp[19]-2);
                   end;
            end;  
          end
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      RemoveNodeNumbers(IPList, TraceFileName, OutputFileName);
    finally
      sp := nil;
      InputStream.Free;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;

procedure GetNewTraceIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');
var InputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, tmp, endpos,
    posIs, posId, posHd : Integer;
    event : Char;
    newIP : String;

  procedure NTaddIP(const startpos : Integer; const stopchar : Char);
  var j : Integer;
  begin
    if (Buf[startpos]='-') then Exit; //-1.0, 0:x, .. 9:x
    endpos := startpos;
    while Buf[endpos]<>stopchar do Inc(endpos);
    SetLength(newIP, endpos-startpos);
    Dec(endpos);
    tmp := 1;
    for j := startpos to endpos do
    begin
      newIP[tmp] := Buf[j];
      Inc(tmp);      
    end;
    with IPList do if not Find(newIP, tmp) then
      Insert(tmp, newIP);  
  end;

  procedure NTaddIPfwd;
  var j : Integer;
  begin
    if (Buf[posHd]='-') or (Buf[posHd+1]=':') or (Buf[posHd+2]=':') then Exit; //-1.0, 0:x, .. 9:x
    endpos := posHd;
    while Buf[endpos]<>#32 do Inc(endpos);
    tmp := endpos-posHd;
    if tmp>FWDLENGTH then
    begin
      SetLength(newIP, endpos-posHd);
      Dec(endpos);
      tmp := 1;
      for j := posHd to endpos do
      begin
        newIP[tmp] := Buf[j];
        Inc(tmp);
      end;
      with IPList do if not Find(newIP, tmp) then
        Insert(tmp, newIP);
    end;    
  end;

begin
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    if OutPutFileName = '' then
      OutPutFileName := TraceFileName + '.ip';
    IPList.Clear;
    IPList.Duplicates := dupAccept;
    IPList.CaseSensitive := True;
    IPList.Sorted := False;
    posId := 0;
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          event := Buf[i];
          if (Buf[i+1]=#32) and ((event='s') or (event='r') or (event='f') or (event='d'))
          then
          begin
            Inc(i,2);
            posIs := 0;
            while (i <= tmppos) and (Buf[i]<>#10) do
            begin
              if Buf[i]='-'
              then
              begin
                Inc(i);
                case Buf[i] of
                  'I' : begin
                          Inc(i);
                          case Buf[i] of
                            's' : begin
                                    Inc(i,2);
                                    posIs := i;
                                  end;
                            'd' : begin
                                    Inc(i,2);
                                    posId := i;
                                  end;
                          end;
                        end;
                  'H' : begin
                          Inc(i);
                          if Buf[i]='d' then
                          begin
                            Inc(i,2);
                            posHd := i;
                          end;
                        end;
                end;
              end  
              else
                Inc(i);                
            end;
            if posIs > 0 then
            begin
              NTaddIP(posIs,#32);
              NTaddIP(posId,#32);
              NTaddIPfwd;
            end;
          end
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      RemoveNodeNumbers(IPList, TraceFileName, OutputFileName);
    finally InputStream.Free;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;

procedure GetWiredOldWirelessIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');
var InputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, tmp, sppos : Integer;
    event : Char;
    HasSlash, IsWireless : Boolean;
    sp : array of Integer;
    newIP : String;

  procedure addIP(const startpos, endpos : Integer);
  var j : Integer;
  begin
    if (Buf[startpos]='-') or (Buf[startpos+1]=':') or (Buf[startpos+2]=':') then Exit; //-1.0, 0:x, .. 99:x
    tmp := 1;
    SetLength(newIP, endpos-startpos+1);
    for j := startpos to endpos do
    begin
      newIP[tmp] := Buf[j];
      Inc(tmp);      
    end;
    with IPList do if not Find(newIP, tmp) then
      Insert(tmp, newIP);
  end;

begin
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    if OutPutFileName = '' then
      OutPutFileName := TraceFileName + '.ip';
    IPList.Clear;
    IPList.Duplicates := dupAccept;
    IPList.CaseSensitive := True;
    IPList.Sorted := False;
    SetLength(sp, spSize);
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          event := Buf[i];
          if Buf[i+1]=#32
          then
          begin
            sppos := 0; //number of spaces in the line
            HasSlash := False;
            IsWireless := False;
            while (i <= tmppos) and (Buf[i]<>#10) do
            begin
              case Buf[i] of
                #32 : begin
                        Inc(sppos);
                        sp[sppos] := i;
                      end;
                '[' : IsWireless := True;
                else if not HasSlash and (Buf[i]='/')
                then
                  HasSlash := True;
              end;
              Inc(i);
            end;
            if IsWireless
            then
            begin
              if not HasSlash and (sppos>15) and
              ((event='s') or (event='r') or (event='f') or (event='D')) then
              begin
                if sp[4]<>(sp[5]-1) then // if there are 2 spaces between columns c4 and c5
                begin
                  for tmp := sppos downto 1 do
                    sp[tmp+1] := sp[tmp];
                  sp[1] := 1;
                end;
                if Buf[sp[14]+1]='['
                then begin
                       addIP(sp[14]+2,sp[15]-1);
                       addIP(sp[15]+1,sp[16]-1);
                       if sp[18]-2-sp[17] > FWDLENGTH then
                         addIP(sp[17]+1,sp[18]-2);
                     end
                else begin
                       addIP(sp[15]+2,sp[16]-1);
                       addIP(sp[16]+1,sp[17]-1);
                       if sp[19]-2-sp[18] > FWDLENGTH then
                         addIP(sp[18]+1,sp[19]-2);
                     end;
              end;
            end
            else if ((sppos=11) or (sppos=15)) and
                    ((event='+') or (event='-') or (event='r') or  (event='d')) //if wired
            then        
            begin
              addIP(sp[8]+1,sp[9]-1);
              addIP(sp[9]+1,sp[10]-1);
            end
            else
            begin//move to the next line
              while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
              Inc(i);
            end;
          end
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      RemoveNodeNumbers(IPList, TraceFileName, OutputFileName);
    finally
      sp := nil;
      InputStream.Free;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;

procedure GetWiredNewTraceIP(const TraceFileName : String; IPList : TStringList;
  OutPutFileName : String = '');
var InputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, tmp, endpos,
    posIs, posId, posHd, sppos : Integer;
    event : Char;
    newIP : String;
    sp : array of Integer;

  procedure NTaddIP(const startpos : Integer; const stopchar : Char);
  var j : Integer;
  begin
    if (Buf[startpos]='-') then Exit; //-1.0, 0:x, .. 9:x
    endpos := startpos;
    while Buf[endpos]<>stopchar do Inc(endpos);
    tmp := endpos-startpos;
    if tmp <> length(newIP) then
      SetLength(newIP, tmp);
    Dec(endpos);
    tmp := 1;
    for j := startpos to endpos do
    begin
      newIP[tmp] := Buf[j];
      Inc(tmp);
    end;
    with IPList do if not Find(newIP, tmp) then
      Insert(tmp, newIP);
  end;

  procedure NTaddIPfwd;
  var j : Integer;
  begin
    if (Buf[posHd]='-') or (Buf[posHd+1]=':') or (Buf[posHd+2]=':') then Exit; //-1.0, 0:x, .. 9:x
    endpos := posHd;
    while Buf[endpos]<>#32 do Inc(endpos);
    tmp := endpos-posHd;
    if tmp>FWDLENGTH then
    begin
      tmp := endpos-posHd;
      if tmp <> length(newIP) then
        SetLength(newIP, tmp);
      Dec(endpos);
      tmp := 1;
      for j := posHd to endpos do
      begin
        newIP[tmp] := Buf[j];
        Inc(tmp);
      end;
      with IPList do if not Find(newIP, tmp) then
        Insert(tmp, newIP);
    end;
  end;

  //wired
  procedure addIP(const startpos, endpos : Integer);
  var j : Integer;
  begin
    if (Buf[startpos]='-') or (Buf[startpos+1]=':') or (Buf[startpos+2]=':') then Exit; //-1.0, 0:x, .. 99:x
    tmp := endpos-startpos+1;
    if tmp <> length(newIP) then
      SetLength(newIP, tmp);
    tmp := 1;
    for j := startpos to endpos do
    begin
      newIP[tmp] := Buf[j];
      Inc(tmp);
    end;
    with IPList do if not Find(newIP, tmp) then
      Insert(tmp, newIP);
  end;

begin
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    if OutPutFileName = '' then
      OutPutFileName := TraceFileName + '.ip';
    IPList.Clear;
    IPList.Duplicates := dupAccept;
    IPList.CaseSensitive := True;
    IPList.Sorted := False;
    posId := 0;
    SetLength(sp, spSize);    
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          if Buf[i+1]=#32
          then
          begin
            event := Buf[i];
            if (Buf[i+2]='-') and (Buf[i+3]='t') //new trace
            then
            begin
              if (event='s') or (event='r') or (event='f') or (event='d')
              then
              begin
                Inc(i,5);
                posIs := 0;
                while (i <= tmppos) and (Buf[i]<>#10) do
                begin
                  if Buf[i]='-'
                  then
                  begin
                    Inc(i);
                    case Buf[i] of
                      'I' : begin
                              Inc(i);
                              case Buf[i] of
                                's' : begin
                                        Inc(i,2);
                                        posIs := i;
                                      end;
                                'd' : begin
                                        Inc(i,2);
                                        posId := i;
                                      end;
                              end;
                            end;
                      'H' : begin
                              Inc(i);
                              if Buf[i]='d' then
                              begin
                                Inc(i,2);
                                posHd := i;
                              end;
                            end;
                    end;
                  end  
                  else
                    Inc(i);
                end;
                if posIs > 0 then
                begin
                  NTaddIP(posIs,#32);
                  NTaddIP(posId,#32);
                  NTaddIPfwd;
                end;
              end //if (event='s') or (event='r') or (event='f') or (event='d')
              else
              begin//move to the next line
                while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
                Inc(i);
              end;
            end //if (Buf[i+2]='-') and (Buf[i+3]='t') //new trace
            else if (event='+') or (event='-') or (event='r') or  (event='d') //if wired
            then
            begin
              sppos := 0; //number of spaces in the line
              while (i <= tmppos) and (Buf[i]<>#10) do
              begin
                if Buf[i]=#32 then
                begin
                  Inc(sppos);
                  sp[sppos] := i;
                end;
                Inc(i);
              end;
              if (sppos=11) or (sppos=15) then
              begin
                addIP(sp[8]+1,sp[9]-1);
                addIP(sp[9]+1,sp[10]-1);
              end;
            end
            else
            begin//move to the next line
              while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
              Inc(i);
            end;
          end //if Buf[i+1]=#32
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      RemoveNodeNumbers(IPList, TraceFileName, OutputFileName);
    finally
      InputStream.Free;
      sp := nil;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;

end.
