unit AutoFormat;

interface

type

  TTraceFormat =
    (trfNone, trfWired, trfOldWireless, trfNewTrace, trfWiredOldWireless, trfWiredNewTrace, trfTracegraph);


function GetTraceFormat(const TraceFileName : String; var TraceFormat : TTraceFormat;
  var HEX, IP : Boolean; const MaxLineNr : Integer = 10000) : Boolean;

implementation

uses Classes, SysUtils, trglobal;

const minip=4; // minimum node number length to take it as a part of IP address
      lkrop=5; // number of dots for IP

function GetTraceFormat(const TraceFileName : String; var TraceFormat : TTraceFormat;
  var HEX, IP : Boolean; const MaxLineNr : Integer = 10000) : Boolean;
var InputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, tmp, sppos, sp1pos, dotcount, LeftBracketCount, linecount,
    post, posIs, posId, posMs : Integer;
    event : Char;
    wired, bez, nowy, tg, koniec, HasSlash, Underline : Boolean;
    sp, sp1 : array of Integer;

  function NewTraceDotCount(const startpos : Integer) : Integer;
  begin
    Result := 0;
    tmp := startpos;
    while Buf[tmp]<>#32 do
    begin
      if Buf[tmp]='.' then Inc(Result);
      Inc(tmp);
    end;
  end;

  function NewTraceTagLen(const startpos : Integer) : Integer;
  begin
    tmp := startpos;
    while Buf[tmp]<>#46 do
      Inc(tmp);
    Result := tmp - startpos;
  end;

begin
  Result := False;
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    SetLength(sp, spSize);
    SetLength(sp1, spSize);
    linecount := 0;
    IP := False;
    HEX := False;
    wired := False;
    bez := False;
    nowy := False;
    tg := False;
    koniec := False;
    TraceFormat := trfNone;
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          if Buf[i+1]=#32
          then
          begin
            event := Buf[i];
            sppos := 0; //number of spaces in the line
            sp1pos := 0; //number of colons in the line
            dotcount := 0;
            LeftBracketCount := 0; //number of '['
            HasSlash := False; //'/'
            Underline := False; //'_'
            post := 0; //-t
            posIs := 0; //-Is
            posId := 0; //-Id
            posMs := 0; //-Ms
            Inc(i);
            while (i <= tmppos) and (Buf[i]<>#10) do
            begin
              case Buf[i] of
                #32 : begin
                        Inc(sppos);
                        sp[sppos] := i;
                      end;
                ':' : begin
                        Inc(sp1pos);
                        sp1[sp1pos] := i;
                      end;
                '.' : Inc(dotcount);
                '[' : Inc(LeftBracketCount);
                '/' : HasSlash := True;
                '_' : Underline := True;
                '-' : begin
                        case Buf[i+1] of
                          't' : begin
                                  Inc(i,3);
                                  post := i;
                                end;
                          'I' : begin
                                  Inc(i,2);
                                  case Buf[i] of
                                    's' : begin
                                            Inc(i,2);
                                            posIs := i;
                                          end;
                                    'd' : begin
                                            Inc(i,2);
                                            posId := i;
                                          end;
                                  end;
                                end;  
                          'M' : begin
                                  Inc(i,2);
                                  if Buf[i]='s' then
                                  begin
                                    Inc(i,2);
                                    posMs := i;
                                  end;
                                end;
                        end;
                      end;
              end;
              Inc(i);
            end;
            if (event='+') or (event='-') // wired
            then
            begin
              wired := True;
              if dotcount>lkrop then
                IP := True;
              if HEX and (bez or nowy) and IP then //1.01 "and IP"
                koniec := True;
            end
            else if (LeftBracketCount > 1) and
                    ((event='r') or (event='s') or (event='f') or (event='D')) //wireless
            then
            begin
              bez := True;
              if (wired and HEX) and IP then //1.01 "and IP"
                koniec := True;
              if sp[4]<>(sp[5]-1) then // if there are 2 spaces between columns c4 and c5
              begin
                for tmp := sppos downto 1 do
                  sp[tmp+1] := sp[tmp];
                sp[1] := 1;
                Inc(sppos);
              end;
              if not HEX then
              begin
                tmp := sp[11]+1;
                while (Buf[tmp]<>#32) and (Buf[tmp]<>']') do
                begin
                  if Buf[tmp] in ['a','b','c','d','e','f'] then // is hex
                  begin
                    HEX := True;
                    Break;
                  end;
                  Inc(tmp);
                end;
              end;
              if not IP and not HasSlash and (sppos>15) then
                if sp1pos>0
                then
                begin
                  if Buf[sp[14]+1]<>'[' then
                  begin
                    Dec(sppos);
                    for tmp := 14 to sppos do
                      sp[tmp] := sp[tmp+1];
                  end;
                  if (sp1[1]-sp[14]-2>minip) or (sp1[2]-1-sp[15]>minip) then
                    IP := True;
                end
                else if dotcount>3
                then
                  IP := True;
            end
            else if (post > 0) and (posIs > 0) // new trace
            then
            begin
              if (event='r') or (event='s') or (event='f') or (event='d') then
              begin
                nowy := True;
                if wired and HEX and IP then //1.01 "and IP"
                  koniec := True;
                if not HEX then
                begin
                  tmp := posMs;
                  while Buf[tmp]<>#32 do
                  begin
                    if Buf[tmp] in ['a','b','c','d','e','f'] then // is hex
                    begin
                      HEX := True;
                      Break;
                    end;
                    Inc(tmp);
                  end;
                end;
                if not IP then
                  if (NewTraceDotCount(posIs) > 2) or (NewTraceDotCount(posId) > 2)
                  or (NewTraceTagLen(posIs)>minip) or (NewTraceTagLen(posId)>minip)
                  then
                    IP := True;
              end;
            end
            else if wired and ((event='d') or (event='r')) // wired
            then
            begin
              if ((sppos=11) or (sppos=15)) and (dotcount>1) then
              begin
                wired := True;
                if dotcount>lkrop then
                  IP := True;
                if HEX and (bez or nowy) and IP then //1.01 "and IP"
                  koniec := True;
              end;    
            end
            else if (dotcount=1) and not Underline // Trace graph format
            then
              if not wired and not bez and not nowy and (dotcount=1) and (sp1pos=0)
              and ((event='r') or (event='s') or (event='f') or (event='d'))
              then
              begin
                tg := True;
                Koniec := True;
              end;
          end
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
          Inc(linecount);
          if Koniec or (linecount >= MaxLineNr) then
            Break;
        end;
      until Koniec or (readcount <> BufSize) or (linecount >= MaxLineNr);
      if linecount >= MaxLineNr then
        writeln(IntToStr(linecount) + ' lines have been processed to recognize trace format.');
      if wired and bez
      then begin
             TraceFormat := trfWiredOldWireless;
             writeln('wired-old wireless format has been detected');
           end
      else if wired and nowy
      then begin
             TraceFormat := trfWiredNewTrace;
             writeln('wired-new trace format has been detected');
           end
      else if wired
      then begin
             TraceFormat := trfWired;
             writeln('wired format has been detected');
             writeln('trace file will not be converted');
           end               
      else if bez
      then begin
             TraceFormat := trfOldWireless;
             writeln('old wireless format has been detected');
           end
      else if nowy
      then begin
             TraceFormat := trfNewTrace;
             writeln('new trace format has been detected');
           end
      else if tg
      then begin
             TraceFormat := trfTracegraph;
             writeln('Trace graph format has been detected');
             writeln('trace file will not be converted');
           end;
      if IP then
        writeln('IP addresses have been detected');
      if HEX then
        writeln('hexadecimal node numbers have been detected');
      if TraceFormat = trfNone then
        writeln('Trace format cannot be recognized!');  
      Result := True;
    finally
      InputStream.Free;
      sp := nil;
      sp1 := nil;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;

end.
