program trconvert;

{$mode objfpc}{$H+}

uses
  trparams;
  
begin
  ProcessTrace;
end.

