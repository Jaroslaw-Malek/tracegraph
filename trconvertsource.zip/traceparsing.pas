unit TraceParsing;

interface

uses
  Classes, SysUtils;

function ConvertOldWireless(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;
function ConvertNewTrace(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;
function ConvertWiredOldWireless(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;
function ConvertWiredNewTrace(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;

implementation

uses trglobal;

function ConvertOldWireless(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;
var InputStream, OutputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, sppos, sp1pos, tmp, lwpos, lenhexstr_hopto : Integer;
    event : Char;
    eventSFD, spaces, HasSlash : Boolean;
    sp, sp1 : array of Integer;
    lw : array [1..BufSize] of Char;
    hexstr, hexstr_hopto : String;

  procedure l(const startpos, endpos : Integer);
  var j : Integer;
  begin
    for j := startpos to endpos do
    begin
      Inc(lwpos);
      lw[lwpos] := Buf[j];
    end;
  end;

  procedure addc(const aChar : Char);
  begin
    Inc(lwpos);
    lw[lwpos] := aChar;
  end;

  procedure adds(const aStr : String);
  var j : Integer;
  begin
    for j := 1 to length(aStr) do
    begin
      Inc(lwpos);
      lw[lwpos] := aStr[j];
    end;
  end;

  procedure addpkt;
  var tmpspnum : Integer;
  begin
    Inc(lwpos);
    tmpspnum := sp[8]-sp[7];
    FillChar(lw[lwpos], 15-tmpspnum, 32);
    Inc(lwpos, 14-tmpspnum);
  end;

  procedure calchex;
  var j,tmplen,startpos,endpos : Integer;
  begin
    tmplen := sp[12]-sp[11]-1;
    if tmplen <> length(hexstr) then
      SetLength(hexstr, tmplen);
    startpos := sp[11]+1;
    endpos := sp[12]-1;
    tmplen := 0;
    for j := startpos to endpos do
    begin
      Inc(tmplen);
      hexstr[tmplen] := Buf[j];
    end;
    hexstr := IntToStr(StrToInt('$' + hexstr));
  end;

  procedure calchex_hopto;
  var j,tmplen,startpos,endpos : Integer;
      ismax : Byte;
  begin
    tmplen := sp[11]-sp[10]-1;
    if tmplen <> lenhexstr_hopto then
    begin
      lenhexstr_hopto := tmplen;
      SetLength(hexstr_hopto, tmplen);
    end;
    startpos := sp[10]+1;
    endpos := sp[11]-1;
    tmplen := 0;
    ismax := 0;
    for j := startpos to endpos do
    begin
      Inc(tmplen);
      hexstr_hopto[tmplen] := Buf[j];
      if hexstr_hopto[tmplen]='f' then Inc(ismax);
    end;
    if ismax=8 //4294967000 ffffffff
    then adds(' -1 ')
    else begin
           addc(#32);
           adds(IntToStr(StrToInt('$' + hexstr_hopto)));
           addc(#32);
         end;  
  end;

  procedure addseqnr(const startpos, endpos : Integer);
  var j : Integer;
  begin
    for j := startpos to endpos do
      if Buf[j]='x' then
      begin
        Inc(lwpos);
        lw[lwpos] := '-';
        Inc(lwpos);
        lw[lwpos] := '1';
        Exit;
      end;
    for j := startpos to endpos do
    begin
      Inc(lwpos);
      lw[lwpos] := Buf[j];
    end;
  end;

begin
  Result := False;
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    OutputStream := TFileStream.Create(OutPutFileName, fmCreate);
    OutputStream.Write(OutTraceHeader[1], length(OutTraceHeader));
    SetLength(sp, spSize);
    SetLength(sp1, spSize);
    lwpos := 0;
    lenhexstr_hopto := -1;
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          event := Buf[i];
          eventSFD := (event='s') or (event='f') or (event='D');
          if (Buf[i+1]=#32) and (eventSFD or (event='r'))
          then
          begin
            sppos := 0; //number of spaces in the line
            sp1pos := 0; //number of colons in the line
            HasSlash := False;
            while (i <= tmppos) and (Buf[i]<>#10) do
            begin
              if Buf[i]=#32
              then
              begin
                Inc(sppos);
                sp[sppos] := i;
              end
              else if Buf[i]=':'
              then
              begin
                Inc(sp1pos);
                sp1[sp1pos] := i;
              end
              else if not HasSlash and (Buf[i]='/')
              then
                HasSlash := True;
              Inc(i);
            end;
            if sp[4]<>(sp[5]-1)
            then // if there are 2 spaces between columns c4 and c5
            begin
              for tmp := sppos downto 1 do
                sp[tmp+1] := sp[tmp];
              sp[1] := 1;
              Inc(sppos);
              spaces := True;
            end
            else
              spaces := False;
            if eventSFD or ((event='r') and ((Buf[sp[9]+2]<>#48) or (Buf[sp[10]+1]<>#48)
                            or (Buf[sp[11]+1]<>#48) or (Buf[sp[12]+1]<>#48))) then
            begin
              if event='D' then event := 'd';
              addc(event);
              if not spaces
              then begin
                     l(sp[1],sp[2]);
                     l(sp[2]+2,sp[3]-2);
                     l(sp[3],sp[4]);
                   end
              else begin
                     l(sp[2],sp[3]);
                     l(sp[3]+2,sp[4]-2);
                     l(sp[4],sp[5]);
                   end;
              if HEX then calchex;
              if HasSlash or (sppos<15)
              then
              begin
                l(sp[6]+1,sp[7]-1);
                l(sp[7],sp[8]);
                addpkt;
                if not HEX
                then begin
                       l(sp[8]+1,sp[9]-1);
                       l(sp[11],sp[12]);
                     end
                else begin
                       l(sp[8]+1,sp[9]);
                       adds(hexstr);
                       addc(#32);
                     end;
              //left: hop from, hop to, fwd node, seq#
                if event='s'
                then
                begin
                  if not spaces //go back because sp is moved
                  then l(sp[2]+2,sp[3]-2)
                  else l(sp[3]+2,sp[4]-2);
                  if not HEX
                  then begin
                         if Buf[sp[10]+1]='f'
                         then adds(' -1 ')
                         else l(sp[10],sp[11]);
                       end
                  else calchex_hopto;  
                  adds('0 -1'#10);
                end
                else //hop from, hop to, fwd, seq#
                begin
                  if not HEX
                  then
                    l(sp[11]+1,sp[12])
                  else begin
                         adds(hexstr);
                         addc(#32);
                       end;  
                  if not spaces //go back because sp is moved
                  then l(sp[2]+2,sp[3]-2)
                  else l(sp[3]+2,sp[4]-2);
                  adds(' 0 -1'#10);
                end
              end  
              else
              begin
                if Buf[sp[14]+1]<>'[' then
                begin
                  Dec(sppos);
                  for tmp := 14 to sppos do
                    sp[tmp] := sp[tmp+1];
                end;
                l(sp[6]+1,sp[7]-1);
                l(sp[7],sp[8]);
                addpkt;
                if not HEX
                then begin
                       l(sp[8]+1,sp[9]-1);
                       l(sp[11],sp[12]);
                     end
                else begin
                       l(sp[8]+1,sp[9]);
                       adds(hexstr);
                       addc(#32);
                     end;  
                l(sp[14]+2,sp1[1]-1);
                addc(#32);
                l(sp[15]+1,sp1[2]-1);
                l(sp[17],sp[18]-2);
                addc(#32);
                if sppos>18 // there is seq#
                then
                begin
                  if Buf[sp[18]+1]='['
                  then
                    if Buf[sp[19]-1]=']' // seq# [no]
                    then
                      addseqnr(sp[18]+2,sp[19]-2)
                    else //[ack no]
                      addseqnr(sp[18]+2,sp[19]-1)
                  else
                    addseqnr(sp[19]+2,sp[20]-1); // ...] 1 [ack no]
                end
                else
                  adds('-1'); // there is no seq#
                addc(#10);
              end;
              if lwpos > WriteBufSize then
              begin
                OutPutStream.Write(lw, lwpos);
                lwpos := 0;
              end;
            end;
          end
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      if lwpos > 0 then
        OutPutStream.Write(lw, lwpos);
      Result := True;  
    finally
      sp := nil;
      sp1 := nil;
      InputStream.Free;
      OutputStream.Free;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;
{ ---------------------------------------------------------------------------- }
function ConvertNewTrace(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;
var InputStream, OutputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, lwpos, lenhexstr,
    post, posIs, posIt, posIi, posIl, posId, posNi, posNl, posMs, posHd, posPi, posPs : Integer;
    event : Char;
    lw : array [1..BufSize] of Char;
    hexstr : String;

  procedure addtolw(const startpos : Integer; const stopchar : Char);
  var j : Integer;
  begin
    j := startpos;
    while Buf[j]<>stopchar do
    begin
      Inc(lwpos);
      lw[lwpos] := Buf[j];
      Inc(j);
    end;
    Inc(lwpos);
    lw[lwpos] := #32;
  end;

  procedure addc(const aChar : Char);
  begin
    Inc(lwpos);
    lw[lwpos] := aChar;
  end;

  procedure adds(const aStr : String);
  var j : Integer;
  begin
    for j := 1 to length(aStr) do
    begin
      Inc(lwpos);
      lw[lwpos] := aStr[j];
    end;
  end;

  procedure addpkt;
  var tmpspnum : Integer;
  begin
    tmpspnum := lwpos;
    addtolw(posIt, #32);
    tmpspnum := lwpos - tmpspnum;
    Inc(lwpos);
    FillChar(lw[lwpos], 15-tmpspnum, 32);
    Inc(lwpos, 14-tmpspnum);
  end;

  procedure addhex;
  var j, tmplen, endpos : Integer;
  begin
    tmplen := posMs+1;
    j := tmplen;
    while Buf[j]<>#32 do
      Inc(j);
    tmplen := j - posMs;
    if tmplen <> lenhexstr then
    begin
      lenhexstr := tmplen;
      SetLength(hexstr, tmplen);
    end;
    endpos := j-1;
    tmplen := 0;
    for j := posMs to endpos do
    begin
      Inc(tmplen);
      hexstr[tmplen] := Buf[j];
    end;
    adds(IntToStr(StrToInt('$' + hexstr)));
    addc(#32);
  end;

begin
  Result := False;
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    OutputStream := TFileStream.Create(OutPutFileName, fmCreate);
    OutputStream.Write(OutTraceHeader[1], length(OutTraceHeader));    
    //just to remove warnings
    post := 0;
    posIt := 0;
    posIi := 0;
    posIl := 0;
    posId := 0;
    posNi := 0;
    posNl := 0;
    posMs := 0;
    posHd := 0;
    lwpos := 0;
    lenhexstr := -1;
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          event := Buf[i];
          if (Buf[i+1]=#32) and ((event='s') or (event='r') or (event='f') or (event='d'))
          then
          begin
            Inc(i,2);
            posIs := 0;
            posPi := 0;
            posPs := 0;
            while (i <= tmppos) and (Buf[i]<>#10) do
            begin
              if Buf[i]='-'
              then
              begin
                Inc(i);
                case Buf[i] of
                  't' : begin
                          Inc(i,2);
                          post := i;
                        end;
                  'I' : begin
                          Inc(i);
                          case Buf[i] of
                            's' : begin
                                    Inc(i,2);
                                    posIs := i;
                                  end;
                            't' : begin
                                    Inc(i,2);
                                    posIt := i;
                                  end;
                            'i' : begin
                                    Inc(i,2);
                                    posIi := i;
                                  end;
                            'l' : begin
                                    Inc(i,2);
                                    posIl := i;
                                  end;
                            'd' : begin
                                    Inc(i,2);
                                    posId := i;
                                  end;
                          end;
                        end;  
                  'N' : begin
                          Inc(i);
                          case Buf[i] of
                            'i' : begin
                                    Inc(i,2);
                                    posNi := i;
                                  end;
                            'l' : begin
                                    Inc(i,2);
                                    posNl := i;
                                  end;
                          end;
                        end;
                  'M' : begin
                          Inc(i);
                          if Buf[i]='s' then
                          begin
                            Inc(i,2);
                            posMs := i;
                          end;
                        end;
                  'H' : begin
                          Inc(i);
                          if Buf[i]='d' then
                          begin
                            Inc(i,2);
                            posHd := i;
                          end;
                        end;  
                  'P' : if posPs = 0 then //1.01
                        begin
                          Inc(i);
                          case Buf[i] of
                            'i' : begin
                                    Inc(i,2);
                                    posPi := i;
                                  end;
                            's' : begin
                                    Inc(i,2);
                                    posPs := i;
                                  end;
                          end;
                        end;
                end;
              end  
              else
                Inc(i);                
            end;
            if posIs > 0 then
            begin
              addc(event);
              addc(#32);              
              addtolw(post, #32);
              addtolw(posNi, #32);
              addtolw(posNl, #32);
              addtolw(posIi, #32);
              addpkt;
              addtolw(posIl, #32);
              if not HEX
              then addtolw(posMs, #32)
              else addhex;
              addtolw(posIs, #46);
              addtolw(posId, #46);
              addtolw(posHd, #32);
              if posPi > 0
              then begin
                     addtolw(posPi, #32);
                     lw[lwpos] := #10;
                   end
              else if posPs > 0
              then begin
                     addtolw(posPs, #32);
                     lw[lwpos] := #10;
                   end
              else adds(' -1'#10); // there's no seq#
            end;
            if lwpos > WriteBufSize then
            begin
              OutPutStream.Write(lw, lwpos);
              lwpos := 0;
            end;
          end
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      if lwpos > 0 then
        OutPutStream.Write(lw, lwpos);
      Result := True;  
    finally
      InputStream.Free;
      OutputStream.Free;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;
{ ---------------------------------------------------------------------------- }
function ConvertWiredOldWireless(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;
var InputStream, OutputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, sppos, sp1pos, spdotpos, tmp, lwpos, lenhexstr_hopto : Integer;
    event : Char;
    eventSFD, spaces, HasSlash, IsWireless : Boolean;
    sp, sp1, spdot : array of Integer;
    lw : array [1..BufSize] of Char;
    hexstr, hexstr_hopto : String;

  procedure l(const startpos, endpos : Integer);
  var j : Integer;
  begin
    for j := startpos to endpos do
    begin
      Inc(lwpos);
      lw[lwpos] := Buf[j];
    end;
  end;

  procedure addc(const aChar : Char);
  begin
    Inc(lwpos);
    lw[lwpos] := aChar;
  end;

  procedure adds(const aStr : String);
  var j : Integer;
  begin
    for j := 1 to length(aStr) do
    begin
      Inc(lwpos);
      lw[lwpos] := aStr[j];
    end;
  end;

  procedure addpkt;
  var tmpspnum : Integer;
  begin
    Inc(lwpos);
    tmpspnum := sp[8]-sp[7];
    FillChar(lw[lwpos], 15-tmpspnum, 32);
    Inc(lwpos, 14-tmpspnum);
  end;

  procedure calchex;
  var j,tmplen,startpos,endpos : Integer;
  begin
    tmplen := sp[12]-sp[11]-1;
    if tmplen <> length(hexstr) then
      SetLength(hexstr, tmplen);
    startpos := sp[11]+1;
    endpos := sp[12]-1;
    tmplen := 0;
    for j := startpos to endpos do
    begin
      Inc(tmplen);
      hexstr[tmplen] := Buf[j];
    end;
    hexstr := IntToStr(StrToInt('$' + hexstr));
  end;

  procedure calchex_hopto;
  var j,tmplen,startpos,endpos : Integer;
      ismax : Byte;
  begin
    tmplen := sp[11]-sp[10]-1;
    if tmplen <> lenhexstr_hopto then
    begin
      lenhexstr_hopto := tmplen;
      SetLength(hexstr_hopto, tmplen);
    end;
    startpos := sp[10]+1;
    endpos := sp[11]-1;
    tmplen := 0;
    ismax := 0;
    for j := startpos to endpos do
    begin
      Inc(tmplen);
      hexstr_hopto[tmplen] := Buf[j];
      if hexstr_hopto[tmplen]='f' then Inc(ismax);
    end;
    if ismax=8 //4294967000 ffffffff
    then adds(' -1 ')
    else begin
           addc(#32);
           adds(IntToStr(StrToInt('$' + hexstr_hopto)));
           addc(#32);
         end;
  end;

  procedure addseqnr(const startpos, endpos : Integer);
  var j : Integer;
  begin
    for j := startpos to endpos do
      if Buf[j]='x' then
      begin
        Inc(lwpos);
        lw[lwpos] := '-';
        Inc(lwpos);
        lw[lwpos] := '1';
        Exit;
      end;
    for j := startpos to endpos do
    begin
      Inc(lwpos);
      lw[lwpos] := Buf[j];
    end;
  end;

  //wired
  function hfromother : Boolean;
  var hopfromstart, hopfromend, cnodestart : Integer;
  begin
    hopfromstart := sp[8]+1; // hop from without port number
    hopfromend := sp1[1]-1;
    cnodestart := sp[2]+1; // other node
    if (hopfromend - hopfromstart) <> (sp[3]-1 - cnodestart) //different length
    then Result := False
    else begin
           while hopfromstart <= hopfromend do
           begin
             if Buf[hopfromstart]<>Buf[cnodestart] then
             begin
               Result := False;
               Exit;
             end;
             Inc(hopfromstart);
             Inc(cnodestart);
           end;
           Result := True;
         end;
  end;

  procedure addpktwired;
  var j : Integer;
  begin;
    if sppos=11
    then begin
           j := sp[11]+1;
           while (Buf[j]<>#13) and (Buf[j]<>#10) do
           begin
             Inc(lwpos);
             lw[lwpos] := Buf[j];
             Inc(j);
           end;
         end
    else l(sp[11]+1,sp[12]-1);
    l(sp[4],sp[5]);
    Inc(lwpos);
    j := sp[5]-sp[4];
    FillChar(lw[lwpos], 16-j, 32);
    Inc(lwpos, 15-j);
    l(sp[5]+1,sp[6]);
  end;

begin
  Result := False;
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    OutputStream := TFileStream.Create(OutPutFileName, fmCreate);
    OutputStream.Write(OutTraceHeader[1], length(OutTraceHeader));    
    SetLength(sp, spSize);
    SetLength(sp1, spSize);
    SetLength(spdot, spSize);    
    lwpos := 0;
    lenhexstr_hopto := -1;
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          if Buf[i+1]=#32
          then
          begin
            event := Buf[i];
            sppos := 0; //number of spaces in the line
            sp1pos := 0; //number of colons in the line
            spdotpos := 0; //number of dots in the line
            HasSlash := False;
            IsWireless := False;
            while (i <= tmppos) and (Buf[i]<>#10) do
            begin
              case Buf[i] of
                #32 : begin
                        Inc(sppos);
                        sp[sppos] := i;
                      end;
                ':' : begin
                        Inc(sp1pos);
                        sp1[sp1pos] := i;
                      end;
                '.' : begin
                        Inc(spdotpos);
                        spdot[spdotpos] := i;
                      end;
                '[' : IsWireless := True;
                else if not HasSlash and (Buf[i]='/')
                then
                  HasSlash := True;
              end;
              Inc(i);
            end;
            if IsWireless
            then
            begin
              eventSFD := (event='s') or (event='f') or (event='D');
              if eventSFD or (event='r') then
              begin
                if sp[4]<>(sp[5]-1)
                then // if there are 2 spaces between columns c4 and c5
                begin
                  for tmp := sppos downto 1 do
                    sp[tmp+1] := sp[tmp];
                  sp[1] := 1;
                  Inc(sppos);
                  spaces := True;
                end
                else
                  spaces := False;
                if eventSFD or ((event='r') and ((Buf[sp[9]+2]<>#48) or (Buf[sp[10]+1]<>#48)
                                or (Buf[sp[11]+1]<>#48) or (Buf[sp[12]+1]<>#48))) then
                begin
                  if event='D' then event := 'd';
                  addc(event);
                  if not spaces
                  then begin
                         l(sp[1],sp[2]);
                         l(sp[2]+2,sp[3]-2);
                         l(sp[3],sp[4]);
                       end
                  else begin
                         l(sp[2],sp[3]);
                         l(sp[3]+2,sp[4]-2);
                         l(sp[4],sp[5]);
                       end;
                  if HEX then calchex;
                  if HasSlash or (sppos<15)
                  then
                  begin
                    l(sp[6]+1,sp[7]-1);
                    l(sp[7],sp[8]);
                    addpkt;
                    if not HEX
                    then begin
                           l(sp[8]+1,sp[9]-1);
                           l(sp[11],sp[12]);
                         end
                    else begin
                           l(sp[8]+1,sp[9]);
                           adds(hexstr);
                           addc(#32);
                         end;
                  //left: hop from, hop to, fwd node, seq#
                    if event='s'
                    then
                    begin
                      if not spaces //go back because sp is moved
                      then l(sp[2]+2,sp[3]-2)
                      else l(sp[3]+2,sp[4]-2);
                      if not HEX
                      then begin
                             if Buf[sp[10]+1]='f'
                             then adds(' -1 ')
                             else l(sp[10],sp[11]);
                           end
                      else calchex_hopto;
                      adds('0 -1'#10);
                    end
                    else //hop from, hop to, fwd, seq#
                    begin
                      if not HEX
                      then
                        l(sp[11]+1,sp[12])
                      else begin
                             adds(hexstr);
                             addc(#32);
                           end;
                      if not spaces //go back because sp is moved
                      then l(sp[2]+2,sp[3]-2)
                      else l(sp[3]+2,sp[4]-2);
                      adds(' 0 -1'#10);
                    end
                  end  
                  else
                  begin
                    if Buf[sp[14]+1]<>'[' then
                    begin
                      Dec(sppos);
                      for tmp := 14 to sppos do
                        sp[tmp] := sp[tmp+1];
                    end;
                    l(sp[6]+1,sp[7]-1);
                    l(sp[7],sp[8]);
                    addpkt;
                    if not HEX
                    then begin
                           l(sp[8]+1,sp[9]-1);
                           l(sp[11],sp[12]);
                         end
                    else begin
                           l(sp[8]+1,sp[9]);
                           adds(hexstr);
                           addc(#32);
                         end;  
                    l(sp[14]+2,sp1[1]-1);
                    addc(#32);
                    l(sp[15]+1,sp1[2]-1);
                    l(sp[17],sp[18]-2);
                    addc(#32);
                    if sppos>18 // there is seq#
                    then
                    begin
                      if Buf[sp[18]+1]='['
                      then
                        if Buf[sp[19]-1]=']' // seq# [no]
                        then
                          addseqnr(sp[18]+2,sp[19]-2)
                        else //[ack no]
                          addseqnr(sp[18]+2,sp[19]-1)
                      else
                        addseqnr(sp[19]+2,sp[20]-1); // ...] 1 [ack no]
                    end
                    else
                      adds('-1'); // there is no seq#
                    addc(#10);
                  end;
                end;
              end; //if eventSFD or (event='r') then
            end //if IsWireless
            else if ((sppos=11) or (sppos=15)) and
                    ((event='+') or (event='-') or (event='r') or  (event='d')) //if wired
            then
            begin
              if sp1pos=0 then
              begin
                sp1[1] := spdot[spdotpos-1];
                sp1[2] := spdot[spdotpos];
              end;
              case event of
                '+' : if hfromother
                      then
                      begin
                        addc('s');
                        l(sp[1],sp[2]);
                        l(sp[2]+1,sp[3]-1); //cnode
                        adds(' AGT ');
                        addpktwired;
                        adds('0 ');  //onode='0'; % -Ms
                        l(sp[8]+1,sp1[1]-1); //hop from without port number
                        l(sp[9],sp1[2]-1);
                        adds(' 0'); //fwdnode='0'; % -Hd
                      end
                      else
                      begin
                        addc('r');
                        l(sp[1],sp[2]);
                        l(sp[2]+1,sp[3]-1); //cnode
                        adds(' RTR ');
                        addpktwired;
                        adds('-1 ');  //onode % -Ms
                        l(sp[8]+1,sp1[1]-1); //hop from without port number
                        l(sp[9],sp1[2]-1);
                        addc(#32);
                        l(sp[3]+1,sp[4]-1); //fwdnode % -Hd
                      end;
                '-' : if hfromother
                      then
                      begin
                        addc('s');
                        l(sp[1],sp[2]);
                        l(sp[2]+1,sp[3]-1); //cnode
                        adds(' MAC ');
                        addpktwired;
                        adds('0 ');  //onode='0'; % -Ms
                        l(sp[8]+1,sp1[1]-1); //hop from without port number
                        l(sp[9],sp1[2]-1);
                        adds(' 0'); //fwdnode='0'; % -Hd
                      end
                      else
                      begin
                        addc('f');
                        l(sp[1],sp[2]);
                        l(sp[2]+1,sp[3]-1); //cnode
                        adds(' RTR ');
                        addpktwired;
                        adds('0 ');  //onode % -Ms
                        l(sp[8]+1,sp1[1]-1); //hop from without port number
                        l(sp[9],sp1[2]-1);
                        addc(#32);
                        l(sp[3]+1,sp[4]-1); //fwdnode % -Hd
                      end;
                'r' : begin
                        addc('r');
                        l(sp[1],sp[2]);
                        l(sp[3]+1,sp[4]-1); //cnode
                        adds(' MAC ');
                        addpktwired;
                        l(sp[2]+1,sp[3]-1); //onode=cnode; % -Ms
                        addc(#32);
                        l(sp[8]+1,sp1[1]-1); //hop from without port number
                        l(sp[9],sp1[2]-1);
                        adds(' 0'); //fwdnode='0'; % -Hd
                      end;
                'd' : begin
                        addc('d');
                        l(sp[1],sp[2]);
                        l(sp[2]+1,sp[3]-1); //cnode
                        adds(' RTR ');
                        addpktwired;
                        adds('0 ');  //onode % -Ms
                        l(sp[8]+1,sp1[1]-1); //hop from without port number
                        l(sp[9],sp1[2]-1);
                        addc(#32);
                        l(sp[3]+1,sp[4]-1); //fwdnode % -Hd
                      end;
              end;
              l(sp[10],sp[11]-1);
              addc(#10);
            end //if wired
            else
            begin//move to the next line
              while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
              Inc(i);
            end;
            if lwpos > WriteBufSize then
            begin
              OutPutStream.Write(lw, lwpos);
              lwpos := 0;
            end;
          end //if Buf[i+1]=#32
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      if lwpos > 0 then
        OutPutStream.Write(lw, lwpos);
      Result := True;  
    finally
      sp := nil;
      sp1 := nil;
      spdot := nil;
      InputStream.Free;
      OutputStream.Free;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;
{ ---------------------------------------------------------------------------- }
function ConvertWiredNewTrace(const TraceFileName, OutPutFileName : String;
  HEX : Boolean) : Boolean;
var InputStream, OutputStream : TFileStream;
    Buf : array [1..BufSize] of Char;
    readcount, i, tmppos, lwpos, lenhexstr, sppos, sp1pos, spdotpos,
    post, posIs, posIt, posIi, posIl, posId, posNi, posNl, posMs, posHd, posPi, posPs : Integer;
    event : Char;
    sp, sp1, spdot : array of Integer;
    lw : array [1..BufSize] of Char;
    hexstr : String;

  procedure addtolw(const startpos : Integer; const stopchar : Char);
  var j : Integer;
  begin
    j := startpos;
    while Buf[j]<>stopchar do
    begin
      Inc(lwpos);
      lw[lwpos] := Buf[j];
      Inc(j);
    end;
    Inc(lwpos);
    lw[lwpos] := #32;
  end;

  procedure addc(const aChar : Char);
  begin
    Inc(lwpos);
    lw[lwpos] := aChar;
  end;

  procedure adds(const aStr : String);
  var j : Integer;
  begin
    for j := 1 to length(aStr) do
    begin
      Inc(lwpos);
      lw[lwpos] := aStr[j];
    end;
  end;

  procedure addpkt;
  var tmpspnum : Integer;
  begin
    tmpspnum := lwpos;
    addtolw(posIt, #32);
    tmpspnum := lwpos - tmpspnum;
    Inc(lwpos);
    FillChar(lw[lwpos], 15-tmpspnum, 32);
    Inc(lwpos, 14-tmpspnum);
  end;

  procedure addhex;
  var j, tmplen, endpos : Integer;
  begin
    tmplen := posMs+1;
    j := tmplen;
    while Buf[j]<>#32 do
      Inc(j);
    tmplen := j - posMs;
    if tmplen <> lenhexstr then
    begin
      lenhexstr := tmplen;
      SetLength(hexstr, tmplen);
    end;
    endpos := j-1;
    tmplen := 0;
    for j := posMs to endpos do
    begin
      Inc(tmplen);
      hexstr[tmplen] := Buf[j];
    end;
    adds(IntToStr(StrToInt('$' + hexstr)));
    addc(#32);
  end;

  //wired
  procedure l(const startpos, endpos : Integer);
  var j : Integer;
  begin
    for j := startpos to endpos do
    begin
      Inc(lwpos);
      lw[lwpos] := Buf[j];
    end;
  end;

  function hfromother : Boolean;
  var hopfromstart, hopfromend, cnodestart : Integer;
  begin
    hopfromstart := sp[8]+1; // hop from without port number
    hopfromend := sp1[1]-1;
    cnodestart := sp[2]+1; // other node
    if (hopfromend - hopfromstart) <> (sp[3]-1 - cnodestart) //different length
    then Result := False
    else begin
           while hopfromstart <= hopfromend do
           begin
             if Buf[hopfromstart]<>Buf[cnodestart] then
             begin
               Result := False;
               Exit;
             end;
             Inc(hopfromstart);
             Inc(cnodestart);
           end;
           Result := True;
         end;
  end;

  procedure addpktwired;
  var j : Integer;
  begin;
    if sppos=11
    then begin
           j := sp[11]+1;
           while (Buf[j]<>#13) and (Buf[j]<>#10) do
           begin
             Inc(lwpos);
             lw[lwpos] := Buf[j];
             Inc(j);
           end;
         end
    else l(sp[11]+1,sp[12]-1);
    l(sp[4],sp[5]);
    Inc(lwpos);
    j := sp[5]-sp[4];
    FillChar(lw[lwpos], 16-j, 32);
    Inc(lwpos, 15-j);
    l(sp[5]+1,sp[6]);
  end;
  
begin
  Result := False;
  try
    InputStream := TFileStream.Create(TraceFileName, fmOpenRead);
    OutputStream := TFileStream.Create(OutPutFileName, fmCreate);
    OutputStream.Write(OutTraceHeader[1], length(OutTraceHeader));    
    //just to remove warnings
    posIt := 0;
    posIi := 0;
    posIl := 0;
    posId := 0;
    posNi := 0;
    posNl := 0;
    posMs := 0;
    posHd := 0;
    SetLength(sp, spSize);
    SetLength(sp1, spSize);
    SetLength(spdot, spSize);    
    lwpos := 0;
    lenhexstr := -1;
    try
      repeat
        readcount := InputStream.Read(Buf, BufSize);
        tmppos := readcount;
        if readcount = BufSize then
        begin
          while Buf[tmppos] <> #10 do
            Dec(tmppos);
          InputStream.Position := InputStream.Position - readcount + tmppos;
        end;
        i := 1;
        while i <= tmppos do
        begin
          if Buf[i+1]=#32
          then
          begin
            event := Buf[i];
            if (Buf[i+2]='-') and (Buf[i+3]='t') //new trace
            then
            begin
              if (event='s') or (event='r') or (event='f') or (event='d')
              then
              begin
                Inc(i,5);
                post := i;
                posIs := 0;
                posPi := 0;
                posPs := 0;
                while (i <= tmppos) and (Buf[i]<>#10) do
                begin
                  if Buf[i]='-'
                  then
                  begin
                    Inc(i);
                    case Buf[i] of
                      'I' : begin
                              Inc(i);
                              case Buf[i] of
                                's' : begin
                                        Inc(i,2);
                                        posIs := i;
                                      end;
                                't' : begin
                                        Inc(i,2);
                                        posIt := i;
                                      end;
                                'i' : begin
                                        Inc(i,2);
                                        posIi := i;
                                      end;
                                'l' : begin
                                        Inc(i,2);
                                        posIl := i;
                                      end;
                                'd' : begin
                                        Inc(i,2);
                                        posId := i;
                                      end;
                              end;
                            end;  
                      'N' : begin
                              Inc(i);
                              case Buf[i] of
                                'i' : begin
                                        Inc(i,2);
                                        posNi := i;
                                      end;
                                'l' : begin
                                        Inc(i,2);
                                        posNl := i;
                                      end;
                              end;
                            end;
                      'M' : begin
                              Inc(i);
                              if Buf[i]='s' then
                              begin
                                Inc(i,2);
                                posMs := i;
                              end;
                            end;
                      'H' : begin
                              Inc(i);
                              if Buf[i]='d' then
                              begin
                                Inc(i,2);
                                posHd := i;
                              end;
                            end;  
                      'P' : if posPs = 0 then //1.01
                            begin
                              Inc(i);
                              case Buf[i] of
                                'i' : begin
                                        Inc(i,2);
                                        posPi := i;
                                      end;
                                's' : begin
                                        Inc(i,2);
                                        posPs := i;
                                      end;
                              end;
                            end;
                    end;
                  end  
                  else
                    Inc(i);                
                end;
                if posIs > 0 then
                begin
                  addc(event);
                  addc(#32);              
                  addtolw(post, #32);
                  addtolw(posNi, #32);
                  addtolw(posNl, #32);
                  addtolw(posIi, #32);
                  addpkt;
                  addtolw(posIl, #32);
                  if not HEX
                  then addtolw(posMs, #32)
                  else addhex;
                  addtolw(posIs, #46);
                  addtolw(posId, #46);
                  addtolw(posHd, #32);
                  if posPi > 0
                  then begin
                         addtolw(posPi, #32);
                         lw[lwpos] := #10;
                       end
                  else if posPs > 0
                  then begin
                         addtolw(posPs, #32);
                         lw[lwpos] := #10;
                       end
                  else adds(' -1'#10); // there's no seq#
                end;
              end //if (event='s') or (event='r') or (event='f') or (event='d')
              else
              begin//move to the next line
                while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
                Inc(i);
              end;
            end //if new trace
            else if (event='+') or (event='-') or (event='r') or  (event='d') //if wired
            then
            begin
              sppos := 0;
              sp1pos := 0;
              spdotpos := 0;
              while (i <= tmppos) and (Buf[i]<>#10) do
              begin
                case Buf[i] of
                  #32 : begin
                          Inc(sppos);
                          sp[sppos] := i;
                        end;
                  ':' : begin
                          Inc(sp1pos);
                          sp1[sp1pos] := i;
                        end;
                  '.' : begin
                          Inc(spdotpos);
                          spdot[spdotpos] := i;
                        end;
                end;
                Inc(i);
              end;
              if (sppos=11) or (sppos=15) then
              begin
                if sp1pos=0 then
                begin
                  sp1[1] := spdot[spdotpos-1];
                  sp1[2] := spdot[spdotpos];
                end;
                case event of
                  '+' : if hfromother
                        then
                        begin
                          addc('s');
                          l(sp[1],sp[2]);
                          l(sp[2]+1,sp[3]-1); //cnode
                          adds(' AGT ');
                          addpktwired;
                          adds('0 ');  //onode='0'; % -Ms
                          l(sp[8]+1,sp1[1]-1); //hop from without port number
                          l(sp[9],sp1[2]-1);
                          adds(' 0'); //fwdnode='0'; % -Hd
                        end
                        else
                        begin
                          addc('r');
                          l(sp[1],sp[2]);
                          l(sp[2]+1,sp[3]-1); //cnode
                          adds(' RTR ');
                          addpktwired;
                          adds('-1 ');  //onode % -Ms
                          l(sp[8]+1,sp1[1]-1); //hop from without port number
                          l(sp[9],sp1[2]-1);
                          addc(#32);
                          l(sp[3]+1,sp[4]-1); //fwdnode % -Hd
                        end;
                  '-' : if hfromother
                        then
                        begin
                          addc('s');
                          l(sp[1],sp[2]);
                          l(sp[2]+1,sp[3]-1); //cnode
                          adds(' MAC ');
                          addpktwired;
                          adds('0 ');  //onode='0'; % -Ms
                          l(sp[8]+1,sp1[1]-1); //hop from without port number
                          l(sp[9],sp1[2]-1);
                          adds(' 0'); //fwdnode='0'; % -Hd
                        end
                        else
                        begin
                          addc('f');
                          l(sp[1],sp[2]);
                          l(sp[2]+1,sp[3]-1); //cnode
                          adds(' RTR ');
                          addpktwired;
                          adds('0 ');  //onode % -Ms
                          l(sp[8]+1,sp1[1]-1); //hop from without port number
                          l(sp[9],sp1[2]-1);
                          addc(#32);
                          l(sp[3]+1,sp[4]-1); //fwdnode % -Hd
                        end;
                  'r' : begin
                          addc('r');
                          l(sp[1],sp[2]);
                          l(sp[3]+1,sp[4]-1); //cnode
                          adds(' MAC ');
                          addpktwired;
                          l(sp[2]+1,sp[3]-1); //onode=cnode; % -Ms
                          addc(#32);
                          l(sp[8]+1,sp1[1]-1); //hop from without port number
                          l(sp[9],sp1[2]-1);
                          adds(' 0'); //fwdnode='0'; % -Hd
                        end;
                  'd' : begin
                          addc('d');
                          l(sp[1],sp[2]);
                          l(sp[2]+1,sp[3]-1); //cnode
                          adds(' RTR ');
                          addpktwired;
                          adds('0 ');  //onode % -Ms
                          l(sp[8]+1,sp1[1]-1); //hop from without port number
                          l(sp[9],sp1[2]-1);
                          addc(#32);
                          l(sp[3]+1,sp[4]-1); //fwdnode % -Hd
                        end;
                end;
                l(sp[10],sp[11]-1);
                addc(#10);
              end; //if (sppos=11) or (sppos=15) 
            end //if wired
            else
            begin//move to the next line
              while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
              Inc(i);
            end;
            if lwpos > WriteBufSize then
            begin
              OutPutStream.Write(lw, lwpos);
              lwpos := 0;
            end;
          end
          else
          begin//move to the next line
            while (i <= tmppos) and (Buf[i]<>#10) do Inc(i);
            Inc(i);
          end;
        end;
      until readcount <> BufSize;
      if lwpos > 0 then
        OutPutStream.Write(lw, lwpos);
      Result := True;  
    finally
      sp := nil;
      sp1 := nil;
      spdot := nil;
      InputStream.Free;
      OutputStream.Free;
    end;
  except
    on E : Exception do
      writeln('Error parsing trace file (' + TraceFileName + '): ' + E.Message);
  end;
end;

end.

