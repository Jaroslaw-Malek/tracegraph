unit trglobal;

interface

const BufSize        = 32768; //read buffer
      spSize         = 100; //space positions buffer
      FWDLENGTH      = 4; //forward node length (old wireless)
      WriteBufSize   = 30000; //write buffer
      OutTraceHeader = 'tracegraph'#10; //output file header
            
implementation

end.
