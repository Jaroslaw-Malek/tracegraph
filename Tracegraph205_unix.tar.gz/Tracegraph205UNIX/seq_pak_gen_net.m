function varargout = seq_pak_gen_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C7 C9 C11 C13 TRACEFORMAT MAC NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    typ=C11~=-1 & typstart(handles,0); % packet type
    if TRACEFORMAT==1
        wsp=C1=='+' & C3==C9 & typ;
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0;
        elseif MAC==1
            wsp4=C1=='s';
        end
        wsp=wsp4 & typ;
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C11(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet generate time [sec]','sequence number of generated packet', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);