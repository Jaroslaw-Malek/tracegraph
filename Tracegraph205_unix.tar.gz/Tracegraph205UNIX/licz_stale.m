function licz_stale
% trgraph
% calculates constants during trace file loading such sa TMAX, PAKIETY, LNOD
global LNOD PAKIETY pole TRACEFORMAT TSTART TEND PAKROZ rozpak
global C2 C3 C4 C5 C6 C9 C10

if TRACEFORMAT==1
    C9=floor(C9);
    C10=floor(C10);
end
if TSTART==-1 & TEND==-1
    LNOD=max(C3); LNOD=max(LNOD, max(C4));
    LNOD=max(LNOD, max(C9)); LNOD=max(LNOD, max(C10))+1;
else
    LNOD=max(length(usunpowt(C3)), length(usunpowt(C4)));
    LNOD=max(LNOD, length(usunpowt(C9)));
    LNOD=max(LNOD, length(usunpowt(C10)))+1;
end
paktmp=unique(C5, 'rows');
paksize=size(paktmp);
paksize=paksize(1);
PAKIETY=cell(paksize,1);
paktype=paktmp(1,:);
PAKIETY{1}=paktype;
pole=['-',paktype(1,:)];
for i=2:paksize
    paktype=paktmp(i,:);
    PAKIETY{i}=paktype;
    pole=[pole, '|-', paktype];
end
PAKROZ=sort(usunpowt(C6));
rozpak=['-',num2str(PAKROZ(1))];
for i=2:length(PAKROZ)
    rozpak=[rozpak, '|-', num2str(PAKROZ(i))];
end