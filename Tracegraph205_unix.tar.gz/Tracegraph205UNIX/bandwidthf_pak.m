function varargout = bandwidthf_pak(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C6 C7 C8 C9 C12 C13 AKTWEZ TRACEFORMAT BANDI NET HIST CHECK IDCOUNT

if CHECK(6)==1
    IDCOUNT=1;
end
HIST=0;
NET=0;
czyscosie;
x={'time', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    if TRACEFORMAT==1
        wsp=C1=='-' & C3==AKTWEZ & C8~=-2 & typstart(handles, 'pakf');
    elseif TRACEFORMAT==2
        wsp=C1=='f' & C3==AKTWEZ & typstart(handles, 'pakf');
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        c2=C2(wsp);
        c6=C6(wsp);
        c12=C12(wsp);
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        band=zeros(roz, 1);
	    if CHECK(6)==1
            band(1)=length(usunpowt(c12(c2<=czas(1))));
        else
            band(1)=sum(c2<=czas(1));
        end
        for i=2:roz
            if CHECK(6)==1
                band(i)=length(usunpowt(c12(c2>czas(i-1) & c2<=czas(i))));
            else
                band(i)=sum(c2>czas(i-1) & c2<=czas(i));
            end
        end
	[hplot,czas,band]=rysuj(czas', band,handles);
        zapisz_wykres([czas, band], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('simulation time [sec]', ['throughput of forwarding packets at node ', num2str(AKTWEZ), ' [No. of Packets/TIL]'], hplot, handles);
end
IDCOUNT=0;
zapisz_wykres_jpg(opis,handles);