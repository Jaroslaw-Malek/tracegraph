function varargout = size_proc_max(h, eventdata, handles, varargin)
% trgraph
global NET DC DCONLY AKTWEZ HIST PAKROZ

HIST=0;
DC=1;
DCONLY=1;
NET=0; % whole network
czyscosie;
[czy, opis]=czyopis('packet size', h, eventdata, handles);
if czy==0
    [opoz,id,roz]=procwsp(handles,3);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        op=zeros(length(PAKROZ),1);
        for i=1:length(PAKROZ)
            m=opoz(roz==PAKROZ(i));
            if isempty(m)==0
                op(i)=max(m);
            end
        end    
        [hplot,pr,op]=rysuj(PAKROZ, op, handles);
        zapisz_wykres([pr, op], opis, handles);
    end   
    plot_info(opis, eventdata, hplot, handles);
    xylabel('packet size',['maximal processing time at node ', num2str(AKTWEZ),' [sec]'], hplot, handles);
end
DC=0;    
DCONLY=0;
zapisz_wykres_jpg(opis,handles);