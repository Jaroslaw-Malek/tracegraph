function varargout = bandsmax_jit(h, eventdata, handles, varargin)
% trgraph
global C2 C6 NET AKTWEZ STARTWEZ HIST DC BANDI fig DELAY

thandles=guihandles(fig);
DELAY=1;
DC=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    x={'throughput', BANDI};
    [czy, opis]=czyopis(x, h, eventdata, handles);
    HIST=0; 
    if czy==0        
        wsp=typstart(handles,4);
        c2=C2(wsp);
        c6=C6(wsp);
        opoz=[];
        if isempty(c2)==0        
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
            roz=length(czas);
            op=zeros(roz, 1);
            band=op;
            band(1)=sum(c6(c2<=czas(1)))*8;
            for i=2:roz
                band(i)=sum(c6(c2>czas(i-1) & c2<=czas(i)))*8;
            end
            [opoz,id,stime,tr]=wezdel(handles,1);
            stime=stime(2:end);
            opoz=abs(opoz(2:end)-opoz(1:(end-1)));
            o=opoz(stime>0 & stime<=czas(1));
            if isempty(o)
                op(1)=0;
            else
                op(1)=max(o);
            end    
            for i=2:roz
                o=opoz(stime>czas(i-1) & stime<=czas(i));
                if isempty(o)
                    op(i)=0;
                else
                    op(i)=max(o);
                end
            end
            opoz=op;
        end    
        if sum(opoz)==0
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
            HIST=2; % empty graph
        else
            [band, index]=sort(band);
            opoz=opoz(index);            
            bnd=usunpowt(band);
            op=zeros(length(bnd),1);
            for i=1:length(bnd)
                m=max(opoz(band==bnd(i)));
                if isempty(m)==0
                    op(i)=m;
                end    
            end    
	    [hplot,bnd,op]=rysuj(bnd, op,handles);
            zapisz_wykres([bnd, op], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['throughput of sending bits at node ', num2str(AKTWEZ), ' [bits/TIL]'],['maximal jitter between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    x={'throughput', BANDI};
    [czy, opis]=czyopis(x, h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['throughput of sending bits at node ', num2str(AKTWEZ), ' [bits/TIL]'],['maximal jitter between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
end
DC=0;    
DELAY=0;
zapisz_wykres_jpg(opis,handles);