function w=typstart(handles, par)
% trgraph
% gets rows from columns C3 (source node) and C5 (packet types)
global CHECK C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C12 C13 STARTWEZ AKTWEZ PAKIETY TRACEFORMAT CZY3D MAC TSTART TEND NET pole
global fig DCONLY FLOWID FID TRACELEVEL DELAY PAKROZ rozpak RTT PKTLIST

if isempty(CZY3D)
    CZY3D=0;
end
if isempty(NET)
    NET=0;
end
if AKTWEZ==STARTWEZ & par~=0 & par~=3 & par~=6 & CHECK(2)==1 & CZY3D==0 & NET==0
    w=zeros(length(C3), 1);
else
    handles=guihandles(fig);
    l=length(C3);
    w=ones(l, 1);
    if CHECK(1)==1 & strcmp(par, 'bezpaktyp')==0 & RTT==0
        temp=zeros(l,1);
        for lp=1:length(PAKIETY)
            pak=char(PAKIETY{lp});
            if isempty(findstr(pole, ['-',pak]))
                i=1;
                pac=ones(l,1);
                while i<=length(pak) & pak(i)~=32
                    pac=pac & C5(:,i)==pak(i);
                    i=i+1;
                end
                temp=temp | pac;
            end
        end
        w=w & temp;
    elseif RTT==1
        if strcmp(par, 'sent')
            pak=char(PAKIETY{get(handles.sentpkt, 'Value')});
        elseif strcmp(par, 'ack')
            pak=char(PAKIETY{get(handles.ackpkt, 'Value')});
        end    
        pac=ones(l,1); i=1;
        while i<=length(pak) & pak(i)~=32
            pac=pac & C5(:,i)==pak(i);
            i=i+1;
        end
        w=w & pac;
    end    
    if CHECK(7)==1
        temp=zeros(l,1);
        for lp=1:length(PAKROZ)
            if isempty(findstr(rozpak, ['-',num2str(PAKROZ(lp))]))
                temp=temp | C6==PAKROZ(lp);
            end
        end
        w=w & temp;
    end
    if DELAY==0 & TRACEFORMAT==2 & MAC==1 & strcmp(par, 'pakd')==0 & par~=6 & par~=3 & par~=4 & strcmp(par, 'sent')==0 & strcmp(par,'ack')==0 % par 6 if drop
        if par~=5 & strcmp(par, 'pakf')==0 & par~=15 % 15 only forward 3D
            w=w & C13(:,1)=='M';
        else
            w=w & C13(:,1)=='R';
        end
    end
    if TRACEFORMAT==1 & strcmp(get(handles.flowidoption, 'Checked'),'on')
        w=w & FID==FLOWID;
    end
    if strcmp(get(handles.timeint, 'Checked'),'on')
        w=w & C2>=TSTART & C2<=TEND;    
    end
    if ((DELAY==1 & par==0) | (strcmp(par,'ack') & RTT==1)) & TRACEFORMAT==2
        dtl=char(TRACELEVEL(get(handles.dtracelevel, 'Value')));
        w=w & C13(:,1)==dtl(1);
    end
    if par==3 % for the whole network when calculating delays
        if TRACEFORMAT==1
            if DELAY==1
                if CHECK(8)==0
                    w=C1=='-' & C3==C9 & w & C8~=-2; % sending
                else
                    w=C1=='-' & C3==C9;
                end
            else
                w=C1=='-' & C3==C9 & w & C8~=-2; % sending
            end
        elseif TRACEFORMAT==2
            stl=char(TRACELEVEL(get(handles.stracelevel, 'Value')));
            if DELAY==1
                if CHECK(8)==0
                    w=C1=='s' & C13(:,1)==stl(1) & w & C7~=-1;% sending
                else    
                    w=C1=='s' & C13(:,1)==stl(1);
                end
            else
                w=C1=='s' & C13(:,1)==stl(1) & w & C7~=-1;% sending
            end
        end
    elseif par==4 % between nodes when calculating delays
        if strcmp(get(handles.directcon, 'Checked'),'on')            
            if DELAY==1
                if TRACEFORMAT==1                
                    if CHECK(8)==0
                        w=C1=='-' & C3==AKTWEZ & C4==STARTWEZ & w & C8~=-2;
                    else
                        w=C1=='-' & C3==AKTWEZ & C4==STARTWEZ;
                    end
                elseif TRACEFORMAT==2
                    if CHECK(8)==0
                        w=C1=='f' & C3==AKTWEZ & w & C7==STARTWEZ;
                    else
                        w=C1=='f' & C3==AKTWEZ & C7==STARTWEZ;
                    end
                end
            else
                if TRACEFORMAT==1                
                    w=C1=='-' & C3==AKTWEZ & C4==STARTWEZ & w & C8~=-2;
                elseif TRACEFORMAT==2
                    w=C1=='f' & C3==AKTWEZ & w & C7==STARTWEZ;
                end
            end
        else
            if DELAY==1
                if TRACEFORMAT==1
                    if CHECK(8)==0
                        w=C1=='-' & C3==AKTWEZ & C9==AKTWEZ & C10==STARTWEZ & w; % sent packets
                    else
                        w=C1=='-' & C3==AKTWEZ & C9==AKTWEZ & C10==STARTWEZ;
                    end
                elseif TRACEFORMAT==2
                    stl=char(TRACELEVEL(get(handles.stracelevel, 'Value')));
                    if CHECK(8)==0
                        w=C1=='s' & C3==AKTWEZ & C7~=-1 & w & C10==STARTWEZ & C13(:,1)==stl(1);
                    else
                        w=C1=='s' & C3==AKTWEZ & C10==STARTWEZ & C13(:,1)==stl(1);
                    end
                end
            else
                if TRACEFORMAT==1          
                    w=C1=='-' & C3==AKTWEZ & C9==AKTWEZ & C10==STARTWEZ & w; % sent packets
                elseif TRACEFORMAT==2
                    stl=char(TRACELEVEL(get(handles.stracelevel, 'Value')));
                    w=C1=='s' & C3==AKTWEZ & C7~=-1 & w & C10==STARTWEZ & C13(:,1)==stl(1);
                end
            end
        end
    end
    if RTT==1
        if NET==1 % whole network
            if strcmp(par, 'sent') % sent packets
                if TRACEFORMAT==1
                    w=C1=='-' & C3==C9 & w & C8~=-2; % sending
                elseif TRACEFORMAT==2
                    stl=char(TRACELEVEL(get(handles.stracelevel, 'Value')));
                    w=C1=='s' & C13(:,1)==stl(1) & w & C7~=-1;% sending
                end
            elseif strcmp(par,'ack') % received ack packets
                w=C1=='r' & C4==C10 & w; % odbior
            end
        elseif NET==0 % AKTWEZ sends packets STARTWEZ sends ACK
            if strcmp(par, 'sent') % sent packets
                if TRACEFORMAT==1          
                    w=C1=='-' & C3==AKTWEZ & C9==AKTWEZ & C10==STARTWEZ & w; % sent packets
                elseif TRACEFORMAT==2
                    stl=char(TRACELEVEL(get(handles.stracelevel, 'Value')));
                    w=C1=='s' & C3==AKTWEZ & C7~=-1 & w & C10==STARTWEZ & C13(:,1)==stl(1);
                end
            elseif strcmp(par,'ack') % received ack packets
                w=C1=='r' & C4==AKTWEZ & C9==STARTWEZ & C10==AKTWEZ & w;               
            end    
        end    
    end    
    if par~=1 & par~=15 % 15 only forward 3D
        if TRACEFORMAT==2 & strcmp(par, 'pakf')
            w=w & C7~=-2;
        end
        if CHECK(2)==1 & strcmp(par, 'pakr')
            if TRACEFORMAT==2 & MAC==0
                c13=['end'; C13(1:(end-1),:)];
                c1=['s'; C1(1:(end-1))];
                c4=[-1; C4(1:(end-1))];
                c12=[-1; C12(1:(end-1))];
                w=w & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
            end
            if DCONLY==1 | strcmp(get(handles.directcon, 'Checked'),'on')
                w=w & C3==STARTWEZ;
            else    
                w=w & C9==STARTWEZ & C10==AKTWEZ;
            end
        elseif CHECK(2)==1 & strcmp(par, 'paks')
            w=w & C10==STARTWEZ; 
        elseif CHECK(2)==1 & strcmp(par, 'pakg')
            w=w & C10==STARTWEZ;     
        elseif CHECK(2)==1 & strcmp(par, 'pakf') & TRACEFORMAT==1
            w=w & C4==STARTWEZ;
        elseif CHECK(2)==1 & strcmp(par, 'pakf') & TRACEFORMAT==2
            w=w & C7==STARTWEZ;
        elseif CHECK(2)==1 & strcmp(par, 'pakd') & TRACEFORMAT==1
            c=C1=='d' & C3==AKTWEZ;
            if strcmp(get(handles.directcon, 'Checked'),'on')
                w=w & c & C8==STARTWEZ;
            else
                w=w & c & C9==STARTWEZ;
            end
        elseif CHECK(2)==1 & strcmp(par, 'pakd') & TRACEFORMAT==2
            if strcmp(get(handles.directcon, 'Checked'),'on')
                w=w & C4==STARTWEZ;
            else
                w=w & C9==STARTWEZ;
            end
        end
    end
end