function varargout = events_hop_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST

HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('send event time', h, eventdata, handles);
if czy==0
    [hop, hopf, id, stime, tr]=nethop(handles,1);
    if isempty(hop)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [hplot,stime,hop]=rysuj(stime, hop, handles);
        zapisz_wykres([stime, hop], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet send time at source node [sec]','number of intermediate nodes receiving packets', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);