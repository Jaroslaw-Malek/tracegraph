function varargout = suma_bajt_wys_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C6 C7 C8 C9 C13 TRACEFORMAT MAC NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    typ=typstart(handles,0); % packet type
    if TRACEFORMAT==1
        wsp=C1=='-' & C3==C9 & typ & C8~=-2;
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0;
        elseif MAC==1
            wsp4=C1=='s' & C7~=-3;
        end
        wsp=wsp4 & typ & C7~=-1;
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        x=C2(wsp);
        y=cumsum(C6(wsp));
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('send event time [sec]','cumulative sum of sent bytes', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);