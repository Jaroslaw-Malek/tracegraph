function varargout = eventr_delay(h, eventdata, handles, varargin)
% trgraph
global NET AKTWEZ STARTWEZ HIST DC fig DELAY

thandles=guihandles(fig);
DELAY=1;
DC=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('receive event time', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [opoz,id,stime,tr]=wezdel(handles,1);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else            
            [tr,i]=sort(tr);
            opoz=opoz(i);
            [hplot,tr,opoz]=rysuj(tr, opoz, handles);
            zapisz_wykres([tr, opoz], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['packet receive time at node ', num2str(STARTWEZ), ' [sec]'],['delay between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ), ' [sec]'], hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('receive event time', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);	
	xylabel(['packet receive time at node ', num2str(STARTWEZ), ' [sec]'],['delay between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ), ' [sec]'], hplot, handles);
    end
end
DC=0;
DELAY=0;
zapisz_wykres_jpg(opis,handles);