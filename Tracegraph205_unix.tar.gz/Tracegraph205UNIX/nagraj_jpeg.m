function varargout = nagraj_jpeg(h, eventdata, handles, varargin)
% trgraph
% saves figure to a jpeg file

[plik, katalog]=uiputfile('*.jpg', 'Choose file name to save');
if plik~=0
   osieoff(handles,0);
   print('-djpeg', [katalog,plik]);
   osieoff(handles,1);
end 