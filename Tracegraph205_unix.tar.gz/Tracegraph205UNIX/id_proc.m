function varargout = id_proc(h, eventdata, handles, varargin)
% trgraph
global NET DC DCONLY AKTWEZ HIST

HIST=0;
DC=1;
DCONLY=1;
NET=0; % whole network
czyscosie;
[czy, opis]=czyopis('packet id', h, eventdata, handles);
if czy==0
    [opoz,id]=procwsp(handles);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [id,index]=sort(id);
        opoz=opoz(index);
        [hplot,id,opoz]=rysuj(id, opoz, handles);
        zapisz_wykres([id, opoz], opis, handles);
    end   
    plot_info(opis, eventdata, hplot, handles);
    xylabel('packet id',['processing time at node ', num2str(AKTWEZ),' [sec]'], hplot, handles);
end
DC=0;    
DCONLY=0;
zapisz_wykres_jpg(opis,handles);