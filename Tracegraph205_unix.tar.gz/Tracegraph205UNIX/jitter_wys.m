function varargout = jitter_wys(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C5 C7 C8 C9 C11 C13 AKTWEZ NET HIST TRACEFORMAT MAC

HIST=0;
NET=0;
czyscosie;
[czy, opis]=czyopis('seq#', h, eventdata, handles);
if czy==0
    wsp=C11~=-1;
    if TRACEFORMAT==1
        wsp=wsp & C1=='-' & C3==AKTWEZ & C9==AKTWEZ & typstart(handles, 'paks') & C8~=-2;
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0 & C3==AKTWEZ;
        elseif MAC==1
            wsp4=C1=='s' & C3==AKTWEZ & C13(:,1)=='M' & C7~=-3;
        end
        wsp=wsp & wsp4 & C7~=-1 & typstart(handles, 'paks');
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
    else    
        time=C2(wsp);
        seq=C11(wsp);
        s=seq;
        seq=seq(2:end)-seq(1:(end-1));
        if isempty(seq)==0
            seq(seq==0)=1;
            y=time(2:end)-time(1:(end-1));
            y=y./seq;
            s=s(2:end);
            [hplot,s,y]=rysuj(s, y,handles);
            zapisz_wykres([s, y], opis, handles);
        else
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        end
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('sequence number',['jitter of sent packet at node ', num2str(AKTWEZ),' [sec]'], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);