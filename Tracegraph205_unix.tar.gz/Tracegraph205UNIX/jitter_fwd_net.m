function varargout = jitter_fwd_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C7 C8 C11 AKTWEZ NET HIST TRACEFORMAT

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('seq#', h, eventdata, handles);
if czy==0
    typ=C11~=-1 & typstart(handles, 5);
    if TRACEFORMAT==1
        wsp=C1=='-' & typ & C8~=-2;
    elseif TRACEFORMAT==2
        wsp=C1=='f' & typ & C7~=-2;
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
    else    
        time=C2(wsp);
        seq=C11(wsp);
        s=seq;
        seq=seq(2:end)-seq(1:(end-1));
        if isempty(seq)==0
            seq(seq==0)=1;
            y=time(2:end)-time(1:(end-1));
            y=y./seq;
            s=s(2:end);
            [hplot,s,y]=rysuj(s, y, handles);
            zapisz_wykres([s, y], opis, handles);
        else
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        end
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('sequence number','jitter of forwarded packet [sec]', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);