function [h,x,y]=rysuj(x,y,handles)
% trgraph
% plots a graph
global HIST CZY3D

if CZY3D==0
    if strcmp(get(handles.logscalex,'Checked'),'on')
        ind=x>0;
        x=log(x(ind));
        y=y(ind);    
    end
    if strcmp(get(handles.logscaley,'Checked'),'on')
        ind=y>0;
        y=log(y(ind));
        x=x(ind);    
    end
    if HIST==0
        h=plot(x,y,'Parent',handles.axes1);
    else
        h=bar(x,y,'histc');
    end    
else
    zero=x<=0;
    if strcmp(get(handles.logscalez,'Checked'),'on')    
        x(zero)=1;
        x=log(x);
        x(zero)=0;
        h=bar3(x);
    else
        h=bar3(x);
    end
end        