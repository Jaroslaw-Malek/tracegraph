function canusetr=usun_linie_wired(plik,katalog,temp)
% trgraph
% removes unneccessary lines from wired format

% these 2 lines can be uncommented if there are only +,-,r,d events in the
% trace file, i.e. there are only lines beginning with "+ ","- ","r ","d " 
% canusetr=1; % textread can be used no lines have to be removed
% return;

canusetr=0;
[events]=textread([katalog,plik],'%2c%*[^\n]');
le=length(events);
if length(find(events(:,2)))==le
    e1=events(:,1);
    e1=e1=='+' | e1=='-' | e1=='r' | e1=='d';
     if length(find(e1))==le
        canusetr=1; % textread can be used no lines have to be removed
        return;
    end        
end
fid=fopen([katalog,plik]);
fidw=fopen([katalog,temp],'wb');
fblocksize=20000; %optimal value
fblock=fread(fid,fblocksize,'*char');
spnum=-1;
k=1;
lw=[];
while isempty(fblock)==0
    lb=length(fblock);
    i=lb;
    while i>1 & fblock(i)~=10 %looking for the end of line
        i=i-1;
    end
    fblock=[10,fblock(1:i)']; % cutting EOL at the end of the block
    fblock=strrep(fblock, char(13), '');    
    lsps=fblock==32; % spaces
    leols=findstr(fblock,10); % EOLs positions
    leneols=length(leols)-1;
    endpos=leols(2:end)-1;
    eolpos2=leols+2;
    eolpos1=leols+1;
    events=fblock=='+' | fblock=='-' | fblock=='r' | fblock=='d';
    for j=1:leneols
        if lsps(eolpos2(j))
            eventpos=eolpos1(j);
            if events(eventpos)
                l=fblock(eventpos:endpos(j)); % a single line
                sp=find(lsps(eventpos:endpos(j)));
                tmpspnum=sp(5)-sp(4);
                if tmpspnum~=spnum
                    pkt=char(zeros(1, 15-tmpspnum)+32);
                    spnum=tmpspnum;
                end
                lw=[lw,l(1:sp(5)),pkt,l((sp(5)+1):sp(6)),l((sp(7)+1):end),10];
                k=k+1;
                if k==5
                    fwrite(fidw, lw, 'char');                    
                    lw=[];
                    k=1;   
                end    
            end    
        end   
    end    
    fseek(fid,i-lb,0); %back to the end of line
    fblock=fread(fid,fblocksize,'*char');            
end
if isempty(lw)==0
    fwrite(fidw, lw, 'char');
end    
fclose(fid);
fclose(fidw);