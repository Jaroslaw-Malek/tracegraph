function xylabel(xl, yl, hplot, handles)
% trgraph
% appends Xlabel and Ylabel to a graph

xlabel(xl);
ylabel(yl);
set(handles.xlabel, 'String', xl);
set(handles.ylabel, 'String', yl);