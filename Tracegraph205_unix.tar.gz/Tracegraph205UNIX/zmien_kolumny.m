function zmien_kolumny(plik,katalog)
% trgraph 
% switches columns after loading a trace file in format TRACEFORMAT 1, 2 and 3
global FID C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 C12 C13 MAC USUNPLIK TRACEFORMAT PODZIAL DELTEMP HEX

if TRACEFORMAT==1
    FID=C8;
    drop=find(C1=='d');
    iddrop=C12(drop);
    rec=C1=='r';
    fwd=C1=='-';
    l=length(drop);
    c4r=C4(rec);
    c12r=C12(rec);
    rnr=find(rec);    
    dl=length(c4r);
    if dl~=0
        n=ceil(dl/PODZIAL); dl=floor(dl/n);
        poz=1;
        C8(drop)=-1;
        for p=1:n
            if p==n
                wsp=poz:length(c4r);
            else
                wsp=poz:(poz+dl-1);
            end
            c4rp=c4r(wsp);
            c12rp=c12r(wsp);
            for i=1:l
                r=find(C3(drop(i))==c4rp & c12rp==iddrop(i)); % when packet received by C4 was dropped by C3 pakiet (packet ID=iddrop(i))
                if isempty(r)==0
                    C8(drop(i))=C3(rnr(r(end)+poz-1)); % node number forwarded the later dropped packet
                end
            end
            poz=poz+dl;
        end   
    end
    clear c4r c12r rnr c4rp c12rp;    
    %forward
    c4f=C4(fwd);
    c3f=C3(fwd);
    c12f=C12(fwd);
    fnr=find(fwd);
    dl=length(c4f);
    if dl~=0
        n=ceil(dl/PODZIAL); dl=floor(dl/n);
        poz=1;
        for p=1:n
            if p==n
                wsp=poz:length(c4f);
            else
                wsp=poz:(poz+dl-1);
            end
            c3fp=c3f(wsp);
            c4fp=c4f(wsp);
            c12fp=c12f(wsp);
            for i=1:l
                r=find(C3(drop(i))==c3fp & C4(drop(i))==c4fp & c12fp==iddrop(i)); % when was forwarded by C3 to C4 and then dropped
                if isempty(r)==0
                    C8(fnr(r(end)+poz-1))=-2; % forward failure in line fnr(r(end)+poz-1)
                end
            end
            poz=poz+dl;
        end 
    end    
else    
    %event, time, CN, AGT_RTR_IFQ, ID, type, size, ON, hopf, hopto, fwd_node, seq#
    % C13 AGT RTR IFQ
    % C8 sending node (fffffff) 
    % C7 dest forward
    % C8=zeros(length(C1),1)-1; % which node forwared packet before dropping
    if HEX==0
        tracefmt='%c%f%d%3c%d%15c%d%d%d%d%d%d';
    else
        tracefmt='%c%f%d%3c%d%15c%d%s%d%d%d%d';
    end    
    if strcmp(plik, 'temp')
        if USUNPLIK==1 % removes temporary file
            [C1,C2,C3,C13,C12,C5,C6,c4,C9,C10,C7,C11]=textread(strcat(katalog,plik),tracefmt,'delimiter',' ');
            if DELTEMP==1   
                delete(strcat(katalog,plik));
            end    
        else
            [C1,C2,C3,C13,C12,C5,C6,c4,C9,C10,C7,C11]=textread(strcat(katalog,plik),tracefmt,'delimiter',' ', ...
                'headerlines',1);
            if DELTEMP==1   
                delete(strcat(katalog,plik));
            end
        end
    else
        [C1,C2,C3,C13,C12,C5,C6,c4,C9,C10,C7,C11]=textread(strcat(katalog,plik),tracefmt, ...
            'delimiter',' ','headerlines',1);
    end
    if isempty(C2)
        return;
    end
    if HEX
        indmin=strmatch('-',c4); %looking for '-1'
        c4(indmin)={'0'}; %to avoid exception when converting with hex2dec
        c4=hex2dec(c4);
        c4(indmin)=-1;
        c4(c4>=4294967000)=-1; %ffffffff
    end    
    odb=C1=='r'; % switches current and other node, delete r RTR [0 0 0 0]
    C13=char(C13);
    C4=c4; C4(odb)=C3(odb);    
    C3(odb)=c4(odb);
    clear c4;
    odb=C1=='f';
    C4(odb)=C7(odb); % next node during forwarding
    dp=C1=='d'; % drop events
    send=C1=='s';
    if length(find(C13(:,1)=='M'))
        MAC=1;
        C7(send & C13(:,1)=='R')=-3; % delete RTR if AGT, RTR, MAC
    else 
        MAC=0;
    end
    if isempty(dp)==0
        dropsend=dp & C3==C9;
        dropfwd=dp & C3~=C9;
        C7(dropsend)=-1; % source node C3 dropped packet during sending
        C7(dropfwd)=-2; % forwarding node C3 dropped packet from source node C9 during forwarding
        c3=C3(dropsend);
        c10=C10(dropsend);
        id=C12(dropsend);
        l=length(c3);
        c3s=C3(send);
        dl=length(c3s);
        if dl~=0
            c10s=C10(send);
            c12s=C12(send);       
            c7s=zeros(dl, 1);           
            c7s(ismember(c3s, c3) & ismember(c10s, c10) & ismember(c12s, id))=-1;
            snr=find(send);
            C7(snr(find(c7s==-1)))=-1; % during send event packet was dropped at node C3
        end
        %forwarding
        c3=C3(dropfwd);
        c10=C10(dropfwd);
        id=C12(dropfwd);
        l=length(c3);        
        c3s=C3(odb);
        dl=length(c3s);
        if dl~=0
            c10s=C10(odb);
            c12s=C12(odb);       
            c7s=zeros(dl, 1);           
            for i=1:l
                c7s(c3s==c3(i) & c10s==c10(i) & c12s==id(i))=-2;
            end
            snr=find(odb);
            C7(snr(find(c7s==-2)))=-2; % during forward event packet was dropped at node C3
        end
    end
    clear dp odb;    
end