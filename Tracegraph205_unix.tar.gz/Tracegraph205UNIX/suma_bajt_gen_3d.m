function suma_bajt_gen_3d(h, eventdata, handles, varargin)
% trgraph
global C1 C3 C4 C6 C7 C9 C10 C12 C13 LNOD CZY3D TRACEFORMAT MAC NET HIST

HIST=0;
NET=0;
os={'source node', 'destination node'};
CZY3D=1;
hold off;
[czy, opis]=czyopis(os, h, eventdata, handles);
sumy=zeros(LNOD, LNOD);
w=typstart(handles, 1); % only packet type
if TRACEFORMAT==1
    w=w & C1=='+';
    c9=C9(w);
elseif TRACEFORMAT==2
    if MAC==0
        w=w & send_mac_0;
    elseif MAC==1
        w=w & C1=='s';
    end
end
c3=C3(w);
if isempty(c3)==0
    c6=C6(w);
    c10=C10(w);
    for i=1:LNOD
        for j=1:LNOD
            if i~=j
                if TRACEFORMAT==1
                    wsp=c3==(i-1) & c9==(i-1) & c10==(j-1);
                elseif TRACEFORMAT==2
                    if MAC==0
                        wsp=c3==(i-1) & c10==(j-1);
                    elseif MAC==1
                        wsp=c3==(i-1) & c10==(j-1);
                    end
                end
                sumy(i,j)=sum(c6(wsp));
            else
                sumy(i,j)=0;
            end
        end
    end
end    
[h,sumy,y]=rysuj(sumy',1,handles);
title(opis);
set(handles.axes1, 'xTickLabel', 0:LNOD);
set(handles.axes1, 'yTickLabel', 0:LNOD);
rotate3d on;
zoom off;
axis tight;
zapisz_wykres(sumy', opis, handles);
xylabel(os{1},os{2},-1, handles);
zapisz_wykres_jpg(opis,handles);