function fe=dystemp(x)
% trgraph
% calculates empirical CDF based on vector x

fe=sort(usunpowt(x));
fe=[fe,fe];
for i=1:length(fe);
   fe(i, 2)=sum(x==fe(i, 1));
end
fe(:, 2)=fe(:, 2)./length(x);
fe(:, 2)=cumsum(fe(:, 2));