function varargout = suma_bajtow_rys(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C6 C7 C8 C9 C12 C13 AKTWEZ TRACEFORMAT MAC NET HIST

HIST=0;
NET=0;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    if TRACEFORMAT==1
        wsp=C1=='-' & C3==AKTWEZ & C9==AKTWEZ & C8~=-2 & typstart(handles, 'paks');
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0 & C3==AKTWEZ;
        elseif MAC==1
            wsp4=C1=='s' & C3==AKTWEZ & C13(:,1)=='M' & C7~=-3;
        end
        wsp=wsp4 & C7~=-1 & typstart(handles, 'paks');
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        x=C2(wsp);
        y=cumsum(C6(wsp));
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('send event time [sec]',['cumulative sum of sent bytes at node ', num2str(AKTWEZ)], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);