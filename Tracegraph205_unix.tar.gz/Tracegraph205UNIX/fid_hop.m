function varargout = fid_hop(h, eventdata, handles, varargin)
% trgraph
global NET AKTWEZ STARTWEZ HIST DC TRACEFORMAT

if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('packet id', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [hopr, hop, id, stime, tr]=wezhop(handles,2);
        if isempty(hop)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else
            [id, index]=sort(id);
            hop=hop(index);
            [hplot,id,hop]=rysuj(id, hop, handles);
            zapisz_wykres([id, hop], opis, handles);
        end        
        plot_info(opis, eventdata, hplot, handles);
	xylabel('packet id',['number of intermediate nodes forwarding packets sent from node ', ...
	num2str(AKTWEZ),' to node ', num2str(STARTWEZ)], hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('packet id', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);
	xylabel('packet id',['number of intermediate nodes forwarding packets sent from node ', ...
	num2str(AKTWEZ),' to node ', num2str(STARTWEZ)], hplot, handles);
    end
end
zapisz_wykres_jpg(opis,handles);