function check_info(handles, par)
% trgraph
% check if node information is on
global CHECK AKTWEZ STARTWEZ sfig DELAY RTT
handles=guihandles(sfig);

if CHECK(5)==1 % auto zmiana info
    if strcmp(get(handles.wezinfo, 'Checked'), 'on') & (par==0 | par==2)
        wez_info1(handles);
    end
    if strcmp(get(handles.syminfo, 'Checked'), 'on') & (par==1 | par==2)
        sym_info1(handles);
    end
    if strcmp(get(handles.simdelays, 'Checked'), 'on') & (par==1 | par==2)
        sym_delay(handles);
    end
    if strcmp(get(handles.nodedelays, 'Checked'), 'on') & (par==0 | par==2) & CHECK(2)==1 & AKTWEZ~=STARTWEZ
        wez_delay(handles);
    elseif strcmp(get(handles.nodedelays, 'Checked'), 'on') & (par==0 | par==2) & CHECK(2)==1 & AKTWEZ==STARTWEZ
        wez_delay_txt(1, 1, handles, 1);
    end
    if strcmp(get(handles.hopnetnr, 'Checked'), 'on') & (par==1 | par==2)
        hopnet_nr(handles);
    end
    if strcmp(get(handles.hopnr, 'Checked'), 'on') & (par==0 | par==2)
        hop_nr(handles);
    end
    if strcmp(get(handles.netproc, 'Checked'), 'on') & (par==1 | par==2)
        procnet(handles);
    end
    if strcmp(get(handles.proc, 'Checked'), 'on') & (par==0 | par==2)
        proc(handles);
    end
    if strcmp(get(handles.net_rtt, 'Checked'), 'on') & (par==1 | par==2)
        net_rtt(handles);
    end
    if strcmp(get(handles.wez_rtt, 'Checked'), 'on') & (par==0 | par==2) & CHECK(2)==1 & AKTWEZ~=STARTWEZ
        wez_rtt(handles);
    end
end