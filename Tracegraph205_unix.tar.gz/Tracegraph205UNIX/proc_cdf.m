function varargout = proc_cdf(h, eventdata, handles, varargin)
% trgraph
global NET DCONLY DC AKTWEZ HIST

HIST=0;
DC=1;
DCONLY=1;
NET=0; % whole network
czyscosie;
[czy, opis]=czyopis('processing time', h, eventdata, handles);
if czy==0
    [opoz,id]=procwsp(handles);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        d=dystemp(opoz);
        x=d(:,1);
        y=d(:,2);
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
    xylabel(['processing time at node ', num2str(AKTWEZ), ' [sec]'],...
        'processing times cumulative distribution', hplot, handles);
end
DC=0;    
DCONLY=0;
zapisz_wykres_jpg(opis,handles);