function varargout = seq_pak_gen(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C6 C7 C9 C11 C12 C13 AKTWEZ TRACEFORMAT MAC NET HIST

HIST=0;
NET=0;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C11~=-1;
    if TRACEFORMAT==1
        wsp=wsp & C1=='+' & C3==AKTWEZ & C9==AKTWEZ & typstart(handles, 'pakg');
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0 & C3==AKTWEZ;
        elseif MAC==1
            wsp4=C1=='s' & C3==AKTWEZ & C13(:,1)=='M';
        end
        wsp=wsp & wsp4 & typstart(handles, 'pakg');
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C11(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet generate time [sec]',['sequence number of generated packet at node ', num2str(AKTWEZ)], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);