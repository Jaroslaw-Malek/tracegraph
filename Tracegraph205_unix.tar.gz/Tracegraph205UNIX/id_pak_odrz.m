function varargout = id_pak_odrz(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C7 C12 AKTWEZ STARTWEZ CHECK TRACEFORMAT NET HIST DC fig

thandles=guihandles(fig);
HIST=0;
NET=0;
DC=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    drop=C1=='d' & C3==AKTWEZ;
    if (CHECK(2)==0 & CHECK(1)==0) | (CHECK(1)==1 & CHECK(2)==0)
        wsp=drop & typstart(handles, 'pakd');
    else
        wsp=typstart(handles, 'pakd');
        if TRACEFORMAT==2
            wsp=wsp & drop;
        end
    end
    if TRACEFORMAT==2 & AKTWEZ==STARTWEZ & CHECK(2)
        wsp=drop & C4==STARTWEZ & typstart(handles, 6) & C7==-1;
    end    
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C12(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet drop time [sec]',['id of dropped packet at node ', num2str(AKTWEZ)], hplot, handles);
end  
DC=0;
zapisz_wykres_jpg(opis,handles);