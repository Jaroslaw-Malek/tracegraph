function varargout = seq_pak_odb(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C6 C11 AKTWEZ NET HIST DC

HIST=0;
NET=0;
DC=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C11~=-1 & C4==AKTWEZ & C1=='r' & typstart(handles, 'pakr'); % receive events times
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C11(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet receive time [sec]',['sequence number of received packet at node ', num2str(AKTWEZ)], hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);