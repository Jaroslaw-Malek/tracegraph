function varargout = procnet_txt(h, eventdata, handles, varargin)
% trgraph
% shows text concerning processing times for the whole network

if strcmp(get(handles.netproc, 'Checked'), 'on')
    set(handles.netproc, 'Checked', 'off');
    set(handles.frame7, 'Visible', 'off');
    set(handles.netproctxt, 'Visible', 'off');
    set(handles.minprocnettxt, 'Visible', 'off');
    set(handles.maxprocnettxt, 'Visible', 'off');
    set(handles.avgprocnettxt, 'Visible', 'off');
    set(handles.minprocnet, 'Visible', 'off');
    set(handles.maxprocnet, 'Visible', 'off');
    set(handles.avgprocnet, 'Visible', 'off');
else    
    set(handles.netproc, 'Checked', 'on');
    procnet(handles);
    set(handles.frame7, 'Visible', 'on');
    set(handles.netproctxt, 'Visible', 'on');
    set(handles.minprocnettxt, 'Visible', 'on');
    set(handles.maxprocnettxt, 'Visible', 'on');
    set(handles.avgprocnettxt, 'Visible', 'on');
    set(handles.minprocnet, 'Visible', 'on');
    set(handles.maxprocnet, 'Visible', 'on');
    set(handles.avgprocnet, 'Visible', 'on');
end