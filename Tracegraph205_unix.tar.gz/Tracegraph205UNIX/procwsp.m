function [pt,nid,rpak] = procwsp(handles,par)
% trgraph
% calculates processing times for the current node
global C1 C2 C3 C4 C6 C8 C9 C12 AKTWEZ TRACEFORMAT PREC STARTWEZ CHECK DCONLY % only direct connection is correct when forwarding to ON

if CHECK(2)==1 & AKTWEZ~=STARTWEZ | CHECK(2)==0
    DCONLY=1;
    if TRACEFORMAT==1
        rpf=C1=='-' & C3==AKTWEZ & typstart(handles, 'pakf') & C9~=AKTWEZ & C8~=-2;
    elseif TRACEFORMAT==2
        rpf=C1=='f' & C3==AKTWEZ & typstart(handles, 'pakf');
    end
    id=C12(rpf); % IDs of forwarded packets
    l=length(id);
    rpr=C1=='r' & C4==AKTWEZ & typstart(handles, 0);
    pt=zeros(sum(rpf), 1)-1; %processing times
    nid=pt; % packets numbers
    if nargin==1
        par=0;
    end    
    if par==3
        rpak=pt;
    else
        rpak=[];
    end        
    in=1; % indexes to pt    
    c2r=C2(rpr);
    c2f=C2(rpf);    
    c12r=C12(rpr);
    c12f=C12(rpf);
    if par==3
        c6=C6(rpf);
    end    
    tr=pt;
    if nargin==1 | par==3
        for j=1:l
            fwd=c12f==id(j);
            tfj=c2f(fwd); % forwarding time of packet id(j)
            if par==3
                rp=c6(fwd);
            end    
            if isempty(tfj)==0
                rec=c12r==id(j);
                trj=c2r(rec); % receive events times
                if isempty(trj)==0
                    for i=1:length(tfj) % for each forwarded packet search for time of it's receive event (the closest to forward time is chosen)
                        pt(in)=min(-trj+tfj(i)); % processing time
                        nid(in)=id(j);
                        if par==3
                            rpak(in)=rp(i);
                        end    
                        in=in+1;                               
                    end
                end
            end        
        end
        clear c2r c2f c12r c12f;
        zero=find(pt>=0);
        pt=pt(zero);
        nid=nid(zero);
        if par==3
            rpak=rpak(zero);
        end    
    elseif par==1 % receive events times
        for j=1:l
            fwd=c12f==id(j);
            tfj=c2f(fwd); % forwarding time of packet id(j)
            if isempty(tfj)==0
                rec=c12r==id(j);
                trj=c2r(rec); % receive events times
                if isempty(trj)==0
                    for i=1:length(tfj) % for each forwarded packet search for time of it's receive event (the closest to forward time is chosen)
                        [pt(in),ind]=min(-trj+tfj(i)); % processing time
                        nid(in)=trj(ind);
                        in=in+1;                               
                    end
                end
            end        
        end
        clear c2r c2f c12r c12f;
        zero=find(pt>=0);
        pt=pt(zero);
        nid=nid(zero);
        [nid,ind]=sort(nid);
        pt=pt(ind);
    elseif par==2 %forward events times
        for j=1:l
            fwd=c12f==id(j);
            tfj=c2f(fwd); % forwarding time of packet id(j)
            if isempty(tfj)==0
                rec=c12r==id(j);
                trj=c2r(rec); % receive events times
                if isempty(trj)==0
                    for i=1:length(tfj) % for each forwarded packet search for time of it's receive event (the closest to forward time is chosen)
                        [pt(in),ind]=min(-trj+tfj(i)); % processing time
                        nid(in)=tfj(i);
                        in=in+1;                               
                    end
                end
            end        
        end
        clear c2r c2f c12r c12f;
        zero=find(pt>=0);
        pt=pt(zero);
        nid=nid(zero);
        [nid,ind]=sort(nid);
        pt=pt(ind);
    end
    DCONLY=0;
else
    pt=[];
    nid=[];
end