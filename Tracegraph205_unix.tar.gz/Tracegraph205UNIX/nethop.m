function [hopr, hopf, id, stime, rtime]=nethop(handles,par)
% trgraph
% calculates number of intermediate nodes for the whole network
global C1 C2 C3 C4 C7 C8 C9 C10 C12 TRACEFORMAT PREC PODZIAL

typ=typstart(handles,0); % packet type
wsp=typstart(handles,3);
stime=C2(wsp); % sent events times
id=C12(wsp); % IDs of sent packets
l=length(id);
hopr=zeros(l, 1)-1; 
hopf=zeros(l, 1)-1; 
r=C1=='r' & typ; % receive events at destination nodes
rpr=r & C4~=C10; % receive events at intermediate nodes
r=r & C4==C10;
if TRACEFORMAT==1 
    rpf=typ & C1=='-' & C3~=C9 & C8~=-2; % forwarding nodes
elseif TRACEFORMAT==2
    rpf=typstart(handles,5) & C1=='f' & C7~=-2;
end
c2=C2(r);
c12=C12(r);
c12r=C12(rpr);
c12f=C12(rpf);
if isempty(c12f)==0
    rtime=zeros(l,1);
    for j=1:l
        trj=c2(c12==id(j)); % receive event time of packet id(j)
        if isempty(trj)==0
            if par==0 
                hopr(j)=sum(c12r==id(j)); % number of intermediate nodes receiving packets
                hopf(j)=sum(c12f==id(j)); % number of intermediate nodes forwarding packets
            elseif par==1
                hopr(j)=sum(c12r==id(j)); % number of intermediate nodes receiving packets
                rtime(j)=trj(1);
            elseif par==2
                hopf(j)=sum(c12f==id(j)); % number of intermediate nodes forwarding packets
                rtime(j)=trj(1);
            end
        end        
    end
    clear c2 c12 c12r c12f;
    zeror=find(hopr>-1); 
    hopr=hopr(zeror);
    zerof=find(hopf>-1);
    hopf=hopf(zerof);
    if par==0
        stime=[];
        rtime=[];
    elseif par==1   
        rtime=rtime(zeror);
        stime=stime(zeror);
        id=id(zeror);
    elseif par==2   
        rtime=rtime(zerof);
        stime=stime(zerof);
        id=id(zerof);
    end
else
    hopr=[];
    hopf=[];
    id=[];
    stime=[];
    rtime=[];
end   