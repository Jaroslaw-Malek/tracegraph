function wez_delay(handles)
% trgraph
% shows delays between 2 nodes
global PREC DELAY

DELAY=1;
[opoz,id,st,rt]=wezdel(handles,0);
if isempty(opoz)==0
    [mind,i]=min(opoz);
    minid=id(i);
    [maxd,i]=max(opoz);
    maxid=id(i);
    avgd=mean(opoz);                      
    set(handles.aktmindinfo, 'String', [num2str(mind,PREC),' (',num2str(minid),')']);
    set(handles.aktmaxdinfo, 'String', [num2str(maxd,PREC),' (',num2str(maxid),')']);
    set(handles.aktavgdinfo, 'String', num2str(avgd,PREC));
else
    na(handles);
end
zapisz_info(handles);
DELAY=0;

%----------
function na(handles)
set(handles.aktmindinfo, 'String', 'N/A');
set(handles.aktmaxdinfo, 'String', 'N/A');
set(handles.aktavgdinfo, 'String', 'N/A');