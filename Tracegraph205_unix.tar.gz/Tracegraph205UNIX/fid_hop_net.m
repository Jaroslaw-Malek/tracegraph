function varargout = fid_hop_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST TRACEFORMAT

HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('packet id', h, eventdata, handles);
if czy==0
    [hopr, hop, id, stime, tr]=nethop(handles,2);
    if isempty(hop)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [id, index]=sort(id);
        hop=hop(index);
        [hplot,id,hop]=rysuj(id, hop, handles);
        zapisz_wykres([id, hop], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet id','number of intermediate nodes forwarding packets', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);