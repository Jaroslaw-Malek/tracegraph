function varargout = id_pak_odrz_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C12 NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C1=='d' & typstart(handles, 6);
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C12(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet drop time [sec]','id of dropped packet', hplot, handles);  
end  
zapisz_wykres_jpg(opis,handles);