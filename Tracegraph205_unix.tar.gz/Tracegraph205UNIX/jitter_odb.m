function varargout = jitter_odb(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C11 AKTWEZ NET HIST DC

HIST=0;
NET=0;
DC=1;
czyscosie;
[czy, opis]=czyopis('seq#', h, eventdata, handles);
if czy==0
    wsp=C1=='r' & C4==AKTWEZ & typstart(handles, 'pakr') & C11~=-1; % number of received packets
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
    else    
        time=C2(wsp);
        seq=C11(wsp);
        s=seq;
        seq=seq(2:end)-seq(1:(end-1));
        if isempty(seq)==0
            seq(seq==0)=1;
            y=time(2:end)-time(1:(end-1));
            y=y./seq;
            s=s(2:end);
            [hplot,s,y]=rysuj(s, y, handles);
            zapisz_wykres([s, y], opis, handles);
        else
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        end
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('sequence number',['jitter of received packet at node ', num2str(AKTWEZ), ' [sec]'], hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);