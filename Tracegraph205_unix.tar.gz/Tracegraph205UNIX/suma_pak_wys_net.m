function varargout = suma_pak_wys_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C7 C8 C9 C13 TRACEFORMAT MAC NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    typ=typstart(handles,0); % packet type
    if TRACEFORMAT==1
        wsp=C1=='-' & C3==C9 & typ & C8~=-2;
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0;
        elseif MAC==1
            wsp4=C1=='s' & C7~=-3;
        end
        wsp=wsp4 & typ & C7~=-1;
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        wsp=C2(wsp);
        l=1:length(wsp);
        [hplot,wsp,l]=rysuj(wsp, l', handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('send event time [sec]','cumulative sum of numbers of sent packets', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);