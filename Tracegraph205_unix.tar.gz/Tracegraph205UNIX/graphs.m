function varargout = graphs(varargin)
% GRAPHS Application M-file for graphs.fig
%    FIG = GRAPHS launch graphs GUI.
%    GRAPHS('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 21-Nov-2002 16:45:25
global CHECK WYKRESY COL CZY3D LICZBAWYK

if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'new');

	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);

	if nargout > 0
		varargout{1} = fig;
	end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		if (nargout)
			[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
		else
			feval(varargin{:}); % FEVAL switchyard
		end
	catch
		disp(lasterr);
	end

end


%| ABOUT CALLBACKS:
%| GUIDE automatically appends subfunction prototypes to this file, and 
%| sets objects' callback properties to call them through the FEVAL 
%| switchyard above. This comment describes that mechanism.
%|
%| Each callback subfunction declaration has the following form:
%| <SUBFUNCTION_NAME>(H, EVENTDATA, HANDLES, VARARGIN)
%|
%| The subfunction name is composed using the object's Tag and the 
%| callback type separated by '_', e.g. 'slider2_Callback',
%| 'figure1_CloseRequestFcn', 'axis1_ButtondownFcn'.
%|
%| H is the callback object's handle (obtained using GCBO).
%|
%| EVENTDATA is empty, but reserved for future use.
%|
%| HANDLES is a structure containing handles of components in GUI using
%| tags as fieldnames, e.g. handles.figure1, handles.slider2. This
%| structure is created at GUI startup using GUIHANDLES and stored in
%| the figure's application data using GUIDATA. A copy of the structure
%| is passed to each callback.  You can store additional information in
%| this structure at GUI startup, and you can change the structure
%| during callbacks.  Call guidata(h, handles) after changing your
%| copy to replace the stored original so that subsequent callbacks see
%| the updates. Type "help guihandles" and "help guidata" for more
%| information.
%|
%| VARARGIN contains any extra arguments you have passed to the
%| callback. Specify the extra arguments by editing the callback
%| property in the inspector. By default, GUIDE sets the property to:
%| <MFILENAME>('<SUBFUNCTION_NAME>', gcbo, [], guidata(gcbo))
%| Add any extra arguments after the last argument, before the final
%| closing parenthesis.

% --------------------------------------------------------------------
function varargout = nwykresy(h, eventdata, handles, varargin)
% nakladanie wykresow on/off
global CHECK WYKRESY COL

if CHECK(3)==0
    set(h, 'Checked', 'on');
    CHECK(3)=1;
    hold on;
elseif CHECK(3)==1 
    set(h, 'Checked', 'off');
    CHECK(3)=0;
    hold off;
end

% --------------------------------------------------------------------
function varargout = autozmwyk(h, eventdata, handles, varargin)
% automatyczna zmiana wykresow
global CHECK

if CHECK(4)==0
    set(h, 'Checked', 'on');
    CHECK(4)=1;
elseif CHECK(4)==1 
    set(h, 'Checked', 'off');
    CHECK(4)=0;
end

% --------------------------------------------------------------
function varargout = usehistint(h, eventdata, handles, varargin)
% wlacza/wylacza uzywanie granic przedzialow histogramow

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');    
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = markgraph(h, eventdata, handles, varargin)
% zaznacza poszczegolne punkty na wykresie

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end

% --------------------------------------------------------------------
function varargout = addminorgrid(h, eventdata, handles, varargin)
% dodaje gesta siatke na wykresie

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
    if strcmp(get(handles.addmajorgrid, 'Checked'), 'on')
        set(handles.addmajorgrid, 'Checked', 'off');
    end
    grid minor;
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
    grid off;
end

% --------------------------------------------------------------------
function varargout = addmajorgrid(h, eventdata, handles, varargin)
% dodaje rzadka siatke na wykresie

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
    if strcmp(get(handles.addminorgrid, 'Checked'), 'on')
        set(handles.addminorgrid, 'Checked', 'off');
        grid off;
    end
    grid on;
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');    
    grid off;
end

% --------------------------------------------------------------------
function varargout = zoomon(h, eventdata, handles, varargin)
% wlacza/wylacza zoom
global CZY3D LICZBAWYK

if strcmp(get(h, 'Checked'), 'off') & LICZBAWYK & CZY3D==0
    set(h, 'Checked', 'on');
    zoom on;
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
    zoom off;
end

% --------------------------------------------------------------------
function varargout = legenda(h, eventdata, handles, varargin)
% wlacza/wylacza legende
global WYKRESY CZY3D LICZBAWYK

if strcmp(get(h, 'Checked'), 'off') & LICZBAWYK & CZY3D==0
    set(h, 'Checked', 'on');
    legend(WYKRESY);
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
    legend off;
end
if strcmp(get(handles.zoomon, 'Checked'),'on')
    zoom on;
end    

% --------------------------------------------------------------------
function varargout = zapisuj_wyk(h, eventdata, handles, varargin)
% wlacza/wylacza zapisywanie wykresow na dysk

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
    odrysuj(h, handles, varargin);
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end

% --------------------------------------------------------------
function varargout = logscalex(h, eventdata, handles, varargin)
% wlacza/wylacza skale logarytmiczna na osi x

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');    
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end
odrysuj(h, handles, varargin);

% --------------------------------------------------------------
function varargout = logscaley(h, eventdata, handles, varargin)
% wlacza/wylacza skale logarytmiczna na osi y

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');    
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end
odrysuj(h, handles, varargin);

% --------------------------------------------------------------
function varargout = logscalez(h, eventdata, handles, varargin)
% wlacza/wylacza skale logarytmiczna na osi z

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');    
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = zapisz_stat_wyk(h, eventdata, handles, varargin)
% wlacza/wylacza zapisywanie statystyk dotyczacych wykresow na dysk

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
    odrysuj(h, handles, varargin);
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end

% --------------------------------------------------------------------
function varargout = figure1_CloseRequestFcn(h, eventdata, handles, varargin)


% --------------------------------------------------------------------
function varargout = xlabel_Callback(h, eventdata, handles, varargin)
xlabel(get(h,'String'));

% --------------------------------------------------------------------
function varargout = ylabel_Callback(h, eventdata, handles, varargin)
ylabel(get(h,'String'));

% --------------------------------------------------------------------
function varargout = tytul_Callback(h, eventdata, handles, varargin)
title(get(h,'String'));

% --------------------------------------------------------------------
function varargout = zlabel_Callback(h, eventdata, handles, varargin)
zlabel(get(h,'String'));