function varargout = events_delay_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST DELAY

DELAY=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('send event time', h, eventdata, handles);
if czy==0
    [opoz,id,stime,tr]=netdel(handles,1);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [hplot,stime,opoz]=rysuj(stime, opoz, handles);
        zapisz_wykres([stime, opoz], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet send time at source node [sec]','End2End delay [sec]' , hplot, handles);
end
DELAY=0;
zapisz_wykres_jpg(opis,handles);