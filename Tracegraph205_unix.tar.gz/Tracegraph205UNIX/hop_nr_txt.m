function varargout = hop_nr_txt(h, eventdata, handles, varargin)
% trgraph
% shows text concerning number of hops between current and other node
global fig

if strcmp(get(handles.hopnr, 'Checked'), 'on')
    set(handles.hopnr, 'Checked', 'off');
    set(handles.frame6, 'Visible', 'off');
    set(handles.avgtext, 'Visible', 'off');
    set(handles.avghoprtxt, 'Visible', 'off');
    set(handles.avghopftxt, 'Visible', 'off');
    set(handles.avghopr, 'Visible', 'off');
    set(handles.avghopf, 'Visible', 'off');
else    
    thandles=guihandles(fig);
    set(thandles.directcon, 'Checked', 'off');
    set(handles.hopnr, 'Checked', 'on');
    hop_nr(handles);
    set(handles.frame6, 'Visible', 'on');
    set(handles.avgtext, 'Visible', 'on');
    set(handles.avghoprtxt, 'Visible', 'on');
    set(handles.avghopftxt, 'Visible', 'on');
    set(handles.avghopr, 'Visible', 'on');
    set(handles.avghopf, 'Visible', 'on');
end