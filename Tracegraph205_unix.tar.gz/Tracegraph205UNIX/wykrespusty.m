function hplot=wykrespusty(handles)
% trgraph
% plots empty graph
global C2

hplot=plot(C2, zeros(length(C2), 1), 'Parent', handles.axes1);