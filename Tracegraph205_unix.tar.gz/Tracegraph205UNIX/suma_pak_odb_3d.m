function suma_pak_odb_3d(h, eventdata, handles, varargin)
% trgraph
global C1 C3 C4 C9 C10 C12 C13 LNOD CZY3D NET HIST TRACEFORMAT MAC IDCOUNT CHECK DC fig

thandles=guihandles(fig);
if CHECK(6)==1
    IDCOUNT=1;
end
HIST=0;
NET=0;
if strcmp(get(thandles.directcon, 'Checked'),'off')
    os={'receive node', 'send node'};
else
    os={'receive node', 'forward node'};
end
CZY3D=1;
DC=1;
hold off;
[czy, opis]=czyopis(os, h, eventdata, handles);
sumy=zeros(LNOD, LNOD);
w=typstart(handles, 1); % only packet type
if TRACEFORMAT==2 & MAC==0
    c13=['end'; C13(1:(end-1),:)];
    c1=['s'; C1(1:(end-1))];
    c4=[-1; C4(1:(end-1))];
    c12=[-1; C12(1:(end-1))];
    w=w & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
end
w=w & C1=='r';
if strcmp(get(thandles.directcon, 'Checked'),'on')
    c3=C3(w);
else
    c9=C9(w);
    c10=C10(w);
end
c4=C4(w);
if isempty(c4)==0
    if CHECK(6)==1
        c12=C12(w);
    end    
    for i=1:LNOD
        for j=1:LNOD
            if i~=j
                if CHECK(6)==1
                    if strcmp(get(thandles.directcon, 'Checked'),'on')
                        sumy(i,j)=length(usunpowt(c12(c4==(i-1) & c3==(j-1))));
                    else
                        sumy(i,j)=length(usunpowt(c12(c4==(i-1) & c9==(j-1) & c10==(i-1))));
                    end
                else    
                    if strcmp(get(thandles.directcon, 'Checked'),'on')
                        sumy(i,j)=sum(c4==(i-1) & c3==(j-1));
                    else
                        sumy(i,j)=sum(c4==(i-1) & c9==(j-1) & c10==(i-1));
                    end
                end
            else
                sumy(i,j)=0;
            end
        end
    end
end    
[h,sumy,y]=rysuj(sumy',1,handles);
title(opis);
set(handles.axes1, 'xTickLabel', 0:LNOD);
set(handles.axes1, 'yTickLabel', 0:LNOD);
rotate3d on;
zoom off;
axis tight;
zapisz_wykres(sumy', opis, handles);
IDCOUNT=0;
DC=0;
xylabel(os{1},os{2},-1, handles);
zapisz_wykres_jpg(opis,handles);