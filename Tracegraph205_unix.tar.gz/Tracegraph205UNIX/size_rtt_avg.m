function varargout = size_rtt_avg(h, eventdata, handles, varargin)
% trgraph
global NET AKTWEZ STARTWEZ HIST fig RTT PAKROZ

thandles=guihandles(fig);
RTT=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % to include ON if CHECK(2)==0
    [czy, opis]=czyopis('sent packet size', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [opoz, id, idr, seqs, stime, tr, roz]=wezrtt(handles,2);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else
            op=zeros(length(PAKROZ),1);
            for i=1:length(PAKROZ)
                m=opoz(roz==PAKROZ(i));
                if isempty(m)==0
                    op(i)=mean(m);
                end
            end    
            [hplot,pr,op]=rysuj(PAKROZ, op, handles);
            zapisz_wykres([pr, op], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel('sent packet size [bytes]',['average RTT between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % to include ON if CHECK(2)==0
    [czy, opis]=czyopis('sent packet size [bytes]', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);
	xylabel('sent packet size [bytes]',['average RTT between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
end
zapisz_wykres_jpg(opis,handles);
RTT=0;