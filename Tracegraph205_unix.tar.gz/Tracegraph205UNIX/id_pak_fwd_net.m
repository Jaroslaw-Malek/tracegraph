function varargout = id_pak_fwd_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C7 C8 C12 TRACEFORMAT NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    typ=typstart(handles, 5);
    if TRACEFORMAT==1
        wsp=C1=='-' & typ & C8~=-2;
    elseif TRACEFORMAT==2
        wsp=C1=='f' & typ & C7~=-2;
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C12(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet forward time [sec]','id of forwarded packet', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);