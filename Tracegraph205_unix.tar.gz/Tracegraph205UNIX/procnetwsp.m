function [pt,wnr,nid,rpak] = procnetwsp(handles,par)
% trgraph
% calculates processing times for the whole network
global C1 C2 C3 C4 C6 C7 C8 C9 C10 C12 TRACEFORMAT PREC PODZIAL

typ=typstart(handles,0); % packet type
wsp=typstart(handles,3);
id=C12(wsp); % IDs of sent packets
l=length(id);
rpr=C1=='r' & typ & C4~=C10; % receiving nodes (not destination ones)
if TRACEFORMAT==1 
    rpf=typ & C1=='-' & C3~=C9 & C8~=-2; % forwarding nodes
elseif TRACEFORMAT==2
    rpf=typstart(handles,5) & C1=='f' & C7~=-2; % omitting drop nodes
end
pt=zeros(sum(rpf), 1)-1; %processing times
wnr=pt; %numbers of forwarding nodes
nid=pt; % packets numbers
in=1; % indexes to pt
if nargin==1
    par=0;
end
if par==3
    rpak=pt; % packets sizes
else
    rpak=[];
end    
c2r=C2(rpr);
c2f=C2(rpf);
c3f=C3(rpf);
c4r=C4(rpr);
c12r=C12(rpr);
c12f=C12(rpf);
if isempty(c12f)==0
    if par==3
        c6=C6(rpf);
    end    
    tr=pt;
    for j=1:l
        fwd=c12f==id(j);
        tfj=c2f(fwd); % forwarding time of packet id(j)
        if isempty(tfj)==0
            nodef=c3f(fwd); % numbers of forwarding nodes
            rec=c12r==id(j);
            noder=c4r(rec); % numbers of receiving nodes
            trj=c2r(rec); % receive events times
            lf=length(nodef);
            lr=length(noder);
            if isempty(trj)==0
                if lf==lr
                    s=length(find(nodef==noder));
                else
                    s=0;
                end
                if s==lf
                    ind=in:(in+s-1);
                    pt(ind)=tfj;
                    tr(ind)=trj;
                    if par==0                
                        wnr(ind)=nodef;
                        nid(ind)=id(j);
                    elseif par==3
                        rpak(ind)=c6(fwd);
                    end
                    in=in+s;
                else
                    if par==3
                        roz=c6(fwd);
                    end    
                    for i=1:lf % for each forwared packet search for it's receive event time
                        for k=1:lr
                            if nodef(i)==noder(k) % if forwarding node fwd=receiving node
                                pt(in)=tfj(i);
                                tr(in)=trj(k); % processing time
                                if par==0
                                    wnr(in)=nodef(i);
                                    nid(in)=id(j);
                                elseif par==3                                
                                    rpak(in)=roz(i);
                                end
                                in=in+1;
                            end
                        end
                    end
                end
            end
        end
    end
    clear c2r c2f c3f c4r c12r c12f;
    if par==1 % receiving time
        nid=tr;
        wnr=[];
    elseif par==2 %forwarding time
        nid=pt;
        wnr=[];
    end    
    pt=pt-tr;
    zero=find(pt>=0);
    pt=pt(zero);
    if par==3
        rpak=rpak(zero);
    end    
    if isempty(wnr)==0
        wnr=wnr(zero);
    end
    nid=nid(zero);
    if par~=0
        [nid,ind]=sort(nid);
        pt=pt(ind);
    end
end    