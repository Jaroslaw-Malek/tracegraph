function varargout = jitter_odrz(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C7 C11 AKTWEZ STARTWEZ NET HIST DC TRACEFORMAT CHECK fig

thandles=guihandles(fig);
HIST=0;
NET=0;
DC=1;
czyscosie;
[czy, opis]=czyopis('seq#', h, eventdata, handles);
if czy==0
    drop=C1=='d' & C3==AKTWEZ;
    if (CHECK(2)==0 & CHECK(1)==0) | (CHECK(1)==1 & CHECK(2)==0)
        wsp=drop & typstart(handles, 'pakd');
    else
        wsp=typstart(handles, 'pakd');
        if TRACEFORMAT==2
            wsp=wsp & drop;
        end
    end
    if TRACEFORMAT==2 & AKTWEZ==STARTWEZ & CHECK(2)
        wsp=drop & C4==STARTWEZ & typstart(handles, 6) & C7==-1;
    end    
    wsp=wsp & C11~=-1;
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
    else    
        time=C2(wsp);
        seq=C11(wsp);
        s=seq;
        seq=seq(2:end)-seq(1:(end-1));
        if isempty(seq)==0
            seq(seq==0)=1;
            y=time(2:end)-time(1:(end-1));
            y=y./seq;
            s=s(2:end);
            [hplot,s,y]=rysuj(s, y, handles);
            zapisz_wykres([s, y], opis, handles);
        else
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        end
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('sequence number',['jitter of dropped packet at node ', num2str(AKTWEZ), ' [sec]'], hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);