function zapisz_wykres(dane,opis,handles)
% trgraph
% saves a graph to a file
global plik CZY3D LNOD katalog PREC

if CZY3D==1
    opis=opis(opis~=10);
    set(handles.tytul, 'String', opis);
end    
if strcmp(get(handles.zapisuj_wyk, 'Checked'), 'on')
    try
        op=strrep(opis,':','_');
        if isempty(findstr(op,10))==0
            op=strrep(op,char(10),' ');
        end
        op=strcat(op,'.trg');
        op=[katalog, plik, '-', op];
        fid=fopen(op,'w');
        pr=['%.',num2str(PREC),'f'];
        if CZY3D==0
            roz=size(dane);
            if roz(2)==1
                fprintf(fid, '%i\n',dane');
            elseif roz(2)==2
                fprintf(fid, [pr,' ',pr,'\n'],dane');
            elseif roz(2)==3
                fprintf(fid, [pr,' ',pr,' ',pr,'\n'],dane');
            end
        elseif CZY3D==1
            x=zeros(1, LNOD*LNOD);
            y=x; z=x;
            for i=0:(LNOD-1)
                for j=0:(LNOD-1)
                    poz=i*LNOD+j+1;
                    x(poz)=i;
                    y(poz)=j;
                    z(poz)=dane(i+1,j+1);
                end
            end
            fprintf(fid, [pr,' ',pr,' ', pr,'\n'],[x;y;z]);
        end
        fclose(fid);
    catch
        disp(lasterr);
        bledy(14);
        fclose('all');
    end   
end
if strcmp(get(handles.zapisz_stat_wyk, 'Checked'), 'on')
    try
        opis=strrep(opis,':','_');
        if isempty(findstr(opis,10))==0
            opis=strrep(opis,char(10),' ');
        end
        opis=strcat(opis,'.trg');
        opis=[katalog, plik, '-STATS-', opis];
        fid=fopen(opis,'w');
        pr=['%.',num2str(PREC),'f'];
        if CZY3D==0
            roz=size(dane);
            if roz(2)==1 | roz(2)==2
                x=dane(:,1);
            end
            if roz(2)==2
                y=dane(:,2);
            end    
        else
            x=zeros(1, LNOD*LNOD);
            y=x; z=x;
            for i=0:(LNOD-1)
                for j=0:(LNOD-1)
                    poz=i*LNOD+j+1;
                    x(poz)=i;
                    y(poz)=j;
                    z(poz)=dane(i+1,j+1);
                end
            end
        end
        fprintf(fid, 'X AXIS VALUES STATISTICS:\n');
        fprintf(fid, ['Minimum: ',pr,'\n'],min(x));
        fprintf(fid, ['Average: ',pr,'\n'],mean(x));
        fprintf(fid, ['Maximum: ',pr,'\n'],max(x));
        fprintf(fid, ['Standard deviation: ',pr,'\n'],std(x));
        fprintf(fid, ['Median: ',pr,'\n'],median(x));
        if CZY3D==1 | (CZY3D==0 & roz(2)==2)
            fprintf(fid, 'Y AXIS VALUES STATISTICS:\n');
            fprintf(fid, ['Minimum: ',pr,'\n'],min(y));
            fprintf(fid, ['Average: ',pr,'\n'],mean(y));
            fprintf(fid, ['Maximum: ',pr,'\n'],max(y));
            fprintf(fid, ['Standard deviation: ',pr,'\n'],std(y));
            fprintf(fid, ['Median: ',pr,'\n'],median(y));        
        end    
        if CZY3D==1
            fprintf(fid, 'Z AXIS VALUES STATISTICS:\n');
            fprintf(fid, ['Minimum: ',pr,'\n'],min(z));
            fprintf(fid, ['Average: ',pr,'\n'],mean(z));
            fprintf(fid, ['Maximum: ',pr,'\n'],max(z));
            fprintf(fid, ['Standard deviation: ',pr,'\n'],std(z));
            fprintf(fid, ['Median: ',pr,'\n'],median(z));
        end    
        fclose(fid);
    catch
        disp(lasterr);
        bledy(14);
        fclose('all');
    end    
end