function varargout = proc_txt(h, eventdata, handles, varargin)
% trgraph
% shows text concerning processing times at current node

if strcmp(get(handles.proc, 'Checked'), 'on')
    set(handles.proc, 'Checked', 'off');
    set(handles.frame8, 'Visible', 'off');
    set(handles.proctxt, 'Visible', 'off');
    set(handles.minproctxt, 'Visible', 'off');
    set(handles.maxproctxt, 'Visible', 'off');
    set(handles.avgproctxt, 'Visible', 'off');
    set(handles.minproc, 'Visible', 'off');
    set(handles.maxproc, 'Visible', 'off');
    set(handles.avgproc, 'Visible', 'off');
else    
    set(handles.proc, 'Checked', 'on');
    proc(handles);
    set(handles.frame8, 'Visible', 'on');
    set(handles.proctxt, 'Visible', 'on');
    set(handles.minproctxt, 'Visible', 'on');
    set(handles.maxproctxt, 'Visible', 'on');
    set(handles.avgproctxt, 'Visible', 'on');
    set(handles.minproc, 'Visible', 'on');
    set(handles.maxproc, 'Visible', 'on');
    set(handles.avgproc, 'Visible', 'on');
end