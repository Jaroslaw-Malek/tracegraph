function osieoff(handles,par)
% trgraph
% set menu on/off in the graphs windows not to save it in a jpeg or tiff file

if par==1 % on
    set(handles.xlabeltxt, 'Visible', 'on');
    set(handles.ylabeltxt, 'Visible', 'on');
    set(handles.zlabeltxt, 'Visible', 'on');
    set(handles.xlabel, 'Visible', 'on');
    set(handles.ylabel, 'Visible', 'on');
    set(handles.zlabel, 'Visible', 'on');    
    set(handles.tytultxt, 'Visible', 'on');
    set(handles.tytul, 'Visible', 'on');
elseif par==0 % off
    set(handles.xlabeltxt, 'Visible', 'off');
    set(handles.ylabeltxt, 'Visible', 'off');
    set(handles.zlabeltxt, 'Visible', 'off');
    set(handles.xlabel, 'Visible', 'off');
    set(handles.ylabel, 'Visible', 'off');
    set(handles.zlabel, 'Visible', 'off');
    set(handles.tytultxt, 'Visible', 'off');
    set(handles.tytul, 'Visible', 'off');
end    