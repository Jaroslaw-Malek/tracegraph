function varargout = hopnet_nr(handles)
% trgraph
% shows information about number of hops in the whole network
global PREC

[hopr, hopf,id,st,rt]=nethop(handles,0);
if isempty(hopr)
    set(handles.avgnethopr, 'String', 'N/A');
else
    hopr=sum(hopr)/length(hopr);
    set(handles.avgnethopr, 'String', num2str(hopr,PREC));
end
if isempty(hopf)
    set(handles.avgnethopf, 'String', 'N/A'); 
else     
    hopf=sum(hopf)/length(hopf);
    set(handles.avgnethopf, 'String', num2str(hopf,PREC)); 
end   
zapisz_info(handles);