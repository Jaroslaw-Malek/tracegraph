function varargout = feventr_hop_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST TRACEFORMAT

HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('receive event time', h, eventdata, handles);
if czy==0
    [hopr, hop, id, stime, tr]=nethop(handles,2);
    if isempty(hop)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else        
        [tr,i]=sort(tr);
        hop=hop(i);
        [hplot,tr,hop]=rysuj(tr, hop, handles);
        zapisz_wykres([tr, hop], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet receive time at destination node [sec]','number of intermediate nodes forwarding packets', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);