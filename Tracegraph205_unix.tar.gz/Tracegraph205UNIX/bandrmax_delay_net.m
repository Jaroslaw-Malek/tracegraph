function varargout = bandrmax_delay_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C6 C10 NET HIST BANDI DELAY

DELAY=1;
HIST=0;
NET=1; % whole network
czyscosie;
x={'throughput', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    typ=typstart(handles,0); % packet type
    r=C1=='r' & C4==C10 & typ;
    c2=C2(r);
    c6=C6(r);
    opoz=[];
    if isempty(c2)==0    
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        op=zeros(roz, 1);
        band=op;
        band(1)=sum(c6(c2<=czas(1)))*8;
        for i=2:roz
            band(i)=sum(c6(c2>czas(i-1) & c2<=czas(i)))*8;
        end
        [opoz,id,stime,tr]=netdel(handles,1);
        o=opoz(tr>0 & tr<=czas(1));
        if isempty(o)
            op(1)=0;
        else
            op(1)=max(o);
        end    
        for i=2:roz
            o=opoz(tr>czas(i-1) & tr<=czas(i));
            if isempty(o)
                op(i)=0;
            else
                op(i)=max(o);
            end
        end
        opoz=op;
    end    
    if sum(opoz)==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        HIST=2; % empty graph
    else
        [band, index]=sort(band);
        opoz=opoz(index);
        index=find(opoz>0); % removing delays equal zero
        opoz=opoz(index);
        band=band(index);
        bnd=usunpowt(band);
        op=zeros(length(bnd),1);
        for i=1:length(bnd)
            m=max(opoz(band==bnd(i)));
            if isempty(m)==0
                op(i)=m;
            end    
        end    
	[hplot,bnd,op]=rysuj(bnd, op,handles);
        zapisz_wykres([bnd, op], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('throughput of receiving bits [bits/TIL]','maximal End2End delay [sec]', hplot, handles);
end
DELAY=0;
zapisz_wykres_jpg(opis,handles);