function varargout = jitter_id_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST DELAY

DELAY=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('packet id', h, eventdata, handles);
if czy==0    
    [opoz, id,st,rt]=netdel(handles,0);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        id=id(1:(end-1));
        [id, index]=sort(id);
        opoz=abs(opoz(2:end)-opoz(1:(end-1))); % jitter(i)=abs((r(i+1)-s(i+1))-(r(i)-s(i)))
        opoz=opoz(index);
        [hplot,id,opoz]=rysuj(id, opoz, handles);
        zapisz_wykres([id, opoz], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet id','jitter [sec]' , hplot, handles);
end
DELAY=0;
zapisz_wykres_jpg(opis,handles);