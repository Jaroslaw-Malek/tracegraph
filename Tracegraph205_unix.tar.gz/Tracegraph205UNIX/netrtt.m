function [rtt, ids, idr, seqs, stime, rtime, rozs]=netrtt(handles,par)  
% trgraph
% calculates RTTs for the whole network
global C2 C9 C10 C6 C11 C12 PODZIAL RTT CHECK

RTT=1;
NET=1;
rtt=[];
ids=[];
idr=[];
stime=[];
rtime=[];
rozs=[];     
sent=typstart(handles,'sent'); % sent packets types
ack=typstart(handles,'ack'); % ack packets
seqs=C11(sent); % sequence numbers of sent packets
seqr=C11(ack); % sequence numbers of received packets
stime=C2(sent); % sent events times
ids=C12(sent); % IDs of sent packets
c9s=C9(sent);
c10s=C10(sent);
wsp=seqs>=0; % where is no seq#
seqs=seqs(wsp);
stime=stime(wsp);
ids=ids(wsp);
c9s=c9s(wsp);
c10s=c10s(wsp);
if par==2 % sent packets sizes
    rozs=C6(sent);
    rozs=rozs(wsp);
end    

r=C2(ack); % receive events times of ack packets
idr=C12(ack); % id ack
c9r=C9(ack);
c10r=C10(ack);
wsp=seqr>=0; % where is no seq# of ack packets
seqr=seqr(wsp);
r=r(wsp);
idr=idr(wsp);
c9r=c9r(wsp);
c10r=c10r(wsp);

l=length(stime);
if l        
    seqstmp=zeros(l,1)-1; % list of processed sequence numbers
    tr=[];
    c2=r; % ack packets receive times
    c11=seqr; % seq # ack
    rtt=zeros(l,1);
    dl=length(c2);
    if dl~=0
        n=ceil(dl/PODZIAL); dl=floor(dl/n);
        poz=1;
        for p=1:n
            if p==n
                wsp=poz:length(c2);
            else
                wsp=poz:(poz+dl-1);
            end
            c2p=c2(wsp);
            c9rp=c9r(wsp); % ack source
            c10rp=c10r(wsp); % ack destination
            c11p=c11(wsp);        
            for i=1:l                
                if isempty(find(seqs(i)==seqstmp))
                    tr=c2p(c11p==seqs(i) & c9rp==c10s(i) & c10rp==c9s(i)); % receive events times of ack seqs(i)
                    if isempty(tr)==0 & rtt(i)==0
                        rtt(i)=tr(1);
                        seqstmp(i)=seqs(i);
                    end
                end    
            end
            poz=poz+dl;
        end
        clear c2 c11 c9s c10s c9r c10r c2p c9rp c10rp c11p wsp;
        if par==1
            rtime=rtt;
        else
            rtime=[];
        end
        rtt=rtt-stime;
        opnr=find(rtt>0);
        rtt=rtt(opnr);
        ids=ids(opnr);
        seqs=seqs(opnr);
        if par==1
            stime=stime(opnr);
            rtime=rtime(opnr);
        elseif par==2
            rozs=rozs(opnr);
        end            
    end        
end