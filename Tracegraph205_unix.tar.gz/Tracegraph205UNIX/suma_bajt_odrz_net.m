function varargout = suma_bajt_odrz_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C6 C7 AKTWEZ STARTWEZ CHECK TRACEFORMAT TSTART TEND NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C1=='d' & typstart(handles, 6);
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        x=C2(wsp);
        y=cumsum(C6(wsp));
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('drop event time [sec]','cumulative sum of dropped bytes', hplot, handles);   
end 
zapisz_wykres_jpg(opis,handles);