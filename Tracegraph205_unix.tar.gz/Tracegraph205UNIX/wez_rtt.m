function wez_rtt(handles)
% trgraph
% shows RTTs between 2 nodes
global PREC RTT

RTT=1;
[rtt, ids, idr, seqs, stime, rtime, rozs]=wezrtt(handles,0);
if isempty(rtt)==0
    [mind,i]=min(rtt);
    minid=ids(i);
    [maxd,i]=max(rtt);
    maxid=ids(i);
    avgd=mean(rtt);                      
    set(handles.aktminrtt, 'String', [num2str(mind,PREC),' (',num2str(minid),')']);
    set(handles.aktmaxrtt, 'String', [num2str(maxd,PREC),' (',num2str(maxid),')']);
    set(handles.aktavgrtt, 'String', num2str(avgd,PREC));
else
    set(handles.aktminrtt, 'String', 'N/A');
    set(handles.aktmaxrtt, 'String', 'N/A');
    set(handles.aktavgrtt, 'String', 'N/A');
end
zapisz_info(handles);
RTT=0;