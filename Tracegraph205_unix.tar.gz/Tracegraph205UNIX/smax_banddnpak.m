function varargout = smax_banddnpak(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C6 C7 C8 C12 AKTWEZ TRACEFORMAT BANDI NET HIST CHECK IDCOUNT PAKROZ

if CHECK(6)==1
    IDCOUNT=1;
end
HIST=0;
NET=1;
czyscosie;
x={'packet size', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    wsp=C1=='d' & typstart(handles, 6);
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        c2=C2(wsp);
        c6=C6(wsp);
        c12=C12(wsp);
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        bwd=zeros(length(PAKROZ),1);
        band=zeros(roz, 1);
        for p=1:length(PAKROZ)
            if CHECK(6)==1
                band(1)=length(usunpowt(c12(c2<=czas(1) & c6==PAKROZ(p))));
            else
                band(1)=sum(c2<=czas(1) & c6==PAKROZ(p));
            end            
            for i=2:roz
                if CHECK(6)==1
                    band(i)=length(usunpowt(c12(c2>czas(i-1) & c2<=czas(i) & c6==PAKROZ(p))));
                else
                    band(i)=sum(c2>czas(i-1) & c2<=czas(i) & c6==PAKROZ(p));
                end                
            end
            bwd(p)=max(band);
        end    
        [hplot,pr,bwd]=rysuj(PAKROZ, bwd, handles);
        zapisz_wykres([pr, bwd], opis, handles);     
    end
    plot_info(opis, eventdata, hplot, handles);
    xylabel('packet size [bytes]', 'maximal throughput of dropping packets [max No. of Packets/TIL]', hplot, handles);
end
IDCOUNT=0;
zapisz_wykres_jpg(opis,handles);