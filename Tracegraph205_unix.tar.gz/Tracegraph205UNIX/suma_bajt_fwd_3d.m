function suma_bajt_fwd_3d(h, eventdata, handles, varargin)
% trgraph
global C1 C3 C4 C6 C7 C8 C9 LNOD CZY3D TRACEFORMAT NET HIST

HIST=0;
NET=0;
os={'forward node', 'receive node'};
CZY3D=1;
hold off;
[czy, opis]=czyopis(os, h, eventdata, handles);
sumy=zeros(LNOD, LNOD);
w=typstart(handles, 15); % only packet type and forward
if TRACEFORMAT==1
    w=w & C1=='-' & C8~=-2;
    c4=C4(w);
elseif TRACEFORMAT==2
    w=w & C1=='f';
    c7=C7(w);
end
c3=C3(w);
if isempty(c3)==0
    c6=C6(w);
    for i=1:LNOD
        for j=1:LNOD
            if i~=j
                if TRACEFORMAT==1
                    wsp=c3==(i-1) & c4==(j-1);
                elseif TRACEFORMAT==2
                    wsp=c3==(i-1) & c7==(j-1);
                end
                sumy(i,j)=sum(c6(wsp));
            else
                sumy(i,j)=0;
            end
        end
    end
end    
[h,sumy,y]=rysuj(sumy',1,handles);
title(opis);
set(handles.axes1, 'xTickLabel', 0:LNOD);
set(handles.axes1, 'yTickLabel', 0:LNOD);
rotate3d on;
zoom off;
axis tight;
zapisz_wykres(sumy', opis, handles);
xylabel(os{1},os{2},-1, handles);
zapisz_wykres_jpg(opis,handles);