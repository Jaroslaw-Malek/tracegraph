function varargout = eventr_rtt(h, eventdata, handles, varargin)
% trgraph
global NET AKTWEZ STARTWEZ HIST RTT fig

thandles=guihandles(fig);
RTT=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('ACK receive time', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [opoz, id, idr, seqs, stime, tr, rozs]=wezrtt(handles,1);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else            
            [tr,i]=sort(tr);
            opoz=opoz(i);
            [hplot,tr,opoz]=rysuj(tr, opoz, handles);
            zapisz_wykres([tr, opoz], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['ACK packet receive time at node ', num2str(AKTWEZ), ' [sec]'],['RTT between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ), ' [sec]'], hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('ACK receive time', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);	
	xylabel(['ACK packet receive time at node ', num2str(AKTWEZ), ' [sec]'],['RTT between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ), ' [sec]'], hplot, handles);
    end
end
zapisz_wykres_jpg(opis,handles);
RTT=0;