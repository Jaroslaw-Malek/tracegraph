function zapisz_info(handles)
% trgraph
% saves network information to files
global plik katalog AKTWEZ STARTWEZ CHECK TSTART TEND PREC PAKIETY pole
global fig sfig FLOWID TRACEFORMAT DELAY TRACELEVEL PAKROZ rozpak RTT

thandles=guihandles(fig);
handles=guihandles(sfig);
if strcmp(get(handles.zapisuj_info, 'Checked'), 'on')
    if CHECK(1)==1        
        opis=' PT_';
        o=[];
        for i=1:length(PAKIETY)
            pak=PAKIETY{i};
            pak=pak(pak~=' ');
            if isempty(findstr(pole, ['-',pak]))
                o=[o, [pak,' ']];
            end
        end
        if isempty(o)
            o='empty';
        else
            o=o(1:(end-1));
        end
        pak=[opis,o];
    else
        pak=[];
    end
    if strcmp(get(thandles.directcon, 'Checked'), 'on')
        dc=' DC';
    else
        dc=[];
    end
    if TRACEFORMAT==1 & strcmp(get(thandles.flowidoption, 'Checked'),'on')
        flowid=[' FID_',num2str(FLOWID)];
    else
        flowid=[];
    end    
    if strcmp(get(thandles.liczpakietraz, 'Checked'), 'on')
        idx1=' IDx1';
    else
        idx1=[];
    end
    aktw=num2str(AKTWEZ);
    if CHECK(2)==1
        iw=[' ON_',num2str(STARTWEZ)];
    else
        iw=[];
    end
    if strcmp(get(thandles.timeint, 'Checked'), 'on')
        ts=[' ST_', num2str(TSTART,PREC)];
        te=[' ET_', num2str(TEND,PREC)];
    else
        ts=[];
        te=[];
    end
    if TRACEFORMAT==2 & (DELAY==1 | RTT==1)
        stl=[' STL_', TRACELEVEL{get(thandles.stracelevel, 'Value')}];
        dtl=[' DTL_', TRACELEVEL{get(thandles.dtracelevel, 'Value')}];
    else
        stl=[];
        dtl=[];
    end
    if CHECK(8)==1 %turbo
        tm=' TM';
    else
        tm=[];
    end
    if RTT==1
        pk=char(PAKIETY{get(thandles.sentpkt, 'Value')});
        pk=pk(pk~=' ');
        spak=[' SPAK_', pk];      
        pk=char(PAKIETY{get(thandles.ackpkt, 'Value')});
        pk=pk(pk~=' ');
        ack=[' ACK_', pk];
    else
        spak=[];
        ack=[];
    end    
    if CHECK(7)==1
        opis=' PS_';
        o=[];
        for i=1:length(PAKROZ)
            if isempty(findstr(rozpak, ['-',num2str(PAKROZ(i))]))
                o=[o, [num2str(PAKROZ(i)),' ']];
            end
        end
        if isempty(o)
            o='empty';
        else
            o=o(1:(end-1));
        end
        paksize=[opis,o];
    else
        paksize=[];
    end
    if strcmp(get(handles.syminfo, 'Checked'), 'on')
        opis=[katalog,plik,'-Simulation info',pak,ts,te,flowid,idx1,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.text1, 'String'));
        fprintf(fid,'%s\n',get(handles.tmax, 'String'));
        fprintf(fid,'%s ',get(handles.text2, 'String'));
        fprintf(fid,'%s\n',get(handles.lnod, 'String'));
        fprintf(fid,'%s ',get(handles.text3, 'String'));
        fprintf(fid,'%s\n',get(handles.lnad, 'String'));
        fprintf(fid,'%s ',get(handles.text4, 'String'));
        fprintf(fid,'%s\n',get(handles.lodb, 'String'));
        fprintf(fid,'%s ',get(handles.nofgp, 'String'));
        fprintf(fid,'%s\n',get(handles.lpakg, 'String'));
        fprintf(fid,'%s ',get(handles.text5, 'String'));
        fprintf(fid,'%s\n',get(handles.lpak, 'String'));
        fprintf(fid,'%s ',get(handles.nofp, 'String'));
        fprintf(fid,'%s\n',get(handles.lpakf, 'String'));
        fprintf(fid,'%s ',get(handles.text9, 'String'));
        fprintf(fid,'%s\n',get(handles.lpakd, 'String'));
        fprintf(fid,'%s ',get(handles.nolp, 'String'));
        fprintf(fid,'%s\n',get(handles.lpakl, 'String'));
        fprintf(fid,'%s ',get(handles.text10, 'String'));
        fprintf(fid,'%s\n',get(handles.minpak, 'String'));
        fprintf(fid,'%s ',get(handles.text11, 'String'));
        fprintf(fid,'%s\n',get(handles.maxpak, 'String'));
        fprintf(fid,'%s ',get(handles.text12, 'String'));
        fprintf(fid,'%s\n',get(handles.srpak, 'String'));
        fprintf(fid,'%s ',get(handles.text49, 'String'));
        fprintf(fid,'%s\n',get(handles.bajts, 'String'));
        fprintf(fid,'%s ',get(handles.nofb, 'String'));
        fprintf(fid,'%s\n',get(handles.bajtf, 'String'));
        fprintf(fid,'%s ',get(handles.slob, 'String'));
        fprintf(fid,'%s\n',get(handles.bajtd, 'String'));
        fprintf(fid,'%s ',get(handles.wop, 'String'));
        fprintf(fid,'%s\n',get(handles.wezlyd, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.wezinfo, 'Checked'), 'on')
        opis=[katalog,plik,'-node ',aktw,' info',iw,pak,ts,te,dc,flowid,idx1,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.aktnogp, 'String'));
        fprintf(fid,'%s\n',get(handles.aktlpakg, 'String'));
        fprintf(fid,'%s ',get(handles.text32, 'String'));
        fprintf(fid,'%s\n',get(handles.aktlpak, 'String'));
        fprintf(fid,'%s ',get(handles.aktnofp, 'String'));
        fprintf(fid,'%s\n',get(handles.aktlpakf, 'String'));
        fprintf(fid,'%s ',get(handles.text33, 'String'));
        fprintf(fid,'%s\n',get(handles.aktlpakr, 'String'));
        fprintf(fid,'%s ',get(handles.text36, 'String'));
        fprintf(fid,'%s\n',get(handles.aktlpakd, 'String'));
        fprintf(fid,'%s ',get(handles.aktnolp, 'String'));
        fprintf(fid,'%s\n',get(handles.aktlpakl, 'String'));
        fprintf(fid,'%s ',get(handles.text37, 'String'));
        fprintf(fid,'%s\n',get(handles.aktbajts, 'String'));
        fprintf(fid,'%s ',get(handles.aktnofb, 'String'));
        fprintf(fid,'%s\n',get(handles.aktbajtf, 'String'));
        fprintf(fid,'%s ',get(handles.text38, 'String'));
        fprintf(fid,'%s\n',get(handles.aktbajtr, 'String'));
        fprintf(fid,'%s ',get(handles.lob, 'String'));
        fprintf(fid,'%s\n',get(handles.aktbajtd, 'String'));
        fprintf(fid,'%s ',get(handles.text54, 'String'));
        fprintf(fid,'%s\n',get(handles.aktminpak, 'String'));
        fprintf(fid,'%s ',get(handles.text55, 'String'));
        fprintf(fid,'%s\n',get(handles.aktmaxpak, 'String'));
        fprintf(fid,'%s ',get(handles.text56, 'String'));
        fprintf(fid,'%s\n',get(handles.aktsrpak, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.simdelays, 'Checked'), 'on')
        opis=[katalog,plik,'-Simulation end2end delays',pak,stl,dtl,ts,te,flowid,tm,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.mind, 'String'));
        fprintf(fid,'%s\n',get(handles.mindinfo, 'String'));
        fprintf(fid,'%s ',get(handles.maxd, 'String'));
        fprintf(fid,'%s\n',get(handles.maxdinfo, 'String'));
        fprintf(fid,'%s ',get(handles.avgd, 'String'));
        fprintf(fid,'%s\n',get(handles.avgdinfo, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.nodedelays, 'Checked'), 'on')
        opis=[katalog,plik,'-Delays between node ',aktw,' and node ',num2str(STARTWEZ),pak,stl,dtl,ts,te,dc,flowid,tm,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.aktmind, 'String'));
        fprintf(fid,'%s\n',get(handles.aktmindinfo, 'String'));
        fprintf(fid,'%s ',get(handles.aktmaxd, 'String'));
        fprintf(fid,'%s\n',get(handles.aktmaxdinfo, 'String'));
        fprintf(fid,'%s ',get(handles.aktavgd, 'String'));
        fprintf(fid,'%s\n',get(handles.aktavgdinfo, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.hopnetnr, 'Checked'), 'on')
        opis=[katalog,plik,'-Average number of intermediate nodes for the whole network ',pak,ts,te,flowid,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.avgnethoprtxt, 'String'));
        fprintf(fid,'%s\n',get(handles.avgnethopr, 'String'));
        fprintf(fid,'%s ',get(handles.avgnethopftxt, 'String'));
        fprintf(fid,'%s\n',get(handles.avgnethopf, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.hopnr, 'Checked'), 'on')
        opis=[katalog,plik,'-Average number of intermediate nodes between node ',aktw,' and node ',num2str(STARTWEZ),pak,ts,te,flowid,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.avghoprtxt, 'String'));
        fprintf(fid,'%s\n',get(handles.avghopr, 'String'));
        fprintf(fid,'%s ',get(handles.avghopftxt, 'String'));
        fprintf(fid,'%s\n',get(handles.avghopf, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.netproc, 'Checked'), 'on')
        opis=[katalog,plik,'-Simulation processing times at intermediate nodes',pak,ts,te,flowid,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.minprocnettxt, 'String'));
        fprintf(fid,'%s\n',get(handles.minprocnet, 'String'));
        fprintf(fid,'%s ',get(handles.maxprocnettxt, 'String'));
        fprintf(fid,'%s\n',get(handles.maxprocnet, 'String'));
        fprintf(fid,'%s ',get(handles.avgprocnettxt, 'String'));
        fprintf(fid,'%s\n',get(handles.avgprocnet, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.proc, 'Checked'), 'on')
        opis=[katalog,plik,'-Processing times at node ',aktw,iw,pak,ts,te,flowid,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.minproctxt, 'String'));
        fprintf(fid,'%s\n',get(handles.minproc, 'String'));
        fprintf(fid,'%s ',get(handles.maxproctxt, 'String'));
        fprintf(fid,'%s\n',get(handles.maxproc, 'String'));
        fprintf(fid,'%s ',get(handles.avgproctxt, 'String'));
        fprintf(fid,'%s\n',get(handles.avgproc, 'String'));
        fclose(fid);
    end
    if strcmp(get(handles.net_rtt,'Checked'),'on')
        opis=[katalog,plik,'-Simulation RTT ',ts,te,flowid,stl,dtl,spak,ack,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.minrtttxt, 'String'));
        fprintf(fid,'%s\n',get(handles.minrtt, 'String'));
        fprintf(fid,'%s ',get(handles.maxrtttxt, 'String'));
        fprintf(fid,'%s\n',get(handles.maxrtt, 'String'));
        fprintf(fid,'%s ',get(handles.avgrtttxt, 'String'));
        fprintf(fid,'%s\n',get(handles.avgrtt, 'String'));
        fclose(fid);
    end    
    if strcmp(get(handles.wez_rtt,'Checked'),'on')
        opis=[katalog,plik,'-RTT between node ',aktw,' and node ',num2str(STARTWEZ),ts,te,flowid,stl,dtl,spak,ack,paksize,'.trg'];
        fid=fopen(opis,'w');
        fprintf(fid,'%s ',get(handles.aktminrtttxt, 'String'));
        fprintf(fid,'%s\n',get(handles.aktminrtt, 'String'));
        fprintf(fid,'%s ',get(handles.aktmaxrtttxt, 'String'));
        fprintf(fid,'%s\n',get(handles.aktmaxrtt, 'String'));
        fprintf(fid,'%s ',get(handles.aktavgrtttxt, 'String'));
        fprintf(fid,'%s\n',get(handles.aktavgrtt, 'String'));
        fclose(fid);
    end    
end