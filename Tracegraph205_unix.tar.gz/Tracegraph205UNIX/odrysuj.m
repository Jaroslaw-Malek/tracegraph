function odrysuj(h, handles, varargin)
% trgraph
% refreshes graphs if CHECK(4)=1 - automatic graphs change
global CHECK WYKRESY WYKRESTAG LICZBAWYK WYKRESLAB IND COL TMPWYKRESTAG TMPWYKRESLAB CZY3D
global ghandles

biez=gcf;
if LICZBAWYK>0 & CHECK(4)
    axes(ghandles.axes1);
    cla reset;    
    if CHECK(3) & LICZBAWYK>1
        WYKRESY=cell(1);
        TMPWYKRESTAG=cell(1);
        TMPWYKRESLAB=cell(1);
        IND=1;
        hold on;
        for i=1:LICZBAWYK
            w={char(WYKRESLAB(i)), i};
            feval(char(WYKRESTAG(i)), h, w, ghandles, varargin);
        end
        COL=IND;
        LICZBAWYK=IND-1;
        WYKRESTAG=TMPWYKRESTAG;
        WYKRESLAB=TMPWYKRESLAB;
        legend(WYKRESY);
    elseif LICZBAWYK==1
        if CHECK(3) & CZY3D==0
            hold on;
        end
        IND=1;
        feval(char(WYKRESTAG(1)), h, WYKRESLAB(1), ghandles, varargin);
        if CZY3D==0
            legend(WYKRESY);
        end
    end
end
if CZY3D~=1
    zoom on;
end
figure(biez);