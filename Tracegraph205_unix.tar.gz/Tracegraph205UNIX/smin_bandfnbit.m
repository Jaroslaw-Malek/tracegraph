function varargout = smin_bandfnbit(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C6 C7 C8 AKTWEZ TRACEFORMAT BANDI NET HIST PAKROZ

HIST=0;
NET=1;
czyscosie;
x={'packet size', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    typ=typstart(handles, 5); % if MAC=1
    if TRACEFORMAT==1
        wsp=C1=='-' & typ & C8~=-2;
    elseif TRACEFORMAT==2
        wsp=C1=='f' & typ & C7~=-2;
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        c2=C2(wsp);
        c6=C6(wsp);
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        bwd=zeros(length(PAKROZ),1);
        band=zeros(roz, 1);
        for p=1:length(PAKROZ)
            band(1)=sum(c6(c2<=czas(1) & c6==PAKROZ(p)))*8;
            for i=2:roz
                band(i)=sum(c6(c2>czas(i-1) & c2<=czas(i) & c6==PAKROZ(p)))*8;
            end
            m=min(band(band~=0));
            if isempty(m)==0
                bwd(p)=m;
            end
        end    
        [hplot,pr,bwd]=rysuj(PAKROZ, bwd, handles);
        zapisz_wykres([pr, bwd], opis, handles);     
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet size [bytes]', 'minimal throughput of forwarding bits [min No. of bits/TIL]', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);