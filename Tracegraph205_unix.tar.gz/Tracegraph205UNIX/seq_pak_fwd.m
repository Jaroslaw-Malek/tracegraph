function varargout = seq_pak_fwd(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C8 C11 AKTWEZ TRACEFORMAT NET HIST

HIST=0;
NET=0;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C11~=-1;
    if TRACEFORMAT==1
        wsp=wsp & C1=='-' & C3==AKTWEZ & C8~=-2 & typstart(handles, 'pakf');
    elseif TRACEFORMAT==2
        wsp=wsp & C1=='f' & C3==AKTWEZ & typstart(handles, 'pakf');
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C11(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet forward time [sec]',['sequence number of forwarded packet at node ', num2str(AKTWEZ)], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);