function varargout = suma_pak_fwd(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C8 AKTWEZ TRACEFORMAT NET HIST

HIST=0;
NET=0;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    if TRACEFORMAT==1
        wsp=C1=='-' & C3==AKTWEZ & C8~=-2 & typstart(handles, 'pakf');
    elseif TRACEFORMAT==2
        wsp=C1=='f' & C3==AKTWEZ & typstart(handles, 'pakf');
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        wsp=C2(wsp);
        l=1:length(wsp);
        [hplot,wsp,l]=rysuj(wsp, l', handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('forward event time [sec]',['cumulative sum of numbers of forwarded packets at node ', num2str(AKTWEZ)], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);