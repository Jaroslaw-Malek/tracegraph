function suma_bajt_odrz_3d(h, eventdata, handles, varargin)
% trgraph
global C1 C3 C4 C6 C8 C9 LNOD CZY3D TRACEFORMAT NET HIST DC fig

thandles=guihandles(fig);
HIST=0; 
NET=0;
DC=1;
if strcmp(get(thandles.directcon, 'Checked'),'off')
    os={'receive and drop node', 'send node'};
else
    os={'receive and drop node', 'forward node'};
end
CZY3D=1;
hold off;
[czy, opis]=czyopis(os, h, eventdata, handles);
sumy=zeros(LNOD, LNOD);
w=typstart(handles, 6); % only packet type and drop= 6
w=w & C1=='d';
c3=C3(w);
if isempty(c3)==0
    c6=C6(w);
    if TRACEFORMAT==1 
        if strcmp(get(thandles.directcon, 'Checked'),'on')
            c8=C8(w);
        else
            c9=C9(w);
        end
    elseif TRACEFORMAT==2
        if strcmp(get(thandles.directcon, 'Checked'),'on')
            c4=C4(w);
        else
            c9=C9(w);
        end
    end    
    for i=1:LNOD
        for j=1:LNOD
            c=c3==(i-1);
            if TRACEFORMAT==1 
                if strcmp(get(thandles.directcon, 'Checked'),'on')
                    sumy(i,j)=sum(c6(c & c8==(j-1)));
                else
                    sumy(i,j)=sum(c6(c & c9==(j-1)));
                end
            elseif TRACEFORMAT==2
                if strcmp(get(thandles.directcon, 'Checked'),'on')
                    sumy(i,j)=sum(c6(c & c4==(j-1)));
                else
                    sumy(i,j)=sum(c6(c & c9==(j-1)));
                end
            end    
        end
    end
end    
[h,sumy,y]=rysuj(sumy',1,handles);
title(opis);
set(handles.axes1, 'xTickLabel', 0:LNOD);
set(handles.axes1, 'yTickLabel', 0:LNOD);
rotate3d on;
zoom off;
axis tight;
zapisz_wykres(sumy', opis, handles);
DC=0;
xylabel(os{1},os{2},-1, handles);
zapisz_wykres_jpg(opis,handles);