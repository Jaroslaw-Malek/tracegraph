function varargout = wez_info1(handles)
% trgraph
% current node information
global C1 C2 C3 C4 C6 C7 C8 C9 C12 C13
global AKTWEZ STARTWEZ CHECK TRACEFORMAT MAC TSTART TEND
global fig FLOWID FID
thandles=guihandles(fig);

wsp1=C1=='r' & C4==AKTWEZ & typstart(handles, 'pakr');
drop=C1=='d' & C3==AKTWEZ;
if TRACEFORMAT==1
    wsp21=C1=='-' & C3==AKTWEZ & C8~=-2; 
    wsp2=wsp21 & C9==AKTWEZ & typstart(handles, 'paks');
    wsp3=wsp21 & typstart(handles, 'pakf');
    aktlpakg=sum(C1=='+' & C3==AKTWEZ & C9==AKTWEZ & typstart(handles, 'pakg'));
    aktlpak=sum(wsp2);
    aktbajts=sum(C6(wsp2));
    sr=C6(wsp1 | wsp2 | wsp3);
elseif TRACEFORMAT==2
    wsp3=C1=='f' & C3==AKTWEZ & typstart(handles, 'pakf');
    if MAC==0
        wsp4=send_mac_0 & C3==AKTWEZ;
    elseif MAC==1
        wsp4=C1=='s' & C3==AKTWEZ & C13(:,1)=='M';
    end
    wsp5=typstart(handles, 'paks');
    aktlpakg=sum(wsp4 & typstart(handles, 'pakg'));
    s1=wsp4 & wsp5 & C7~=-1;
    aktlpak=sum(s1);
    aktbajts=sum(C6(s1));
    sr=C6(wsp1 | s1 | wsp3);
end
if CHECK(6)==1
    aktlpakf=length(usunpowt(C12(wsp3)));
    aktlpakr=length(usunpowt(C12(wsp1)));
else   
    aktlpakf=sum(wsp3);
    aktlpakr=sum(wsp1);
end
if (CHECK(2)==0 & CHECK(1)==0) | (CHECK(1)==1 & CHECK(2)==0)
    drop=drop & typstart(handles, 'pakd');
    if CHECK(6)==1
        aktlpakd=length(usunpowt(C12(drop)));
    else
        aktlpakd=sum(drop);
    end
    aktbajtd=sum(C6(drop));
else
    w=typstart(handles, 'pakd');
    if TRACEFORMAT==2
        w=w & drop;
    end
    if CHECK(6)==1
        aktlpakd=length(usunpowt(C12(w)));
    else
        aktlpakd=sum(w);
    end
    aktbajtd=sum(C6(find(w)));
end
if TRACEFORMAT==2 & AKTWEZ==STARTWEZ & CHECK(2)
    c=drop & C4==STARTWEZ & typstart(handles, 6) & C7==-1;
    if CHECK(6)==1
        aktlpakd=length(usunpowt(C12(c)));
    else
        aktlpakd=sum(c);
    end
    aktbajtd=sum(C6(c));
    sr=C6(c);
end    
aktbajtf=sum(C6(wsp3));
aktbajtr=sum(C6(wsp1));
if CHECK(2)==1 & AKTWEZ~=STARTWEZ % other node
    akt=AKTWEZ;
    AKTWEZ=STARTWEZ;
    STARTWEZ=akt;
    odb=C1=='r' & C4==AKTWEZ & typstart(handles, 'pakr');
    if strcmp(get(thandles.directcon, 'Checked'),'on')
        aktlpakl=aktlpakf-sum(odb);
    else
        aktlpakl=aktlpak-sum(odb);
    end
    akt=AKTWEZ;
    AKTWEZ=STARTWEZ;
    STARTWEZ=akt;
else 
    aktlpakl=0;
end
if aktlpakl<0
    aktlpakl=0;
end
if isempty(sr)
    aktminpak=0;
    aktmaxpak=0;
    aktsrpak=0;
else 
    aktminpak=min(sr);
    aktmaxpak=max(sr);
    aktsrpak=sum(sr)/length(sr);
end
if CHECK(2)==1 & AKTWEZ==STARTWEZ
    aktlpakf=0;
    aktbajtf=0;
end
set(handles.aktlpakg, 'String', num2str(aktlpakg));
set(handles.aktlpak, 'String', num2str(aktlpak));
set(handles.aktlpakf, 'String', num2str(aktlpakf));
set(handles.aktlpakr, 'String', num2str(aktlpakr));
set(handles.aktlpakd, 'String', num2str(aktlpakd));
set(handles.aktlpakl, 'String', num2str(aktlpakl));
set(handles.aktbajts, 'String', num2str(aktbajts));
set(handles.aktbajtf, 'String', num2str(aktbajtf));
set(handles.aktbajtr, 'String', num2str(aktbajtr));
set(handles.aktbajtd, 'String', num2str(aktbajtd));
set(handles.aktminpak, 'String', num2str(aktminpak));
set(handles.aktmaxpak, 'String', num2str(aktmaxpak));
set(handles.aktsrpak, 'String', num2str(aktsrpak));
zapisz_info(handles);