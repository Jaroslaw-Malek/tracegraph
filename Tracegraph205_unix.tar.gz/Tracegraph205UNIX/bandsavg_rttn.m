function varargout = bandsavg_rttn(h, eventdata, handles, varargin)
% trgraph
global C2 C6 C11 NET HIST BANDI RTT

RTT=1;
HIST=0;
NET=1; % whole network
czyscosie;
x={'throughput', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0   
    wsp=typstart(handles,'sent');
    c2=C2(wsp);
    c6=C6(wsp);
    seqs=C11(wsp);
    wsp=seqs>=0;
    c2=c2(wsp);
    c6=c6(wsp);    
    opoz=[];
    if isempty(c2)==0    
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        op=zeros(roz,1);
        band=op;
        band(1)=sum(c6(c2<=czas(1)))*8;
        for i=2:roz
            band(i)=sum(c6(c2>czas(i-1) & c2<=czas(i)))*8;
        end
        [opoz, ids, idr, seqs, stime, tr, rozs]=netrtt(handles,1);
        o=opoz(stime>0 & stime<=czas(1));
        if isempty(o)
            op(1)=0;
        else
            op(1)=mean(o);
        end    
        for i=2:roz
            o=opoz(stime>czas(i-1) & stime<=czas(i));
            if isempty(o)
                op(i)=0;
            else
                op(i)=mean(o);
            end
        end
        opoz=op;
    end    
    if sum(opoz)==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        HIST=2; % empty graph
    else
        [band, index]=sort(band);
        opoz=opoz(index);
        index=find(opoz>0); % removing delays equal zero
        opoz=opoz(index);
        band=band(index);
        bnd=usunpowt(band);
        op=zeros(length(bnd),1);
        for i=1:length(bnd)
            m=mean(opoz(band==bnd(i)));
            if isempty(m)==0
                op(i)=m;
            end    
        end    
	[hplot,bnd,op]=rysuj(bnd, op,handles);
        zapisz_wykres([bnd, op], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('throughput of sending bits [bits/TIL]','average RTT [sec]', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);
RTT=0;