function varargout = jit_cdf(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C9 C10 C12 NET AKTWEZ STARTWEZ HIST DC fig DELAY

thandles=guihandles(fig);
DC=1;
DELAY=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('jitter', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [opoz,id,st,rt]=wezdel(handles,0);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else            
            opoz=abs(opoz(2:end)-opoz(1:(end-1))); % jitter(i)=abs((r(i+1)-s(i+1))-(r(i)-s(i)))           
            d=dystemp(opoz);
            x=d(:,1);
            y=d(:,2);
            [hplot,x,y]=rysuj(x, y, handles);
            zapisz_wykres([x, y], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['jitter between node ', num2str(AKTWEZ), ' and node ',num2str(STARTWEZ),' [sec]'],...
	'jitter cumulative distribution', hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('delay', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['jitter between node ', num2str(AKTWEZ), ' and node ',num2str(STARTWEZ),' [sec]'],...
	'jitter cumulative distribution', hplot, handles);
    end
end
DC=0;    
DELAY=0;
zapisz_wykres_jpg(opis,handles);