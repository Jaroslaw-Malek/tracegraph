function varargout = eventf_procnet(h, eventdata, handles, varargin)
% trgraph
global NET HIST

HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('forward event time', h, eventdata, handles);
if czy==0
    [opoz,wnr,id]=procnetwsp(handles,2);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [id,index]=sort(id);
        opoz=opoz(index);        
        [hplot,id,opoz]=rysuj(id, opoz,handles);
        zapisz_wykres([id, opoz], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('forward event time','processing time [sec]', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);