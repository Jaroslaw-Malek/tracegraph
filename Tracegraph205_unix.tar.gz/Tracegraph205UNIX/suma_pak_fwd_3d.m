function suma_pak_fwd_3d(h, eventdata, handles, varargin)
% trgraph
global C1 C3 C4 C7 C8 C9 C12 CHECK LNOD CZY3D TRACEFORMAT NET HIST IDCOUNT

if CHECK(6)==1
    IDCOUNT=1;
end
HIST=0;
NET=0;
os={'forward node', 'receive node'};
CZY3D=1;
hold off;
[czy, opis]=czyopis(os, h, eventdata, handles);
sumy=zeros(LNOD, LNOD);
w=typstart(handles, 15); % only packet type and forward
if TRACEFORMAT==1
    w=w & C1=='-' & C8~=-2;
    c4=C4(w);
elseif TRACEFORMAT==2
    w=w & C1=='f';
    c7=C7(w);
end
c3=C3(w);
if isempty(c3)==0
    if CHECK(6)==1
        c12=C12(w);
    end
    for i=1:LNOD
        for j=1:LNOD
            if i~=j
                if TRACEFORMAT==1
                    wsp=c3==(i-1) & c4==(j-1);
                elseif TRACEFORMAT==2
                    wsp=c3==(i-1) & c7==(j-1);
                end
                if CHECK(6)==1
                    sumy(i,j)=length(usunpowt(c12(wsp)));
                else    
                    sumy(i,j)=sum(wsp);
                end
            else
                sumy(i,j)=0;
            end
        end
    end
end    
[h,sumy,y]=rysuj(sumy',1,handles);
title(opis);
set(handles.axes1, 'xTickLabel', 0:LNOD);
set(handles.axes1, 'yTickLabel', 0:LNOD);
rotate3d on;
zoom off;
axis tight;
zapisz_wykres(sumy', opis, handles);
IDCOUNT=0;
xylabel(os{1},os{2},-1, handles);
zapisz_wykres_jpg(opis,handles);