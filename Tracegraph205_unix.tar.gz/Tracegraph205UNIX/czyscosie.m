function czyscosie
% trgraph
% clears axes
global CZY3D WYKRESY WYKRESTAG WYKRESLAB COL LICZBAWYK ghandles

if CZY3D==1
      axes(ghandles.axes1);
      cla reset;
      zoom on;
      hold off;
      rotate3d off;
      WYKRESY=cell(1);
      WYKRESTAG=cell(1);
      WYKRESLAB=cell(1);
      LICZBAWYK=0;
end
CZY3D=0;