function varargout = jitter_odb_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C8 C10 C11 C12 C13 AKTWEZ NET HIST DC TRACEFORMAT MAC fig

thandles=guihandles(fig);
HIST=0;
NET=2;
DC=1;
czyscosie;
[czy, opis]=czyopis('seq#', h, eventdata, handles);
if czy==0
    wsp=C11~=-1 & typstart(handles, 0); % number of received packets
    if TRACEFORMAT==2 & MAC==0
        c13=['end'; C13(1:(end-1),:)];
        c1=['s'; C1(1:(end-1))];
        c4=[-1; C4(1:(end-1))];
        c12=[-1; C12(1:(end-1))];
        wsp=wsp & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
    end
    if strcmp(get(thandles.directcon, 'Checked'),'on')
        wsp=wsp & C1=='r';
    else
        wsp=wsp & C4==C10 & C1=='r';
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
    else    
        time=C2(wsp);
        seq=C11(wsp);
        s=seq;
        seq=seq(2:end)-seq(1:(end-1));
        if isempty(seq)==0
            seq(seq==0)=1;
            y=time(2:end)-time(1:(end-1));
            y=y./seq;
            s=s(2:end);
            [hplot,s,y]=rysuj(s, y, handles);
            zapisz_wykres([s, y], opis, handles);
        else
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        end
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('sequence number','jitter of received packet [sec]', hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);