function varargout = smax_bandrnbit(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C6 C10 C12 C13 AKTWEZ BANDI NET HIST TRACEFORMAT MAC DC fig PAKROZ

thandles=guihandles(fig);
HIST=0;
NET=2; % to include DC in the description
DC=1;
czyscosie;
x={'packet size', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    wsp=typstart(handles, 0); % number of received packets
    if TRACEFORMAT==2 & MAC==0
        c13=['end'; C13(1:(end-1),:)];
        c1=['s'; C1(1:(end-1))];
        c4=[-1; C4(1:(end-1))];
        c12=[-1; C12(1:(end-1))];
        wsp=wsp & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
    end
    if strcmp(get(thandles.directcon, 'Checked'),'on')
        wsp=wsp & C1=='r';
    else
        wsp=wsp & C4==C10 & C1=='r';
    end
    if isempty(find(wsp)>0)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        c2=C2(wsp);
        c6=C6(wsp);
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        bwd=zeros(length(PAKROZ),1);
        band=zeros(roz, 1);
        for p=1:length(PAKROZ)
            band(1)=sum(c6(c2<=czas(1) & c6==PAKROZ(p)))*8;
            for i=2:roz
                band(i)=sum(c6(c2>czas(i-1) & c2<=czas(i) & c6==PAKROZ(p)))*8;
            end
            bwd(p)=max(band);
        end    
        [hplot,pr,bwd]=rysuj(PAKROZ, bwd, handles);
        zapisz_wykres([pr, bwd], opis, handles);     
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet size [bytes]', 'maximal throughput of receiving bits [max No. of bits/TIL]', hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);