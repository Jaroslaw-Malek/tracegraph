function varargout = procnet_cdf(h, eventdata, handles, varargin)
% trgraph
global NET HIST

HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('processing time', h, eventdata, handles);
if czy==0
    [opoz,wnr,id]=procnetwsp(handles);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        d=dystemp(opoz);
        x=d(:,1);
        y=d(:,2);
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('processing time [sec]','processing time cumulative distribution', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);