function varargout = id_delay_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST DELAY

DELAY=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('packet id', h, eventdata, handles);
if czy==0
    [opoz,id,st,tr]=netdel(handles,1);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [id, i]=sort(id);
        opoz=opoz(i);
        [hplot,id,opoz]=rysuj(id, opoz, handles);
        zapisz_wykres([id, opoz], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet id','End2End delay [sec]', hplot, handles);
end
DELAY=0;
zapisz_wykres_jpg(opis,handles);