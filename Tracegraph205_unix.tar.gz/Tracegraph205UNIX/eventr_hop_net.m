function varargout = eventr_hop_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST

HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('receive event time', h, eventdata, handles);
if czy==0
    [hop, hopf, id, stime, tr]=nethop(handles,1);
    if isempty(hop)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [tr,i]=sort(tr);
        hop=hop(i);
        [hplot,tr,hop]=rysuj(tr, hop, handles);
        zapisz_wykres([tr, hop], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet receive time at destination node [sec]','number of intermediate nodes receiving packets', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);