function varargout = otworz_plik(h, eventdata, handles, varargin)
% trgraph
% opens a trace file
global OPLIK TSTART TEND MAC plik katalog HEX USUNPLIK AUTOFORMAT

HEX=0;
TRGRAPH=0; %Trace graph format
USUNPLIK=1;
if OPLIK==0    
    [plik, katalog]=uigetfile({'*.tr','trace files';'*.mat','mat files';'*.out','out trace files';'*.*','all files'},'Choose a file to open');
elseif OPLIK==1
    if exist(eventdata)==0
        bledy(3);
        return;
    end
    plik=eventdata;
    sl=findstr(plik, '/');
    bsl=findstr(plik, '/');
    if length(sl) | length(bsl)
        if length(sl)
            katalog=plik(1:sl(end));
            plik=plik((sl(end)+1):end);
        elseif length(bsl)
            katalog=plik(1:bsl(end));
            plik=plik((bsl(end)+1):end);
        end
    else
        katalog=strcat(pwd, '/');
    end
end
try
if plik~=0 & isempty(findstr(plik, '.mat'))
    global C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 C12 C13 C14 C15 C16 
    global TMAX LNOD AKTWEZ STARTWEZ PAKIETY BANDI TRACEFORMAT pole PLIKINT

    TEMPFORMAT=TRACEFORMAT;
    li=1;
    if isempty(C2) & strcmp(get(handles.timeint, 'Checked'),'on') & TSTART~=-1 & TEND~=-1
        PLIKINT=1;
    end
    if strcmp(get(handles.timeint, 'Checked'),'off') & (PLIKINT==0 | OPLIK==0)
        TSTART=-1;
        TEND=-1;
    end
    fid=fopen(strcat(katalog, plik));
    l=fgets(fid);
    if AUTOFORMAT==1
        l=autoform(plik,katalog);
    end
    fclose('all');
    fid=fopen(strcat(katalog, plik));
    if length(findstr(l, 'ip')) & length(findstr(l, 'tracegraph'))==0
        fclose(fid);
        czyplik=zamien_ip([katalog,plik]);
        if czyplik==-1
            podaj_ip([katalog,plik]);
            return;
        elseif czyplik==0
            bledy(9);
            return;
        else % file without IPs already exists
            kropa=findstr(plik,'.');
            ekst=plik(kropa(end):end);
            plik=plik(1:(kropa(end)-1));
            plik=[plik,'_no_ip',ekst];
            disp(['Trace file without IPs has been created: ', katalog, plik, 10,'Loading the file...']);
        end
    end
    if length(findstr(l, 'tracegraph'))
        if length(findstr(l, 'hex'))
            HEX=1;
        end
        TRACEFORMAT=2;
        TRGRAPH=1;
        if TSTART~=-1 & TEND~=-1
            usun_czas(fid,katalog);
            zmien_kolumny('temp',katalog);
        else
            fclose(fid);
            zmien_kolumny(plik,katalog);
        end
    elseif length(findstr(l, 'mixed12'))
        USUNPLIK=0;
        fclose('all');
        fidw=fopen(strcat(katalog,'temp'), 'wt');
        if length(findstr(l, 'hex'))
            HEX=1;
        end    
        fprintf(fidw,'tracegraph\n');                    
        fid=fopen(strcat(katalog, plik));
        l=fgets(fid);
        spacje=0;
        tint=TSTART~=-1 & TEND~=-1;
        spnum=-1;
        while l~=-1
            event=l(1);
            if length(findstr(l,'[')) %if wireless
                eventSFD=event=='s' | event=='f' | event=='D';
                if l(2)==32 & (eventSFD | event=='r')
                    sp=findstr(l,32); % searching for a space
                    if tint
                        t=str2double(l((sp(1)+1):(sp(2)-1)));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end
                    spacje=0;
                    if sp(4)~=(sp(5)-1) % if there are 2 spaces between columns c4 and c5
                        sp=[1,sp]; spacje=1;
                    end
                    if eventSFD | (event=='r' & (l(sp(9)+2)~=48 | l(sp(10)+1)~=48 | l(sp(11)+1)~=48 | l(sp(12)+1)~=48))
                        if event=='D'
                            event='d';
                        end
                        if spacje==0
                            lw=[event, l(sp(1):sp(2)), l((sp(2)+2):(sp(3)-2)), l(sp(3):sp(4))];
                        else
                            lw=[event, l(sp(2):sp(3)), l((sp(3)+2):(sp(4)-2)), l(sp(4):sp(5))];
                        end
                        tmpspnum=sp(8)-sp(7);
                        if tmpspnum~=spnum
                            pkt=char(zeros(1, 15-tmpspnum)+32);
                            spnum=tmpspnum;
                        end                                    
                        if length(findstr(l,'/'))>0 | length(sp)<15
                            lw=[lw, [l((sp(6)+1):(sp(7)-1)), l(sp(7):sp(8)), pkt, l((sp(8)+1):(sp(9)-1)), l(sp(11):sp(12))]];
                            % left: hop from, hop to, fwd node, seq#
                            if event=='s'
                                if HEX==1
                                    ht=hex2dec(l((sp(10)+1):(sp(11)-1))); % hop to
                                    if (ht>=4294967000)
                                        ht='-1';
                                    else
                                        ht=num2str(ht);
                                    end
                                else
                                    if l(sp(10)+1)=='f'
                                        ht=' -1 ';
                                    else
                                        ht=l(sp(10):sp(11));
                                    end
                                end                                
                                if spacje==0 %go back because sp is moved
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(2)+2):(sp(3)-2)), ht, '0 -1', 10], 'char');
                                    else    
                                        fwrite(fidw, [lw, l((sp(2)+2):(sp(3)-2)), 32, ht, ' 0 -1', 10], 'char');
                                    end    
                                else
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(3)+2):(sp(4)-2)), ht, '0 -1', 10], 'char');
                                    else    
                                        fwrite(fidw, [lw, l((sp(3)+2):(sp(4)-2)), 32, ht, ' 0 -1', 10], 'char');
                                    end    
                                end
                            else % hop from, hop to, fwd, seq#
                                if spacje==0 %go back because sp is moved
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(11)+1):sp(12)), l((sp(2)+2):(sp(3)-2)), ' 0 -1', 10], 'char');
                                    else
                                        fwrite(fidw, [lw, num2str(hex2dec(l((sp(11)+1):(sp(12)-1)))), 32, l((sp(2)+2):(sp(3)-2)), ' 0 -1', 10], 'char');
                                    end    
                                else
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(11)+1):sp(12)), l((sp(3)+2):(sp(4)-2)), ' 0 -1', 10], 'char');
                                    else
                                        fwrite(fidw, [lw, num2str(hex2dec(l((sp(11)+1):(sp(12)-1)))), 32, l((sp(3)+2):(sp(4)-2)), ' 0 -1', 10], 'char');
                                    end    
                                end
                            end
                        else
                            sp1=findstr(l,':'); % node nr:port nr
                            if l(sp(14)+1)~='['
                                sp=[sp(1:13),sp(15:end)];
                            end
                            if length(sp)>18 % there is seq#
                                if l(sp(18)+1)=='[' 
                                    if l(sp(19)-1)==']' % seq# [no]
                                      c18=l((sp(18)+2):(sp(19)-2));
                                    else %[ack no]
                                      c18=l((sp(18)+2):(sp(19)-1));
                                    end  
                                else
                                    c18=l((sp(19)+2):(sp(20)-1)); % ...] 1 [ack no]
                                end
                                if str2double(c18)==NaN % uncomment if necessary
                                    c18='-1';
                                end
                            else 
                                c18='-1'; % there is no seq#
                            end
                            if HEX==0
                                fwrite(fidw, [lw, l((sp(6)+1):(sp(7)-1)), l(sp(7):sp(8)), pkt, ...
                                       l((sp(8)+1):(sp(9)-1)), l(sp(11):sp(12)), l((sp(14)+2):(sp1(1)-1)), ...
                                       32, l((sp(15)+1):(sp1(2)-1)), l(sp(17):(sp(18)-2)), 32, c18, 10], 'char');
                            else
                                fwrite(fidw, [lw, l((sp(6)+1):(sp(7)-1)), l(sp(7):sp(8)), pkt, ...
                                       l((sp(8)+1):sp(9)), num2str(hex2dec(l((sp(11)+1):(sp(12)-1)))), 32, l((sp(14)+2):(sp1(1)-1)), ...
                                       32, l((sp(15)+1):(sp1(2)-1)), l(sp(17):(sp(18)-2)), 32, c18, 10], 'char');                                
                            end   
                        end
                    end
                end
            elseif l(2)==32 & (event=='+' | event=='r' | event=='-' | event=='d') %if wired
                sp=findstr(l,32); % searching for a space
                lsp=length(sp);
                if lsp==11 | lsp==15
                    if tint
                        t=str2double(l((sp(1)+1):(sp(2)-1)));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end
                    sp1=findstr(l,':'); 
                    if isempty(sp1)
                        sp1=findstr(l,'.'); % if there is no : find .
                        sp1=sp1((end-1):end);
                    end
                    hopfrom=l((sp(8)+1):(sp1(1)-1)); % hop from without port number
                    cnode=l((sp(2)+1):(sp(3)-1)); % other node
                    if event=='+'
                        hfromother=strcmp(hopfrom, cnode); % c3=c9
                        if hfromother
                            event='s';
                            fwdnode='0'; % -Hd 
                            onode='0'; % -Ms
                            level=' AGT ';
                        else % to the queue after receiving c3~=c9
                            event='r';
                            level=' RTR ';
                            fwdnode=l((sp(3)+1):(sp(4)-1));
                            onode='-1'; %hop from
                        end
                    elseif event=='-' % (mac) c3==c9
                        hfromother=strcmp(hopfrom, cnode); % c3=c9
                        if hfromother
                            event='s';
                            level=' MAC ';
                            fwdnode='0';
                            onode='0';
                        else % forward
                            event='f';
                            level=' RTR ';
                            fwdnode=l((sp(3)+1):(sp(4)-1));
                            onode='0';
                        end
                    elseif event=='d' % drop
                        level=' RTR ';
                        fwdnode=l((sp(3)+1):(sp(4)-1));
                        onode='0';
                    elseif event=='r' % receive
                        level=' MAC ';
                        fwdnode='0';
                        onode=cnode;
                        cnode=l((sp(3)+1):(sp(4)-1));
                    end
                    if lsp==11
                        pid=l((sp(11)+1):(end-1));
                    else
                        pid=l((sp(11)+1):(sp(12)-1));
                    end
                    pid=pid(pid~=13 & pid~=10);
                    fwrite(fidw,[event, l(sp(1):sp(2)), cnode, level, pid, ...
                           [l(sp(4):sp(5)), char(zeros(1, 15-(sp(5)-sp(4)))+32)], l((sp(5)+1):sp(6)), ...
                           onode, 32, hopfrom, l(sp(9):(sp1(2)-1)), 32, fwdnode, l(sp(10):(sp(11)-1)),10], 'char');
                end
            end
            l=fgets(fid);
        end
        fclose(fidw);
        fclose(fid);
        TRACEFORMAT=2;
        HEX==0;
    elseif length(findstr(l, 'mixed13'))
        USUNPLIK=0;
        fclose('all');
        fidw=fopen(strcat(katalog,'temp'), 'wt');
        if length(findstr(l, 'hex'))
            HEX=1;
        end    
        fprintf(fidw,'tracegraph\n');                    
        fid=fopen(strcat(katalog, plik));
        l=fgets(fid);
        tint=TSTART~=-1 & TEND~=-1;
        while l~=-1
            %event, time, CN, AGT_RTR_IFQ_MAC, ID, type, size, ON, hopf, hopto, fwd_node, seq#
            event=l(1);
            if l(2)==32 & (event=='s' | event=='r' | event=='f' | event=='d') & length(findstr(l, '-Is'))
                if tint
                    t=str2double(wytnij(l,'-t',3,32));
                    if t<TSTART
                        continue;
                    end    
                    if t>TEND
                        break;
                    end                    
                end                     
                p=wytnij(l,'-It',4,32);
                if HEX==0
                    lw=[l(1),wytnij(l,'-t',3,32),wytnij(l,'-Ni',4,32),wytnij(l,'-Nl',4,32), ...
                        wytnij(l,'-Ii',4,32),p,char(zeros(1,15-length(p))+32),wytnij(l,'-Il',4,32),wytnij(l,'-Ms',4,32), ...
                        wytnij(l,'-Is',4,46),wytnij(l,'-Id',4,46),wytnij(l,'-Hd',4,32)];                     
                else
                    lw=[l(1),wytnij(l,'-t',3,32),wytnij(l,'-Ni',4,32),wytnij(l,'-Nl',4,32), ...
                        wytnij(l,'-Ii',4,32),p,char(zeros(1,15-length(p))+32),wytnij(l,'-Il',4,32), 32, num2str(hex2dec(wytnij(l,'-Ms',4,32))), ...
                        wytnij(l,'-Is',4,46),wytnij(l,'-Id',4,46),wytnij(l,'-Hd',4,32)];                                         
                end
                if length(findstr(l,'-Pi'))
                    fwrite(fidw,[lw,wytnij(l,'-Pi',4,32),10],'char');
                elseif length(findstr(l,'-Ps'))
                    fwrite(fidw,[lw,wytnij(l,'-Ps',4,32),10],'char');
                else
                    fwrite(fidw,[lw,' -1',10],'char'); % there's no seq#
                end
            elseif l(2)==32 & (event=='+' | event=='r' | event=='-' | event=='d') %if wired
                sp=findstr(l,32); % searching for a space
                lsp=length(sp);
                if lsp==11 | lsp==15
                    if tint
                        t=str2double(l((sp(1)+1):(sp(2)-1)));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end
                    sp1=findstr(l,':'); 
                    if isempty(sp1)
                        sp1=findstr(l,'.'); % if there is no : find .
                        sp1=sp1((end-1):end);
                    end
                    hopfrom=l((sp(8)+1):(sp1(1)-1)); % hop from without port number
                    cnode=l((sp(2)+1):(sp(3)-1)); % other node
                    if event=='+'
                        hfromother=strcmp(hopfrom, cnode); % c3=c9
                        if hfromother
                            event='s';
                            fwdnode='0'; % -Hd 
                            onode='0'; % -Ms
                            level=' AGT ';
                        else % to the queue after receiving c3~=c9
                            event='r';
                            level=' RTR ';
                            fwdnode=l((sp(3)+1):(sp(4)-1));
                            onode='-1'; %hop from
                        end
                    elseif event=='-' % (mac) c3==c9
                        hfromother=strcmp(hopfrom, cnode); % c3=c9
                        if hfromother
                            event='s';
                            level=' MAC ';
                            fwdnode='0';
                            onode='0';
                        else % forward
                            event='f';
                            level=' RTR ';
                            fwdnode=l((sp(3)+1):(sp(4)-1));
                            onode='0';
                        end
                    elseif event=='d' % drop
                        level=' RTR ';
                        fwdnode=l((sp(3)+1):(sp(4)-1));
                        onode='0';
                    elseif event=='r' % receive
                        level=' MAC ';
                        fwdnode='0';
                        onode=cnode;
                        cnode=l((sp(3)+1):(sp(4)-1));
                    end
                    if lsp==11
                        pid=l((sp(11)+1):(end-1));
                    else
                        pid=l((sp(11)+1):(sp(12)-1));
                    end
                    pid=pid(pid~=13 & pid~=10);
                    fwrite(fidw,[event, l(sp(1):sp(2)), cnode, level, pid, ...
                           [l(sp(4):sp(5)), char(zeros(1, 15-(sp(5)-sp(4)))+32)], l((sp(5)+1):sp(6)), ...
                           onode, 32, hopfrom, l(sp(9):(sp1(2)-1)), 32, fwdnode, l(sp(10):(sp(11)-1)),10], 'char');
                end
            end
            l=fgets(fid);
        end
        fclose(fidw);
        fclose(fid); 
        TRACEFORMAT=2; % new trace compatible with the second trace format
        HEX==0;
    else    %other trace formats
        if AUTOFORMAT==0
            if length(findstr(l, 'hex'))
                HEX=1;
                USUNPLIK=0;
                fidw=fopen(strcat(katalog,'temp'), 'wt');
                fprintf(fidw,'tracegraph hex\n');
                fclose(fidw);
            end
            fclose('all');
            fid=fopen(strcat(katalog, plik));
            while l(1)~='r' & l~=-1
                l=fgets(fid);
                if (l(1)=='+' | l(1)=='-') & l(2)==32
                    break;
                end
            end
            fclose(fid);
        else
            fclose(fid);
        end    
        if length(findstr(l,'-t'))
            fid=fopen(strcat(katalog, plik));
            fidw=fopen(strcat(katalog,'temp'), 'wt');
            l=fgets(fid);
            tint=TSTART~=-1 & TEND~=-1;
            while l~=-1
                %event, time, CN, AGT_RTR_IFQ_MAC, ID, type, size, ON, hopf, hopto, fwd_node, seq#
                if l(2)==32 & (l(1)=='s' | l(1)=='r' | l(1)=='f' | l(1)=='d') & length(findstr(l, '-Is'))
                    if tint
                        t=str2double(wytnij(l,'-t',3,32));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end                     
                    p=wytnij(l,'-It',4,32);
                    lw=[l(1),wytnij(l,'-t',3,32),wytnij(l,'-Ni',4,32),wytnij(l,'-Nl',4,32), ...
                        wytnij(l,'-Ii',4,32),p,char(zeros(1,15-length(p))+32),wytnij(l,'-Il',4,32),wytnij(l,'-Ms',4,32), ...
                        wytnij(l,'-Is',4,46),wytnij(l,'-Id',4,46),wytnij(l,'-Hd',4,32)];                     
                    if length(findstr(l,'-Pi'))
                        fwrite(fidw,[lw,wytnij(l,'-Pi',4,32),10],'char');
                    elseif length(findstr(l,'-Ps'))
                        fwrite(fidw,[lw,wytnij(l,'-Ps',4,32),10],'char');
                    else
                        fwrite(fidw,[lw,' -1',10],'char'); % there's no seq#
                    end
                end   
                l=fgets(fid);
            end
            fclose(fidw);
            fclose(fid); 
            TRACEFORMAT=2; % new trace compatible with the second trace format
        elseif length(findstr(l,' '))==11 | length(findstr(l,' '))==15
            if TSTART==-1 & TEND==-1
                if usun_linie_wired(plik,katalog,'temp')==1
                    [C1,C2,C3,C4,C5,C6,C8,C9,C10,C11,C12]=textread([katalog,plik],'%c%f%d%d%s%d%*7c%d%f%f%d%d%*[^\n]','delimiter',' ');
                    C5=char(C5);
                else    
                    [C1,C2,C3,C4,C5,C6,C8,C9,C10,C11,C12]=textread(strcat(katalog,'temp'),'%c%f%d%d%15c%d%d%f%f%d%d%*[^\n]','delimiter',' ');                   
                    delete(strcat(katalog,'temp'));                    
                end    
            elseif TSTART~=-1 & TEND~=-1
                fid=fopen(strcat(katalog, plik));
                usun_czas(fid,katalog);
                if usun_linie_wired('temp',katalog,'temp1')==1
                    [C1,C2,C3,C4,C5,C6,C8,C9,C10,C11,C12]=textread([katalog,plik],'%c%f%d%d%s%d%*7c%d%f%f%d%d%*[^\n]','delimiter',' ');
                    C5=char(C5);
                else    
                    ft=fopen([katalog,'temp1'],'r');
                    li=fgets(ft);
                    fclose(ft);
                    if li~=-1
                        [C1,C2,C3,C4,C5,C6,C8,C9,C10,C11,C12]=textread(strcat(katalog,'temp1'),'%c%f%d%d%15c%d%d%f%f%d%d%*[^\n]','delimiter',' ');
                    end    
                    delete(strcat(katalog,'temp1'));
                end
                delete(strcat(katalog,'temp'));
            end
            TRACEFORMAT=1;
            MAC=0;        
        else
            %C1{i}=l(1); % r s d f
            %C2{i}=l((sp(1)+1):(sp(2)-1)); % time
            %c3{i}=l((sp(2)+2):(sp(3)-2)); % current node
            %c4{i}=l((sp(3)+1):(sp(4)-1)); % agent router IFQ
            %c5{i}=l((sp(5)+1):(sp(6)-1)); % ARP_CBK NRTE drop cause
            %c6{i}=l((sp(6)+1):(sp(7)-1)); % packet ID
            %c7{i}=l((sp(7)+1):(sp(8)-1)); % packet type
            %c8{i}=l((sp(8)+1):(sp(9)-1)); % packet header size
            %c9{i}=l((sp(9)+2):(sp(10)-1)); % expected time to send packet
            %c10{i}=l((sp(10)+1):(sp(11)-1)); % sending node
            %c11{i}=l((sp(11)+1):(sp(12)-1)); % receiving node
            %c12{i}=l((sp(12)+1):(sp(13)-2)); % type ?
            %c13{i}=l((sp(13)+1):(sp(14)-1)); % flags
            %c14{i}=l((sp(14)+2):(sp1(1)-1)); % hop from
            %c15{i}=l((sp(15)+1):(sp1(2)-1)); % hop to
            %c16(i)=str2num(l((sp(16)+1):(sp(17)-1))); % TTL
            %c17(i)=str2num(l((sp(17)+1):(sp(18)-2))); % next hop after forward
            fid=fopen(strcat(katalog, plik));            
            if HEX==0
                fidw=fopen(strcat(katalog,'temp'), 'wb');
            elseif HEX==1
                fidw=fopen(strcat(katalog,'temp'), 'ab');
            end
            l=fgets(fid);
            spacje=0;
            tint=TSTART~=-1 & TEND~=-1;
            spnum=-1;            
            while l~=-1
                event=l(1);
                eventSFD=event=='s' | event=='f' | event=='D';
                if l(2)==32 & (eventSFD | event=='r')
                    sp=findstr(l,32); % searching for a space
                    if tint
                        t=str2double(l((sp(1)+1):(sp(2)-1)));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end
                    spacje=0;
                    if sp(4)~=(sp(5)-1) % if there are 2 spaces between columns c4 and c5
                        sp=[1,sp]; spacje=1;
                    end
                    if eventSFD | (event=='r' & (l(sp(9)+2)~=48 | l(sp(10)+1)~=48 | l(sp(11)+1)~=48 | l(sp(12)+1)~=48))
                        if event=='D'
                            event='d';
                        end
                        if spacje==0
                            lw=[event, l(sp(1):sp(2)), l((sp(2)+2):(sp(3)-2)), l(sp(3):sp(4))];
                        else
                            lw=[event, l(sp(2):sp(3)), l((sp(3)+2):(sp(4)-2)), l(sp(4):sp(5))];
                        end
                        tmpspnum=sp(8)-sp(7);
                        if tmpspnum~=spnum
                            pkt=char(zeros(1, 15-tmpspnum)+32);
                            spnum=tmpspnum;
                        end                        
                        if length(findstr(l,'/'))>0 | length(sp)<15
                            lw=[lw, [l((sp(6)+1):(sp(7)-1)), l(sp(7):sp(8)), pkt, l((sp(8)+1):(sp(9)-1)), l(sp(11):sp(12))]];
                            % left: hop from, hop to, fwd node, seq#
                            if event=='s'
                                if HEX==1
                                    ht=hex2dec(l((sp(10)+1):(sp(11)-1))); % hop to
                                    if (ht>=4294967000)
                                        ht='-1';
                                    else
                                        ht=num2str(ht);
                                    end
                                else
                                    if l(sp(10)+1)=='f'
                                        ht=' -1 ';
                                    else
                                        ht=l(sp(10):sp(11));
                                    end
                                end                                
                                if spacje==0 %go back because sp is moved
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(2)+2):(sp(3)-2)), ht, '0 -1', 10], 'char');
                                    else    
                                        fwrite(fidw, [lw, l((sp(2)+2):(sp(3)-2)), 32, ht, ' 0 -1', 10], 'char');
                                    end    
                                else
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(3)+2):(sp(4)-2)), ht, '0 -1', 10], 'char');
                                    else    
                                        fwrite(fidw, [lw, l((sp(3)+2):(sp(4)-2)), 32, ht, ' 0 -1', 10], 'char');
                                    end    
                                end
                            else % hop from, hop to, fwd, seq#
                                if spacje==0 %go back because sp is moved
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(11)+1):sp(12)), l((sp(2)+2):(sp(3)-2)), ' 0 -1', 10], 'char');
                                    else
                                        fwrite(fidw, [lw, num2str(hex2dec(l((sp(11)+1):(sp(12)-1)))), 32, l((sp(2)+2):(sp(3)-2)), ' 0 -1', 10], 'char');
                                    end    
                                else
                                    if HEX==0
                                        fwrite(fidw, [lw, l((sp(11)+1):sp(12)), l((sp(3)+2):(sp(4)-2)), ' 0 -1', 10], 'char');
                                    else
                                        fwrite(fidw, [lw, num2str(hex2dec(l((sp(11)+1):(sp(12)-1)))), 32, l((sp(3)+2):(sp(4)-2)), ' 0 -1', 10], 'char');
                                    end    
                                end
                            end
                        else
                            sp1=findstr(l,':'); % node nr:port nr
                            if l(sp(14)+1)~='['
                                sp=[sp(1:13),sp(15:end)];
                            end
                            if length(sp)>18 % there is seq#
                                if l(sp(18)+1)=='[' 
                                    if l(sp(19)-1)==']' % seq# [no]
                                      c18=l((sp(18)+2):(sp(19)-2));
                                    else %[ack no]
                                      c18=l((sp(18)+2):(sp(19)-1));
                                    end  
                                else
                                    c18=l((sp(19)+2):(sp(20)-1)); % ...] 1 [ack no]
                                end
                                if str2double(c18)==NaN % uncomment if necessary
                                    c18='-1';
                                end
                            else 
                                c18='-1'; % there is no seq#
                            end
                            fwrite(fidw, [lw, l((sp(6)+1):(sp(7)-1)), l(sp(7):sp(8)), pkt, ...
                                   l((sp(8)+1):(sp(9)-1)), l(sp(11):sp(12)), l((sp(14)+2):(sp1(1)-1)), ...
                                   32, l((sp(15)+1):(sp1(2)-1)), l(sp(17):(sp(18)-2)), 32, c18, 10], 'char');
                        end
                    end
                end
                l=fgets(fid);
            end
            fclose(fidw);
            fclose(fid);
            TRACEFORMAT=2;
            %event, time, CN, AGT_RTR_IFQ, ID, type, size, ON, hopf, hopto, fwd_node, seq#
        end    
    end    
    l=1;
    if TRGRAPH==0
        if TRACEFORMAT==2
            fid=fopen([katalog,'temp']);
            l=fgets(fid);
            fclose(fid);
        end
        if l~=-1 & li~=-1
            zmien_kolumny('temp',katalog);
        end    
    end
    if isempty(C2) | l==-1 | li==-1
        bledy(1);
        TRACEFORMAT=TEMPFORMAT;
    else
        if TSTART~=-1 & TEND~=-1 & strcmp(get(handles.timeint, 'Checked'),'on')
            PLIKINT=1;
        elseif strcmp(get(handles.timeint, 'Checked'),'off') & OPLIK==0
            PLIKINT=0;
        end
        licz_stale;
        afterload(handles, strcat(katalog, plik));
    end
elseif plik~=0 & isempty(findstr(plik, '.mat'))==0
    global C1 C2 C3 C4 C5 C6 C7 C9 C10 C11 C12 C13 FID
    global TMAX LNOD PAKIETY TRACEFORMAT pole MAC PLIKINT PAKROZ rozpak
    
    load(strcat(katalog, plik));
    TSTART=-1;
    TEND=-1;
    afterload(handles, strcat(katalog, plik));
end
catch
    bledy(7);
    disp(lasterr);
end

function s=wytnij(l,x,lx,stop)
% trgraph
% cuts data after -x for traceformat=3
% stop character - space (32) or dot (46)

poz=findstr(l,x);
poz=poz(1)+lx; %2.05 takes the first occurrence
pozk=poz;
while l(pozk)~=stop
    pozk=pozk+1;
end    
s=l(poz-1:pozk-1);