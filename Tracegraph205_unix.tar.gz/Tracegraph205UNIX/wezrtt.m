function [rtt, ids, idr, seqs, stime, rtime, rozs]=wezrtt(handles,par)  
% trgraph
% calculates RTT between Current and Other node
global C2 C9 C10 C6 C11 C12 PODZIAL RTT CHECK AKTWEZ STARTWEZ

RTT=1;
NET=0;
rtt=[];
ids=[];
idr=[];
stime=[];
rtime=[];
rozs=[];
if CHECK(2)==1 & AKTWEZ~=STARTWEZ
    sent=typstart(handles,'sent'); % sent packets type
    ack=typstart(handles,'ack'); % ack packets type
    seqs=C11(sent); % sequence number of the sent packets
    seqr=C11(ack); % sequence number of the received packets
    stime=C2(sent); % send events times
    ids=C12(sent); % sent packet IDs
    wsp=seqs>=0; % if there's no seq#
    seqs=seqs(wsp);
    stime=stime(wsp);
    ids=ids(wsp);
    if par==2 % sent packet sizes
        rozs=C6(sent);
        rozs=rozs(wsp);
    end    
    
    r=C2(ack); % ack packet receive event times
    idr=C12(ack); % IDs of ack packets
    wsp=seqr>=0; % if there's no seq# for ack
    seqr=seqr(wsp);
    r=r(wsp);
    idr=idr(wsp);
    
    l=length(stime);
    if l        
        seqstmp=zeros(l,1)-1; % list of processed sequence numbers
        tr=[];
        c2=r; % ack packet receive event times
        c11=seqr; % sequence numbers for ack
        rtt=zeros(l,1);
        dl=length(c2);
        if dl~=0
            n=ceil(dl/PODZIAL); dl=floor(dl/n);
            poz=1;
            for p=1:n
                if p==n
                    wsp=poz:length(c2);
                else
                    wsp=poz:(poz+dl-1);
                end
                c2p=c2(wsp);
                c11p=c11(wsp);        
                for i=1:l                
                    if isempty(find(seqs(i)==seqstmp))
                        tr=c2p(c11p==seqs(i)); % ack packet receive event time seqs(i)
                        if isempty(tr)==0 & rtt(i)==0
                            rtt(i)=tr(1);
                            seqstmp(i)=seqs(i);
                        end
                    end    
                end
                poz=poz+dl;
            end
            clear c2 c11 c2p c11p wsp;
            if par==1
                rtime=rtt;
            else
                rtime=[];
            end
            rtt=rtt-stime;
            opnr=find(rtt>0);
            rtt=rtt(opnr);
            ids=ids(opnr);
            seqs=seqs(opnr);
            if par==1
                stime=stime(opnr);
                rtime=rtime(opnr);
            elseif par==2
                rozs=rozs(opnr);
            end            
        end        
    end
end    