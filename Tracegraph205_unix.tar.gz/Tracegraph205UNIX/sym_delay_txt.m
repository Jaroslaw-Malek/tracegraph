function varargout = sym_delay_txt(h, eventdata, handles, varargin)
% trgraph
% shows text concerning delays for the whole network

if strcmp(get(handles.simdelays, 'Checked'), 'on')
    set(handles.simdelays, 'Checked', 'off');
    set(handles.frame3, 'Visible', 'off');
    set(handles.sd, 'Visible', 'off');
    set(handles.mind, 'Visible', 'off');
    set(handles.maxd, 'Visible', 'off');
    set(handles.avgd, 'Visible', 'off');
    set(handles.mindinfo, 'Visible', 'off');
    set(handles.maxdinfo, 'Visible', 'off');
    set(handles.avgdinfo, 'Visible', 'off');
else    
    set(handles.simdelays, 'Checked', 'on');
    sym_delay(handles);
    set(handles.frame3, 'Visible', 'on');
    set(handles.sd, 'Visible', 'on');
    set(handles.mind, 'Visible', 'on');
    set(handles.maxd, 'Visible', 'on');
    set(handles.avgd, 'Visible', 'on');
    set(handles.mindinfo, 'Visible', 'on');
    set(handles.maxdinfo, 'Visible', 'on');
    set(handles.avgdinfo, 'Visible', 'on');
end