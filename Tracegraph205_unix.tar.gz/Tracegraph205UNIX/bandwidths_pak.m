function varargout = bandwidths_pak(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C6 C7 C8 C9 C12 C13 AKTWEZ TRACEFORMAT BANDI MAC NET HIST

HIST=0;
NET=0;
czyscosie;
x={'time', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    if TRACEFORMAT==1
        wsp=C1=='-' & C3==AKTWEZ & C8~=-2 & C9==AKTWEZ & typstart(handles, 'paks');
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0 & C7~=-1 & C3==AKTWEZ;
        elseif MAC==1
            wsp4=C1=='s' & C3==AKTWEZ & C13(:,1)=='M' & C7~=-1 & C7~=-3;
        end
        wsp=wsp4 & typstart(handles, 'paks');
    end
    if isempty(find(wsp)>0)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        c2=C2(wsp);
        c6=C6(wsp);
        mc2=max(c2);
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        band=zeros(roz, 1);
        band(1)=sum(c2<=czas(1));
        band(end)=sum(c2>czas(end));
        for i=2:roz
            band(i)=sum(c2>czas(i-1) & c2<=czas(i));
        end
	    [hplot,czas,band]=rysuj(czas', band,handles);
        zapisz_wykres([czas, band], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('simulation time [sec]', ['throughput of sending packets at node ', num2str(AKTWEZ),' [No. of Packets/TIL]'], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);