function sym_delay(handles)
% trgraph
% shows delays for the whole network
global C9 C10 C12 PREC DELAY

DELAY=1;
[opoz,id,st,rt]=netdel(handles,0);
if isempty(opoz)==0
    [mind,i]=min(opoz);
    minid=id(i);
    [maxd,i]=max(opoz);
    maxid=id(i);
    avgd=mean(opoz);              
    minsnode=C9(C12==minid);
    minsnode=minsnode(1);
    minrnode=C10(C12==minid);
    minrnode=minrnode(1);
    maxsnode=C9(C12==maxid);
    maxsnode=maxsnode(1);
    maxrnode=C10(C12==maxid);
    maxrnode=maxrnode(1);
    set(handles.mindinfo, 'String', [num2str(mind,PREC),' (',num2str(minsnode),',',num2str(minrnode),',',num2str(minid),')']);
    set(handles.maxdinfo, 'String', [num2str(maxd,PREC),' (',num2str(maxsnode),',',num2str(maxrnode),',',num2str(maxid),')']);
    set(handles.avgdinfo, 'String', num2str(avgd,PREC));
else
    na(handles);
end
zapisz_info(handles);
DELAY=0;

%----------
function na(handles)
set(handles.mindinfo, 'String', 'N/A');
set(handles.maxdinfo, 'String', 'N/A');
set(handles.avgdinfo, 'String', 'N/A');    
    