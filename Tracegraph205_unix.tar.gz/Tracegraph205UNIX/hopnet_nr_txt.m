function varargout = hopnet_nr_txt(h, eventdata, handles, varargin)
% trgraph
% show text concerning number of hops in the whole network
global fig

if strcmp(get(handles.hopnetnr, 'Checked'), 'on')
    set(handles.hopnetnr, 'Checked', 'off');
    set(handles.frame5, 'Visible', 'off');
    set(handles.avgnettext, 'Visible', 'off');
    set(handles.avgnethoprtxt, 'Visible', 'off');
    set(handles.avgnethopftxt, 'Visible', 'off');
    set(handles.avgnethopr, 'Visible', 'off');
    set(handles.avgnethopf, 'Visible', 'off');
else    
    thandles=guihandles(fig);
    set(thandles.directcon, 'Checked', 'off');
    set(handles.hopnetnr, 'Checked', 'on');
    hopnet_nr(handles);
    set(handles.frame5, 'Visible', 'on');
    set(handles.avgnettext, 'Visible', 'on');
    set(handles.avgnethoprtxt, 'Visible', 'on');
    set(handles.avgnethopftxt, 'Visible', 'on');
    set(handles.avgnethopr, 'Visible', 'on');
    set(handles.avgnethopf, 'Visible', 'on');
end