function varargout = size_procn_min(h, eventdata, handles, varargin)
% trgraph
global NET HIST PAKROZ

HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('packet size', h, eventdata, handles);
if czy==0
    [opoz,wnr,id,roz]=procnetwsp(handles,3);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        op=zeros(length(PAKROZ),1);
        for i=1:length(PAKROZ)
            m=opoz(roz==PAKROZ(i));
            if isempty(m)==0
                op(i)=min(m);
            end
        end    
        [hplot,pr,op]=rysuj(PAKROZ, op, handles);
        zapisz_wykres([pr, op], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet size [bytes]','minimal simulation processing time [sec]', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);