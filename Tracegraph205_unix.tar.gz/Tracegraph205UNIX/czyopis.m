function [czy, opis]=czyopis(x, h, eventdata, handles, varargin)
% trgraph
% checks if a given graph description exists
global CZY3D TSTART TEND NET HIST IDCOUNT DC TILNUM pole DCONLY
global CHECK WYKRESY WYKRESTAG WYKRESLAB COL AKTWEZ STARTWEZ PAKIETY IND TMPWYKRESTAG TMPWYKRESLAB LICZBAWYK
global fig TRACEFORMAT FLOWID DELAY TRACELEVEL PAKROZ rozpak gfig RTT

thandles=guihandles(fig);
ghandles=guihandles(gfig);
if CZY3D
    opis=[' X:', x{1}, ' Y:', x{2}];
    LICZBAWYK=1;
else    
    if NET==0 % for 2 nodes
        if iscell(x)
            opis=[' X:', x{1}, ' TIL:', num2str(x{2},TILNUM), ' CN:', num2str(AKTWEZ)];
        else
            opis=[' X:', x, ' CN:', num2str(AKTWEZ)];
        end
    elseif NET==1 | NET==2 % for the whole network
        if iscell(x)
            opis=[' X:', x{1}, ' TIL:', num2str(x{2},TILNUM)];
        else
            opis=[' X:', x];
        end
    end
end
if (CHECK(2) & CZY3D==0 & NET==0) | HIST==3 % hist=3 if wez_delay_hist
    opis=[opis, [' ON:', num2str(STARTWEZ)]];
end
if CHECK(1) & RTT==0
    opis=[opis, ' PT:'];
    o=[];
    for i=1:length(PAKIETY)
        pak=PAKIETY{i};
        pak=pak(pak~=' ');
        if isempty(findstr(pole, ['-',pak]))
           o=[o, [pak,' ']];
        end
    end
    if isempty(o)
        o='empty';
    else
        o=o(1:(end-1));
    end
    opis=[opis,o];
end
if TRACEFORMAT==2 & (DELAY==1 | RTT==1)
    opis=[opis,10,' STL:', TRACELEVEL{get(thandles.stracelevel, 'Value')}];
    opis=[opis,' DTL:', TRACELEVEL{get(thandles.dtracelevel, 'Value')}];
end
if strcmp(get(thandles.timeint, 'Checked'),'on')
    opis=[opis, [' ST:', num2str(TSTART), ' ET:', num2str(TEND)]];
end
if (strcmp(get(thandles.directcon, 'Checked'),'on') & NET~=1 & DC==1) | (CHECK(2) & DCONLY==1)
    opis=[opis, ' DC'];
end
if TRACEFORMAT==1 & strcmp(get(thandles.flowidoption, 'Checked'),'on')
    opis=[opis, [' FID:',num2str(FLOWID)]];
end    
if strcmp(get(thandles.liczpakietraz, 'Checked'),'on') & IDCOUNT==1
    opis=[opis, ' IDx1'];
end
if strcmp(get(ghandles.logscalex,'Checked'),'on') & CZY3D==0
    opis=[opis, ' LSX'];
end
if strcmp(get(ghandles.logscaley,'Checked'),'on') & CZY3D==0
    opis=[opis, ' LSY'];
end
if strcmp(get(ghandles.logscalez,'Checked'),'on') & CZY3D==1
    opis=[opis, ' LSZ'];
end
if CHECK(8)==1 & DELAY==1 %turbo mode
    opis=[opis, ' TM'];
end
if RTT==1
    pak=char(PAKIETY{get(thandles.sentpkt, 'Value')});
    pak=pak(pak~=' ');
    if length(findstr(opis,10))==0
        opis=[opis,10];
    end  
    opis=[opis, ' SPAK:', pak];
    pak=char(PAKIETY{get(thandles.ackpkt, 'Value')});
    pak=pak(pak~=' ');
    opis=[opis, ' ACK:', pak]; 
end    
if CHECK(7)==1
    if length(findstr(opis,10))==0
        opis=[opis,10];
    end    
    opis=[opis, ' PS:'];
    o=[];
    for i=1:length(PAKROZ)
        if isempty(findstr(rozpak, ['-',num2str(PAKROZ(i))]))
           o=[o, [num2str(PAKROZ(i)),' ']];
        end
    end
    if isempty(o)
        o='empty';
    else
        o=o(1:(end-1));
    end
    opis=[opis,o];
end
if isempty(varargin)==0
    opis=varargin;
end    
if isempty(eventdata)
    if isempty(varargin)
        opis=[get(h, 'Label'), opis];
    end    
    if CHECK(3) & CZY3D==0
        for i=1:(COL-1)
            if strcmp(WYKRESY(i), opis)
                czy=1;
                return;
            end
        end
        WYKRESTAG(COL)=cellstr(get(h, 'Tag'));
        WYKRESLAB(COL)=cellstr(get(h, 'Label'));
    else
        WYKRESY=cell(1);
        WYKRESTAG=cell(1);
        WYKRESLAB=cell(1);
        WYKRESTAG(1)=cellstr(get(h, 'Tag'));
        WYKRESLAB(1)=cellstr(get(h, 'Label'));
        if CZY3D==0
            COL=2;
        elseif CZY3D==1
            COL=1;
        end
    end
else
    opis=[eventdata{1}, opis];
    if CHECK(3) & IND>1 & CZY3D==0
        for i=1:(IND-1)
            if strcmp(WYKRESY(i), opis)
                czy=1;
                return;
            end
        end
    end
    if LICZBAWYK>1
        TMPWYKRESTAG(IND)=WYKRESTAG(eventdata{2});
        TMPWYKRESLAB(IND)=WYKRESLAB(eventdata{2});
    end
end
czy=0;