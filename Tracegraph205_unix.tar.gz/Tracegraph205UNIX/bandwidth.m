function varargout = bandwidth(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C6 AKTWEZ BANDI NET HIST DC

HIST=0;
NET=0;
DC=1;
czyscosie;
x={'time', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    wsp=C4==AKTWEZ & C1=='r' & typstart(handles, 'pakr'); % number of received packets
    if isempty(find(wsp)>0)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        c2=C2(wsp);
        c6=C6(wsp);
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        band=zeros(roz, 1);
        band(1)=sum(c6(c2<=czas(1)))*8;
        for i=2:roz
            band(i)=sum(c6(c2>czas(i-1) & c2<=czas(i)))*8;
        end
	    [hplot,czas,band]=rysuj(czas', band,handles);
        zapisz_wykres([czas, band], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('simulation time [sec]', ['throughput of receiving bits at node ', num2str(AKTWEZ), ' [bits/TIL]'], hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);