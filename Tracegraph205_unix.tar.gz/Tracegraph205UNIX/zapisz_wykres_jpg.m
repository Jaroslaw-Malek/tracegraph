function zapisz_wykres_jpg(opis,handles)
% trgraph
% saves a graph in jpeg format
global plik katalog savejpeg legenda PLIKSKRYPT

if strcmp(get(handles.zapisuj_wyk, 'Checked'), 'on')
    osieoff(handles,0);
    opis=strrep(opis,':','_');
    if isempty(findstr(opis,10))==0
        opis=strrep(opis,char(10),' ');
    end
    opis=strcat(opis,'.jpg');
    opis=[katalog, plik, '-', opis];
    if isempty(legenda)==0 
        if legenda==0
            legend off;
        end
    end
    if isempty(PLIKSKRYPT)==0 & savejpeg==1
        print('-djpeg', strrep(opis,'.trg','.jpg'));
    end 
    osieoff(handles,1);
end