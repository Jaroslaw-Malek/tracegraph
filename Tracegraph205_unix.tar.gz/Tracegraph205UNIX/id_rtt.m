function varargout = id_rtt(h, eventdata, handles, varargin)
% trgraph
global NET AKTWEZ STARTWEZ HIST fig RTT

thandles=guihandles(fig);
RTT=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('sent packet id', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [opoz, id, idr, seqs, stime, rtime, rozs]=wezrtt(handles,0);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else
            [id, i]=sort(id);
            opoz=opoz(i);
            [hplot,id,opoz]=rysuj(id, opoz, handles);
            zapisz_wykres([id, opoz], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel('sent packet id',['RTT between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('sent packet id', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);
	xylabel('sent packet id',['RTT between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
end
zapisz_wykres_jpg(opis,handles);
RTT=0;