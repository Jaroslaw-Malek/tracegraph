function net_rtt(handles)
% trgraph
% shows RTT for the whole network
global C9 C10 C12 PREC RTT NET

RTT=1;
NET=1;
[rtt, ids, idr, seqs, stime, rtime, rozs]=netrtt(handles,0);
if isempty(rtt)==0
    [mind,i]=min(rtt);
    minid=ids(i);
    [maxd,i]=max(rtt);
    maxid=ids(i);
    avgd=mean(rtt);              
    minsnode=C9(C12==minid);
    minsnode=minsnode(1);
    minrnode=C10(C12==minid);
    minrnode=minrnode(1);
    maxsnode=C9(C12==maxid);
    maxsnode=maxsnode(1);
    maxrnode=C10(C12==maxid);
    maxrnode=maxrnode(1);
    set(handles.minrtt, 'String', [num2str(mind,PREC),' (',num2str(minsnode),',',num2str(minrnode),',',num2str(minid),')']);
    set(handles.maxrtt, 'String', [num2str(maxd,PREC),' (',num2str(maxsnode),',',num2str(maxrnode),',',num2str(maxid),')']);
    set(handles.avgrtt, 'String', num2str(avgd,PREC));
else
    set(handles.minrtt, 'String', 'N/A');
    set(handles.maxrtt, 'String', 'N/A');
    set(handles.avgrtt, 'String', 'N/A');    
end
zapisz_info(handles);
RTT=0;
NET=0;