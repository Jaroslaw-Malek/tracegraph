function varargout = kopiuj_do_clip(h, eventdata, handles, varargin)
% trgraph
% copies figure to clipboard

osieoff(handles,0);
print -dbitmap;
osieoff(handles,1);