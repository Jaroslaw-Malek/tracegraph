function varargout = proc(handles)
% trgraph
% shows information about processing times at current node
global PREC

[pt,id]=procwsp(handles);
if isempty(pt)
    set(handles.minproc, 'String', 'N/A');
    set(handles.maxproc, 'String', 'N/A');
    set(handles.avgproc, 'String', 'N/A');
else
    [mi,imin]=min(pt);
    [ma,imax]=max(pt);
    set(handles.minproc, 'String', [num2str(mi,PREC),' (',num2str(id(imin)),')']);
    set(handles.maxproc, 'String', [num2str(ma,PREC),' (',num2str(id(imax)),')']);
    set(handles.avgproc, 'String', num2str(mean(pt),PREC));
end
zapisz_info(handles);