function varargout = id_rttnet(h, eventdata, handles, varargin)
% trgraph
global NET HIST RTT

RTT=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('sent packet id', h, eventdata, handles);
if czy==0
    [opoz, id, idr, seqs, stime, rtime, rozs]=netrtt(handles,0);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [id, i]=sort(id);
        opoz=opoz(i);
        [hplot,id,opoz]=rysuj(id, opoz, handles);
        zapisz_wykres([id, opoz], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('sent packet id','RTT [sec]', hplot, handles);
end
RTT=0;
zapisz_wykres_jpg(opis,handles);