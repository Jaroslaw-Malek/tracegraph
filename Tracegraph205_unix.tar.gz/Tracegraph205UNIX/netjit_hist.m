function varargout = netjit_hist(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C7 C9 C10 C12 C13 TRACEFORMAT MAC NUMDELINT NET HIST HISTINTERVALS DELAY

if (strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0) | strcmp(get(handles.usehistint, 'Checked'), 'off')
DELAY=1;
HIST=1;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('jitter', h, eventdata, handles);
if czy==0
    [opoz,id,st,rt]=netdel(handles,0);    
    opoz=abs(opoz(2:end)-opoz(1:(end-1))); % jitter(i)=abs((r(i+1)-s(i+1))-(r(i)-s(i)))
    mind=min(opoz);
    maxd=max(opoz);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        HIST=2; % empty graph
    elseif mind==maxd
        [hplot,mind,lopoz]=rysuj(mind, length(opoz), handles);
        zapisz_wykres([mind, lopoz], opis, handles);    
    else
        if strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0% uses intervals
            x=HISTINTERVALS;
            y=histc(opoz,x);
            y=y';                    
        else    
            krok=(maxd-mind)/NUMDELINT;
            start=mind;
            y=zeros(1, NUMDELINT);
            for i=1:NUMDELINT
                if i==NUMDELINT
                    y(i)=length(opoz(opoz>=start));
                else
                    y(i)=length(opoz(opoz>=start & opoz<(start+krok)));
                end
                start=start+krok;
            end
            x=mind:krok:(maxd-krok);
        end
        [hplot,x,y]=rysuj(x', y', handles);
        zapisz_wykres([x,y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('Simulation jitter [sec]','jitter frequency distribution', hplot, handles);
end
DELAY=0;
end
zapisz_wykres_jpg(opis,handles);