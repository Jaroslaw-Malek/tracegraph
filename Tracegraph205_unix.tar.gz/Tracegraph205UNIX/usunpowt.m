function x=usunpowt(x)
% trgraph
% removes the same elements from a column vector

l=length(x);
for i=1:l
    w=~(x==x(i)); % rows where there is no x(i)
    x=[x(i); x(w)];
    if i==length(x) 
        break;
    end
end