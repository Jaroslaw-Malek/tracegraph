function varargout = bandf_pt(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C6 C8 NET AKTWEZ HIST BANDI fig TRACEFORMAT

thandles=guihandles(fig);
NET=0; % whole network
czyscosie;
HIST=0;
x={'throughput', BANDI};
[czy, opis]=czyopis(x, h, eventdata, handles);
if czy==0
    if TRACEFORMAT==1
        r=C1=='-' & C3==AKTWEZ & C8~=-2 & typstart(handles, 'pakf');
    elseif TRACEFORMAT==2
        r=C1=='f' & C3==AKTWEZ & typstart(handles, 'pakf');
    end
    c2=C2(r);
    c6=C6(r);
    opoz=[];
    if isempty(c2)==0
        mc2=max(c2);
        czas=min(c2):BANDI:mc2;
        if czas(end)~=mc2
            czas=[czas,mc2];
        end    
        roz=length(czas);
        op=zeros(roz,1);
        band=op;
        band(1)=sum(c6(c2<=czas(1)))*8;
        for i=2:roz
            band(i)=sum(c6(c2>czas(i-1) & c2<=czas(i)))*8;
        end
        [opoz,tr]=procwsp(handles,2);
        o=opoz(tr>0 & tr<=czas(1));
        if isempty(o)
            op(1)=0;
        else
            op(1)=mean(o);
        end    
        for i=2:roz
            o=opoz(tr>czas(i-1) & tr<=czas(i));
            if isempty(o)
                op(i)=0;
            else
                op(i)=mean(o);
            end
        end
        opoz=op;
    end    
    if sum(opoz)==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        HIST=2; % empty graph
    else
        [band, index]=sort(band);
        opoz=opoz(index);            
        bnd=usunpowt(band);
        op=zeros(length(bnd),1);
        for i=1:length(bnd)
            m=mean(opoz(band==bnd(i)));
            if isempty(m)==0
                op(i)=m;
            end    
        end    
        [hplot,bnd,op]=rysuj(bnd, op,handles);
        zapisz_wykres([bnd, op], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
    xylabel(['throughput of forwarding bits at node ', num2str(AKTWEZ), ' [bits/TIL]'],['average processing time at node ', ...
            num2str(AKTWEZ),' [sec]'], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);