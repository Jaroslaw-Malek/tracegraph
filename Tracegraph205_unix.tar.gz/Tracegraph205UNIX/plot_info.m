function plot_info(opis, eventdata, hplot, handles)
% trgraph
% show information about a figure
global CHECK WYKRESY KOLORY COL LICZBAWYK IND CZY3D HIST

axis tight;
set(handles.zoomon, 'Checked', 'on');
set(handles.legenda, 'Checked', 'on');
if HIST~=1 & strcmp(get(handles.markgraph, 'Checked'), 'on')
    set(hplot, 'Marker', 'o', 'MarkerSize', 3);
end
if strcmp(get(handles.addminorgrid, 'Checked'), 'on')
    grid minor;
end
if strcmp(get(handles.addmajorgrid, 'Checked'), 'on')
    grid on;
end
if CHECK(3)
    hold on;
    if isempty(eventdata)
        WYKRESY(COL)=cellstr(opis);
        if HIST==1
            set(hplot, 'Facecolor', KOLORY(COL));
        else    
            set(hplot, 'Color', KOLORY(COL));
        end
        COL=COL+1;
        LICZBAWYK=LICZBAWYK+1;   
        if LICZBAWYK==8
            LICZBAWYK=7;
        end
        if COL==8 
            COL=1;
        end
        legend(WYKRESY);
    else
        WYKRESY(IND)=cellstr(opis);
        if HIST==1
            set(hplot, 'Facecolor', KOLORY(IND));
        else
            set(hplot, 'Color', KOLORY(IND));
        end
        if LICZBAWYK>1
            IND=IND+1;
        end
    end    
else
    LICZBAWYK=1;
    WYKRESY=cell(1);
    WYKRESY(1)=cellstr(opis);
    COL=2;
    legend(WYKRESY);
    if HIST==1
        set(hplot, 'Facecolor', 'b');
    else
        set(hplot, 'Color', 'b');
    end    
end
zoom on;