function varargout = netrtt_cdf(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C10 C12 NET HIST RTT

RTT=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('RTT', h, eventdata, handles);
if czy==0
    [opoz, ids, idr, seqs, stime, rtime, rozs]=netrtt(handles,0);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        d=dystemp(opoz);
        x=d(:,1);
        y=d(:,2);
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('RTT [sec]','RTT cumulative distribution', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);
RTT=0;