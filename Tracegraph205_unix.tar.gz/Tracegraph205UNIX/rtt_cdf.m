function varargout = rtt_cdf(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C9 C10 C12 NET AKTWEZ STARTWEZ HIST RTT fig

thandles=guihandles(fig);
RTT=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('RTT', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [opoz, ids, idr, seqs, stime, rtime, rozs]=wezrtt(handles,0);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else
            d=dystemp(opoz);
            x=d(:,1);
            y=d(:,2);
	    [hplot,x,y]=rysuj(x, y, handles);            
            zapisz_wykres([x, y], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['RTT between node ', num2str(AKTWEZ), ' and node ',num2str(STARTWEZ),' [sec]'],...
	'RTT cumulative distribution', hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('RTT', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['RTT between node ', num2str(AKTWEZ), ' and node ',num2str(STARTWEZ),' [sec]'],...
	'RTT cumulative distribution', hplot, handles);
    end
end
zapisz_wykres_jpg(opis,handles);
RTT=0;