function suma_bajt_lost_3d(h, eventdata, handles, varargin)
% trgraph
global C1 C3 C4 C6 C7 C8 C9 C10 C12 C13 LNOD CZY3D TRACEFORMAT MAC NET HIST DC fig

thandles=guihandles(fig);
HIST=0;
NET=0;
DC=1;
if strcmp(get(thandles.directcon, 'Checked'),'off')
    os={'send node', 'receive node'};
else
    os={'forward node', 'receive node'};
end
CZY3D=1;
hold off;
[czy, opis]=czyopis(os, h, eventdata, handles);
sumy=zeros(LNOD, LNOD);
w=typstart(handles, 15); % packet type
odb=w;
if TRACEFORMAT==2 & MAC==0
    c13=['end'; C13(1:(end-1),:)];
    c1=['s'; C1(1:(end-1))];
    c4=[-1; C4(1:(end-1))];
    c12=[-1; C12(1:(end-1))];
    odb=w & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
end
odb=odb & C1=='r';
if strcmp(get(thandles.directcon, 'Checked'),'on')
    if TRACEFORMAT==1
        w=w & C1=='-' & C8~=-2;
    elseif TRACEFORMAT==2
        w=w & C1=='f'; 
        c7=C7(w);
    end    
else
    if TRACEFORMAT==1
        w=w & C1=='-' & C8~=-2;
        c9=C9(w);
    elseif TRACEFORMAT==2
        if MAC==0
            w=w & send_mac_0 & C7~=-1;
        elseif MAC==1
            w=w & C1=='s' & C13(:,1)=='M' & C7~=-1 & C7~=-3;
        end
    end
    c10=C10(w);
    c9o=C9(odb);
    c10o=C10(odb);
end
c3=C3(w);
if isempty(c3)==0
    c4=C4(w);
    c6=C6(w);
    c3o=C3(odb);
    c4o=C4(odb);
    c6o=C6(odb);
    for i=1:LNOD
        for j=1:LNOD
            if i~=j
                if strcmp(get(thandles.directcon, 'Checked'),'on')
                    if TRACEFORMAT==1
                        wsp=c3==(i-1) & c4==(j-1);
                    elseif TRACEFORMAT==2
                        wsp=c3==(i-1) & c7==(j-1); 
                    end
                    sumy(i,j)=sum(c6(wsp))-sum(c6o(c3o==(i-1) & c4o==(j-1)));
                else
                    if TRACEFORMAT==1
                        wsp=c3==(i-1) & c9==(i-1) & c10==(j-1);
                    elseif TRACEFORMAT==2
                        if MAC==0
                            wsp=c3==(i-1) & c10==(j-1);
                        elseif MAC==1
                            wsp=c3==(i-1) & c10==(j-1);
                        end
                    end
                    sumy(i,j)=sum(c6(wsp))-sum(c6o(c4o==(j-1) & c9o==(i-1) & c10o==(j-1)));
                end
                if sumy(i,j)<0
                    sumy(i,j)=0;
                end
            else
                sumy(i,j)=0;
            end
        end
    end
end    
[h,sumy,y]=rysuj(sumy',1,handles);
title(opis);
set(handles.axes1, 'xTickLabel', 0:LNOD);
set(handles.axes1, 'yTickLabel', 0:LNOD);
rotate3d on;
zoom off;
axis tight;
zapisz_wykres(sumy', opis, handles);
DC=0;
xylabel(os{1},os{2},-1, handles);
zapisz_wykres_jpg(opis,handles);