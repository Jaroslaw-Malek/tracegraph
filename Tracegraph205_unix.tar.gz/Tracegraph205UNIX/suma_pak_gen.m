function varargout = suma_pak_gen(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C6 C7 C9 C12 C13 AKTWEZ TRACEFORMAT MAC NET HIST

HIST=0;
NET=0;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    if TRACEFORMAT==1
        wsp=C1=='+' & C3==AKTWEZ & C9==AKTWEZ & typstart(handles, 'pakg');
    elseif TRACEFORMAT==2
        if MAC==0
            wsp4=send_mac_0 & C3==AKTWEZ;
        elseif MAC==1
            wsp4=C1=='s' & C3==AKTWEZ & C13(:,1)=='M';
        end
        wsp=wsp4 & typstart(handles, 'pakg');
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        wsp=C2(wsp);
        l=1:length(wsp);
        [hplot,wsp,l]=rysuj(wsp, l', handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('generate event time [sec]',['cumulative sum of numbers of generated packets at node ', num2str(AKTWEZ)], hplot, handles);
end
zapisz_wykres_jpg(opis,handles);