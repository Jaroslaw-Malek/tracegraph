function varargout = jit_hist(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C7 C9 C10 C12 C13 TRACEFORMAT MAC NUMDELINT NET AKTWEZ STARTWEZ CHECK HIST DC HISTINTERVALS
global fig DELAY

DELAY=1;
thandles=guihandles(fig);
if (strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0) | strcmp(get(handles.usehistint, 'Checked'), 'off')
DC=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    HIST=3; % to include ON
    czyscosie;
    [czy, opis]=czyopis('jitter', h, eventdata, handles);
    HIST=1;
    if czy==0
        [opoz,id,st,rt]=wezdel(handles,0);        
        opoz=abs(opoz(2:end)-opoz(1:(end-1))); % jitter(i)=abs((r(i+1)-s(i+1))-(r(i)-s(i)))
        mind=min(opoz);
        maxd=max(opoz);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
            HIST=2; % empty graph
        else            
            if length(opoz)>1
                if mind==maxd
                    [hplot,mind,lopoz]=rysuj(mind, length(opoz), handles);
                    zapisz_wykres([mind, lopoz], opis, handles);    
                else
                    if strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0% uses interval
                        x=HISTINTERVALS;
                        y=histc(opoz,x);
                        y=y';            
                    else     
                        krok=(maxd-mind)/NUMDELINT;
                        start=mind;
                        y=zeros(1, NUMDELINT);
                        for i=1:NUMDELINT
                            if i==NUMDELINT
                                y(i)=length(opoz(opoz>=start));
                            else
                                y(i)=length(opoz(opoz>=start & opoz<(start+krok)));
                            end
                            start=start+krok;
                        end
                        x=mind:krok:(maxd-krok);
                    end
                    [hplot,x,y]=rysuj(x', y', handles);
                    zapisz_wykres([x,y], opis, handles);
                end
            else
                [hplot,mind,op]=rysuj(mind, 1, handles);
                zapisz_wykres([mind, op], opis, handles);
            end            
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['jitter between node ', num2str(AKTWEZ), ' and node ',num2str(STARTWEZ),' [sec]'],...
	'jitter frequency distribution', hplot, handles);
    end
else
    NET=0; % whole network
    HIST=3; % to include ON
    czyscosie;
    [czy, opis]=czyopis('delay', h, eventdata, handles);
    HIST=1;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        HIST=2; % empty graph
        plot_info(opis, eventdata, hplot, handles);
	xylabel(['jitter between node ', num2str(AKTWEZ), ' and node ',num2str(STARTWEZ),' [sec]'],...
	'jitter frequency distribution', hplot, handles);
    end
end
DC=0;
end
DELAY=0;
zapisz_wykres_jpg(opis,handles);