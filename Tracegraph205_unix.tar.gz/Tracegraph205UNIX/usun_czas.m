function usun_czas(fid,katalog)
% trgraph
% removes lines form file which are outside time interval [TSTART, TEND]
global TSTART TEND

l=fgets(fid);
fidw=fopen(strcat(katalog,'temp'), 'wb');
sp=findstr(l, 32);
t=str2double(l(sp(1):sp(2)));
while t<=TEND & l~=-1
    sp=findstr(l, 32);
    t=str2double(l(sp(1):sp(2)));
    if t>=TSTART & t<=TEND
        fwrite(fidw, l, 'char');
    end
    l=fgets(fid);
end
fclose(fidw);
fclose(fid);