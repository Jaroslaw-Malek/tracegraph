function varargout = jitter_id(h, eventdata, handles, varargin)
% trgraph
global NET AKTWEZ STARTWEZ HIST DC fig DELAY

thandles=guihandles(fig);
DELAY=1;
DC=1;
if AKTWEZ~=STARTWEZ
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('packet id', h, eventdata, handles);
    HIST=0; 
    if czy==0
        [opoz,id,st,rt]=wezdel(handles,0);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
        else
            id=id(1:(end-1));
            [id, index]=sort(id);
            opoz=abs(opoz(2:end)-opoz(1:(end-1))); % jitter(i)=abs((r(i+1)-s(i+1))-(r(i)-s(i)))
            opoz=opoz(index);
            [hplot,id,opoz]=rysuj(id, opoz, handles);
            zapisz_wykres([id, opoz], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
	xylabel('packet id',['jitter between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
else
    NET=0; % whole network
    czyscosie;
    HIST=3; % ON if CHECK(2)==0
    [czy, opis]=czyopis('packet id', h, eventdata, handles);
    HIST=0;
    if czy==0
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
        plot_info(opis, eventdata, hplot, handles);
	xylabel('packet id',['jitter between node ', ...
	num2str(AKTWEZ),' and node ', num2str(STARTWEZ),' [sec]'], hplot, handles);
    end
end
DC=0;    
DELAY=0;
zapisz_wykres_jpg(opis,handles);