function bledy(nr)
% trgraph
% displays error of a given number 

switch nr
    case 1
        disp('ERROR: No data! Choose another time interval.');
    case 2
        disp('ERROR: Start time >= End time!');
        pause;
    case 3
        disp('ERROR: Cannot open the file!');
    case 4
        disp('ERROR: Start time < 0!');
        pause;
    case 5
        disp('ERROR: Time is not a number!');
        pause;
    case 6
        disp('ERROR: Bad option!');
        pause;
    case 7
        disp('ERROR: Cannot read the file!');
    case 8
        disp('ERROR: Cannot save the file!');
    case 9
        disp('ERROR: Cannot read the IP file!');
    case 10
        disp('ERROR: Script file not found!');
    case 11
        disp('Cannot calculate in turbo mode!');
    case 12
        disp('ERROR: Configuration file does not exist!');
    case 13
        disp('ERROR: Cannot read configuration file!');
    case 14
        disp('ERROR: Cannot save graph data!');
    case 15
        disp('ERROR: Cannot load the graph!');
    case 16
        disp('ERROR: Cannot detect file format!');
    case 17
        disp('ERROR: Cannot read license.txt file! Exiting ...');
end   