function varargout = eventr_delay_net(h, eventdata, handles, varargin)
% trgraph
global NET HIST DELAY

DELAY=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('receive event time', h, eventdata, handles);
if czy==0
    [opoz,id,st,tr]=netdel(handles,1);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else        
        [tr,i]=sort(tr);
        opoz=opoz(i);
        [hplot,tr,opoz]=rysuj(tr, opoz, handles);
        zapisz_wykres([tr, opoz], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet receive time at destination node [sec]','End2End delay [sec]' , hplot, handles);
end
DELAY=0;
zapisz_wykres_jpg(opis,handles);