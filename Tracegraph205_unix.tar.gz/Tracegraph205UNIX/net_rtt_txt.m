function varargout = net_rtt_txt(h, eventdata, handles, varargin)
% trgraph
% shows text concerning RTTs for the whole network

if strcmp(get(handles.net_rtt, 'Checked'), 'on')
    set(handles.net_rtt, 'Checked', 'off');
    set(handles.frame9, 'Visible', 'off');
    set(handles.rtttxt, 'Visible', 'off');
    set(handles.minrtttxt, 'Visible', 'off');
    set(handles.maxrtttxt, 'Visible', 'off');
    set(handles.avgrtttxt, 'Visible', 'off');
    set(handles.minrtt, 'Visible', 'off');
    set(handles.maxrtt, 'Visible', 'off');
    set(handles.avgrtt, 'Visible', 'off');
else    
    set(handles.net_rtt, 'Checked', 'on');
    net_rtt(handles);
    set(handles.frame9, 'Visible', 'on');
    set(handles.rtttxt, 'Visible', 'on');
    set(handles.minrtttxt, 'Visible', 'on');
    set(handles.maxrtttxt, 'Visible', 'on');
    set(handles.avgrtttxt, 'Visible', 'on');
    set(handles.minrtt, 'Visible', 'on');
    set(handles.maxrtt, 'Visible', 'on');
    set(handles.avgrtt, 'Visible', 'on');    
end