function varargout = procnet(handles)
% trgraph
% shows information about processing times for the whole network
global PREC

[pt,wnr,id]=procnetwsp(handles);
if isempty(pt)
    set(handles.minprocnet, 'String', 'N/A');
    set(handles.maxprocnet, 'String', 'N/A');
    set(handles.avgprocnet, 'String', 'N/A');
else
    [mi,imin]=min(pt);
    [ma,imax]=max(pt);
    set(handles.minprocnet, 'String', [num2str(mi,PREC),' (',num2str(wnr(imin)),',',num2str(id(imin)),')']);
    set(handles.maxprocnet, 'String', [num2str(ma,PREC),' (',num2str(wnr(imax)),',',num2str(id(imax)),')']);
    set(handles.avgprocnet, 'String', num2str(mean(pt),PREC));
end
zapisz_info(handles);