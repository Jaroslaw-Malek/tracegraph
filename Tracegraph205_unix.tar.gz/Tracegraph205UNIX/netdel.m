function [opoz, id, stime, rtime,roz]=netdel(handles,par)  
% trgraph
% calculates delays for the whole network
global C1 C2 C4 C6 C10 C12 PODZIAL DELAY CHECK

DELAY=1;
typ=typstart(handles,0); % packet type
wsp=typstart(handles,3);
stime=C2(wsp); % sent events times
id=C12(wsp); % IDs of sent packets
l=length(id);
if par==2
    roz=C6(wsp);
else
    roz=[];
end    
if l        
    tr=[];
    r=C1=='r' & C4==C10 & typ;
    c2=C2(r);
    c12=C12(r);        
    if CHECK(8)==0
        opoz=zeros(l,1);
        dl=length(c2);
        if dl~=0
            n=ceil(dl/PODZIAL); dl=floor(dl/n);
            poz=1;
            for p=1:n
                if p==n
                    wsp=poz:length(c2);
                else
                    wsp=poz:(poz+dl-1);
                end
                c2p=c2(wsp);
                c12p=c12(wsp);        
                for i=1:l
                    tr=c2p(c12p==id(i)); % receive event time of packet id(i)
                    if isempty(tr)==0 & opoz(i)==0
                        opoz(i)=tr(1);        
                    end
                end
                poz=poz+dl;
            end
            clear c2 c12 c2p c12p wsp;
            if par==1
                rtime=opoz;
            else
                rtime=[];
            end    
            opoz=opoz-stime;
            opnr=find(opoz>0);
            opoz=opoz(opnr);
            id=id(opnr);
            if par==1
                stime=stime(opnr);
                rtime=rtime(opnr);
            elseif par==2
                roz=roz(opnr);
            end            
        else
            opoz=[];
            id=[];
            stime=[];
            rtime=[];
        end
    else
        try            
            [c12,i]=sort(c12);
            c2=c2(i);
            if id(1)>0 % if it doesn't start from 0
                c12=c12-id(1);
            end    
            if length(stime)>=c12(end)
                stime=stime(c12+1);
                opoz=c2-stime;
                id=id(c12+1);
                typ=find(typ(c12+1));
                opoz=opoz(typ);
                stime=stime(typ);
                c2=c2(typ);
                id=id(typ);
                if par==2
                    roz=roz(typ);
                end    
            else
                l=length(c2);
                stime=stime(1:l);
                opoz=c2-stime; 
                id=id(1:l);
                typ=find(typ(1:l));
                opoz=opoz(typ);
                stime=stime(typ);
                c2=c2(typ);
                id=id(typ);
                if par==2
                    roz=roz(typ);
                end                    
            end
            if par==1
                rtime=c2;
            else
                rtime=[];
            end
        catch
            bledy(11);
            opoz=[];
            id=[];
            stime=[];
            rtime=[];
            return;
        end    
    end    
else
    opoz=[];
    id=[];
    stime=[];
    rtime=[];
end