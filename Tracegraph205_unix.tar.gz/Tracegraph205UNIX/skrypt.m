function skrypt(handles)
%trgraph
%processes a Trace graph script file

global sfig ghandles fig gfig PLIKSKRYPT savejpeg legenda CHECK

if exist(PLIKSKRYPT)==0
    bledy(10);
    return;
end
shandles=guihandles(sfig);
set(shandles.zapisuj_info, 'Checked', 'on');
set(shandles.autozminf, 'Checked', 'off');
set(ghandles.zapisuj_wyk, 'Checked', 'on');
CHECK=[0,0,0,0,0,0,0,0];
try
    nrlinii=0;
    sid=fopen(PLIKSKRYPT);
    savejpeg=0; % saves graphs to jpeg
    closeprog=0; % closes program when finished
    legenda=0; % legend in the graphs
    wylaczopcje=0; % clear options after each graph
    separator=',';
    linia=7; 
    for i=1:linia
        l=fgets(sid);
        if isempty(findstr(l, 'SAVE MAT FILE: ON'))==0
            zapisz_plik(0,0,0,1);
        elseif isempty(findstr(l, 'SAVE GRAPHS TO JPEG: ON'))==0
            savejpeg=1;
        elseif isempty(findstr(l, 'SAVE GRAPHS STATISTICS: ON'))==0
            set(ghandles.zapisz_stat_wyk, 'Checked', 'on');
        elseif isempty(findstr(l, 'CLOSE PROGRAM WHEN FINISHED: ON'))==0
            closeprog=1;
        elseif isempty(findstr(l, 'GRAPHS LEGEND: ON'))==0
            legenda=1;
        elseif isempty(findstr(l, 'RESET OPTIONS: ON'))==0
            wylaczopcje=1;
        end
        nrlinii=nrlinii+1;
    end
    if isempty(findstr(l, 'GRAPHS'))==0
        l=fgets(sid);
        while l~=-1 & isempty(findstr(l, 'NETWORK INFORMATION'))
            nrlinii=nrlinii+1;
            if l(1)~='%' %if not a comment
                if strcmp(l(end-1),char(13))
                    l=l(1:(end-2));
                else
                    l=l(1:(end-1));
                end
                sep=findstr(l,separator);
                h=findobj('Label',l(1:(sep(1)-1)));
                if isempty(h)==0 % if options have been found
                    for i=1:(length(sep)-1)
                        [opcja, par]=wytnij_dane(l((sep(i)+1):(sep(i+1)-1)));
                    end          
                    [opcja, par]=wytnij_dane(l((sep(end)+1):end));
                end
            end
            l=fgets(sid);           
        end        
    end
    if isempty(findstr(l, 'NETWORK INFORMATION'))==0
        l=fgets(sid);
        while l~=-1
            nrlinii=nrlinii+1;
            if l(1)~='%' %if not a comment
                if strcmp(l(end-1),char(13))
                    l=l(1:(end-2));
                elseif strcmp(l(end),char(10))
                    l=l(1:(end-1));
                end
                sep=findstr(l,separator);
                h=findobj('Label',l(1:(sep(1)-1)));
                if isempty(h)==0 % if options have been found
                    for i=1:(length(sep)-1)
                        [opcja, par]=wytnij_dane(l((sep(i)+1):(sep(i+1)-1)));
                    end          
                    [opcja, par]=wytnij_dane(l((sep(end)+1):end));
                end
            end
            l=fgets(sid);           
        end
    end
    fclose(sid);
catch
    disp(lasterr);
    disp(['Error processing script file: line ', num2str(nrlinii),' !']);
    PLIKSKRYPT=[];
    fclose('all');
    return;
end

try
    nrlinii=0;
    sid=fopen(PLIKSKRYPT);
    savejpeg=0; % saves graphs to jpeg
    closeprog=0; % closes program when finished
    legenda=0; % legend in the graphs
    wylaczopcje=0; % clear options after each graph
    separator=',';
    linia=7; 
    for i=1:linia
        l=fgets(sid);
        if isempty(findstr(l, 'SAVE MAT FILE: ON'))==0
            zapisz_plik(0,0,0,1);
        elseif isempty(findstr(l, 'SAVE GRAPHS TO JPEG: ON'))==0
            savejpeg=1;
        elseif isempty(findstr(l, 'SAVE GRAPHS STATISTICS: ON'))==0
            set(ghandles.zapisz_stat_wyk, 'Checked', 'on');
        elseif isempty(findstr(l, 'CLOSE PROGRAM WHEN FINISHED: ON'))==0
            closeprog=1;
        elseif isempty(findstr(l, 'GRAPHS LEGEND: ON'))==0
            legenda=1;
        elseif isempty(findstr(l, 'RESET OPTIONS: ON'))==0
            wylaczopcje=1;
        end
        nrlinii=nrlinii+1;
    end
    if isempty(findstr(l, 'GRAPHS'))==0
        l=fgets(sid);
        while l~=-1 & isempty(findstr(l, 'NETWORK INFORMATION'))
            nrlinii=nrlinii+1;
            if l(1)~='%' %if not a comment
                if strcmp(l(end-1),char(13))
                    l=l(1:(end-2));
                else
                    l=l(1:(end-1));
                end
                sep=findstr(l,separator);
                h=findobj('Label',l(1:(sep(1)-1)));
                if isempty(h)==0 % if options have been found
                    for i=1:(length(sep)-1)
                        [opcja, par]=wytnij_dane(l((sep(i)+1):(sep(i+1)-1)));
                        opcje(handles, ghandles, opcja, par);
                    end          
                    [opcja, par]=wytnij_dane(l((sep(end)+1):end));
                    opcje(handles, ghandles, opcja, par);
                    funkcja=get(h,'Callback');
                    poz1=findstr(funkcja,'('); poz1=poz1(1);
                    poz2=findstr(funkcja,','); poz2=poz2(1);
                    funkcja=funkcja((poz1+2):(poz2-2));
                    figure(gfig);            
                    feval(funkcja,h,[],ghandles);            
                end
                if wylaczopcje==1
                    zeruj_opcje(handles, ghandles);
                end
            end
            l=fgets(sid);           
        end        
    end
    if isempty(findstr(l, 'NETWORK INFORMATION'))==0
        l=fgets(sid);
        while l~=-1
            nrlinii=nrlinii+1;
            if l(1)~='%' %if not a comment
                if strcmp(l(end-1),char(13))
                    l=l(1:(end-2));
                elseif strcmp(l(end),char(10))
                    l=l(1:(end-1));
                end
                sep=findstr(l,separator);
                h=findobj('Label',l(1:(sep(1)-1)));
                if isempty(h)==0 % if options have been found
                    for i=1:(length(sep)-1)
                        [opcja, par]=wytnij_dane(l((sep(i)+1):(sep(i+1)-1)));
                        opcje(handles, ghandles, opcja, par);
                    end          
                    [opcja, par]=wytnij_dane(l((sep(end)+1):end));
                    opcje(handles, ghandles, opcja, par);
                    funkcja=get(h,'Callback');
                    poz1=findstr(funkcja,'('); poz1=poz1(1);
                    poz2=findstr(funkcja,','); poz2=poz2(1);
                    funkcja=funkcja((poz1+2):(poz2-2));
                    figure(sfig);            
                    feval(funkcja,h,[],shandles);
                    feval(funkcja,h,[],shandles);   
                end
                if wylaczopcje==1
                    zeruj_opcje(handles, ghandles);
                end
            end
            l=fgets(sid);           
        end
    end
    fclose(sid);
    PLIKSKRYPT=[];
    savejpeg=0;
    if closeprog==1
        delete(sfig);
        delete(gfig);
        delete(fig);
    end
catch
    disp(lasterr);
    disp(['Error processing script file: line ', num2str(nrlinii),' !']);
    PLIKSKRYPT=[];
    fclose('all');
end

function opcje(handles, ghandles, opcja, par)
% sets menu options
global AKTWEZ STARTWEZ pole rozpak BANDI FLOWID TSTART TEND NUMDELINT HISTINTERVALS DC TRACEFORMAT TRACELEVEL PAKIETY
global CHECK 

switch opcja
    case 'CN:'
        AKTWEZ=str2num(par{1});
        set(handles.aktwez, 'String', par{1});
    case 'ON:'
        STARTWEZ=str2num(par{1});
        CHECK(2)=1;
        set(handles.startwez, 'String', par{1});
    case 'PT:'
        for i=1:length(par)
            pole=strrep(pole,['-',par{i}],['+',par{i}]);
        end        
        CHECK(1)=1;
        set(handles.listapak, 'String', pole);
    case 'PS:'
        for i=1:length(par)
            rozpak=strrep(rozpak,['-',par{i}],['+',par{i}]);
        end
        CHECK(7)=1;
        set(handles.psize, 'String', rozpak);
    case 'TM'
        CHECK(8)=1;
        set(handles.turbo, 'Checked','on');
    case 'TIL:'
        BANDI=str2num(par{1});
        set(handles.bandinterval, 'String', par{1});
    case 'FID:'
        if TRACEFORMAT==1
            FLOWID=str2num(par{1});
            set(handles.flowidoption,'Checked','on');
            set(handles.flowid, 'String', par{1});
        end        
    case 'STL:'
        if TRACEFORMAT==2
            if length(TRACELEVEL)==3               
                if strcmp(par{1},'AGT')
                    set(handles.stracelevel, 'Value',1);
                elseif strcmp(par{1},'RTR')
                    set(handles.stracelevel, 'Value',2);
                elseif strcmp(par{1},'MAC')
                    set(handles.stracelevel, 'Value',3);
                end
            elseif length(TRACELEVEL)==2
                if (strcmp(TRACELEVEL{1},'AGT') & strcmp(par{1},'AGT')) | (strcmp(TRACELEVEL{1},'RTR') & strcmp(par{1},'RTR'))
                    set(handles.stracelevel, 'Value',1);
                elseif (strcmp(TRACELEVEL{2},'RTR') & strcmp(par{1},'RTR')) | (strcmp(TRACELEVEL{2},'MAC') & strcmp(par{1},'MAC'))
                    set(handles.stracelevel, 'Value',2);
                end    
            elseif length(TRACELEVEL)==1
                set(handles.stracelevel, 'Value',1);
            end    
        end
    case 'DTL:'
        if TRACEFORMAT==2
            if length(TRACELEVEL)==3               
                if strcmp(par{1},'AGT')
                    set(handles.dtracelevel, 'Value',1);
                elseif strcmp(par{1},'RTR')
                    set(handles.dtracelevel, 'Value',2);
                elseif strcmp(par{1},'MAC')
                    set(handles.dtracelevel, 'Value',3);
                end
            elseif length(TRACELEVEL)==2
                if (strcmp(TRACELEVEL{1},'AGT') & strcmp(par{1},'AGT')) | (strcmp(TRACELEVEL{1},'RTR') & strcmp(par{1},'RTR'))
                    set(handles.dtracelevel, 'Value',1);
                elseif (strcmp(TRACELEVEL{2},'RTR') & strcmp(par{1},'RTR')) | (strcmp(TRACELEVEL{2},'MAC') & strcmp(par{1},'MAC'))
                    set(handles.dtracelevel, 'Value',2);
                end    
            elseif length(TRACELEVEL)==1
                set(handles.dtracelevel, 'Value',1);
            end                
        end
    case 'ST:'
        TSTART=str2num(par{1});
        set(handles.timeint,'Checked','on');
        set(handles.starttime, 'String', par{1});
    case 'ET:'
        TEND=str2num(par{1});
        set(handles.timeint,'Checked','on');
        set(handles.endtime, 'String', par{1});
    case 'DC'
        CHECK(2)=1;
        DC=1;
        set(handles.directcon,'Checked','on');
    case 'IDx1'
        CHECK(6)=1;
        set(handles.liczpakietraz,'Checked', 'on');
    case 'HISTINT:'
        NUMDELINT=str2num(par{1});
        set(ghandles.usehistint,'Checked', 'off');
        set(handles.numdelint, 'String', par{1});
    case 'HISTEDGES:'
        for i=1:length(par)
            HISTINTERVALS(i)=str2num(par{i});
        end
        set(ghandles.usehistint,'Checked', 'on');
        set(handles.histintervals, 'String', num2str(HISTINTERVALS));
    case 'MARKPOINTS'
        set(ghandles.markgraph,'Checked', 'on');
    case 'MINORGRID'
        set(ghandles.addminorgrid,'Checked', 'on');
    case 'MAJORGRID'
        set(ghandles.addmajorgrid,'Checked', 'on');       
    case 'LSX'
        set(ghandles.logscalex,'Checked', 'on');
    case 'LSY'
        set(ghandles.logscaley,'Checked', 'on');
    case 'LSZ'
        set(ghandles.logscalez,'Checked', 'on');
    case 'SPAK:'
        spak=par{1};
        for p=1:length(PAKIETY)
            pak=char(PAKIETY{p}); 
            i=1; tak=1;
            while i<=length(pak) & pak(i)~=32
                if spak(i)==pak(i)
                    tak=tak+1;
                end    
                i=i+1;
            end
            if tak==i
                break;
            end    
        end    
        set(handles.sentpkt,'Value',p);
    case 'ACK:'
        ack=par{1};
        for p=1:length(PAKIETY)
            pak=char(PAKIETY{p}); 
            i=1; tak=1;
            while i<=length(pak) & pak(i)~=32
                if ack(i)==pak(i)
                    tak=tak+1;
                end    
                i=i+1;
            end
            if tak==i
                break;
            end    
        end    
        set(handles.ackpkt,'Value',p);    
end

function zeruj_opcje(handles, ghandles)
% unchecks all options
global pole rozpak DC
global CHECK 

CHECK=[0,0,0,0,0,0,0,0];
DC=0;
pole=strrep(pole,'+','-');
rozpak=strrep(rozpak,'+','-');
set(handles.listapak, 'String', pole);
set(handles.psize, 'String', rozpak);
set(handles.flowidoption,'Checked','off');
set(handles.timeint,'Checked','off');
set(handles.directcon,'Checked','off');
set(handles.liczpakietraz,'Checked', 'off');
set(handles.turbo,'Checked','off');
set(ghandles.usehistint,'Checked', 'off');
set(ghandles.markgraph,'Checked', 'off');
set(ghandles.addminorgrid,'Checked', 'off');
set(ghandles.addmajorgrid,'Checked', 'off');       

function [opcja, par]=wytnij_dane(linia)
% cuts data from a line

sp=findstr(linia, ' ');
if isempty(sp)
    opcja=linia;
    par=[];
else
    opcja=linia(1:(sp(1)-1));
    par=cell(1,length(sp));
    for i=1:(length(sp)-1)
        par{i}=linia((sp(i)+1):(sp(i+1)-1));
    end
    par{end}=linia((sp(end)+1):end);
end