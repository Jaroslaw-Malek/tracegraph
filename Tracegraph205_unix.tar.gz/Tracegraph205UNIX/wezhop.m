function [hopr, hopf, id, stime, rtime]=wezhop(handles,par)
% trgraph
% calculates number of hops between Current and Other node
global C1 C2 C3 C4 C7 C8 C9 C10 C12 AKTWEZ STARTWEZ TRACEFORMAT PREC

typ=typstart(handles,0); % packet type
wsp=typstart(handles,4);
stime=C2(wsp); % send events times
id=C12(wsp); % sent packet IDs
l=length(id);
hopr=zeros(l, 1)-1; 
hopf=zeros(l, 1)-1; 
r=C9==AKTWEZ & C10==STARTWEZ;
rpr=C1=='r' & r & typ & C4~=STARTWEZ;
if TRACEFORMAT==1
    rpf=C1=='-' & C3~=AKTWEZ & r & C8~=-2 & typ;
elseif TRACEFORMAT==2
    rpf=C1=='f' & r & typstart(handles,5) & C7~=-2;
end
r=typ & C1=='r' & r & C4==STARTWEZ;
c2=C2(r);
c12=C12(r);
c12r=C12(rpr);
c12f=C12(rpf);
rtime=zeros(l,1);
for j=1:l
    trj=c2(c12==id(j)); % receive time for packet id(j)
    if isempty(trj)==0
        if par==0 
            hopr(j)=sum(c12r==id(j)); % number of intermediate nodes receiving packets
            hopf(j)=sum(c12f==id(j)); % number of intermediate nodes forwarding packets
        elseif par==1
            hopr(j)=sum(c12r==id(j)); % number of intermediate nodes receiving packets
            rtime(j)=trj(1);
        elseif par==2
            hopf(j)=sum(c12f==id(j)); % number of intermediate nodes forwarding packets
            rtime(j)=trj(1);
        end
    end        
end
clear c2 c12 c12r c12f;
zeror=find(hopr>-1);
hopr=hopr(zeror);
zerof=find(hopf>-1);
hopf=hopf(zerof);
if par==0
    stime=[];
    rtime=[];
elseif par==1   
    rtime=rtime(zeror);
    stime=stime(zeror);
    id=id(zeror);
elseif par==2   
    rtime=rtime(zerof);
    stime=stime(zerof);
    id=id(zerof);
end