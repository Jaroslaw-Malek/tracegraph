function konfig(plik)
% trgraph
% loads configuration from plik
global PREC PODZIAL DELTEMP AUTOFORMAT MAXLINIA

precd=10;
podziald=2500;
DELTEMP=1; % deleting temporary file
AUTOFORMAT=1; % automatic format recognition
if exist(plik)==0
    bledy(12);
    PREC=precd;
    PODZIAL=podziald;
    MAXLINIA=1000; % maximum number of lines to process during automatic format recognition
    disp('Default configuration has been set.');
else
    try
        fid=fopen(plik);
        l=fgets(fid);
        while l~=-1
            if isempty(findstr(l,'PRECISION='))==0
                PREC=str2num(l(11:end));
            elseif isempty(findstr(l,'SPLIT='))==0
                PODZIAL=str2num(l(7:end));
            elseif isempty(findstr(l,'REMOVE TEMP FILE=OFF'))==0 % removes temp file
                DELTEMP=0;
            elseif isempty(findstr(l,'AUTOMATIC FORMAT DETECTION=OFF'))==0
                AUTOFORMAT=0;
            elseif isempty(findstr(l,'MAXIMAL NUMBER OF LINES='))==0
                MAXLINIA=str2num(l(25:end));
            end               
            l=fgets(fid);
        end
        if PREC>16 | PREC<1
            PREC=precd;
        end
        if PODZIAL>100000 | PODZIAL<100
            PODZIAL=podziald;
        end
        if MAXLINIA<100
            MAXLINIA=1000;
        end    
    catch
        PREC=precd;
        PODZIAL=podziald;
        MAXLINIA=1000; % maximum number of lines to process during automatic format recognition
        bledy(13);
    end
end    