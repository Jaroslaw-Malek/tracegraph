function varargout = wez_delay_txt(h, eventdata, handles, varargin)
% trgraph
% shows text concerning delays between 2 nodes
global CHECK AKTWEZ STARTWEZ

if strcmp(get(handles.nodedelays, 'Checked'), 'on')
    set(handles.nodedelays, 'Checked', 'off');
    set(handles.frame4, 'Visible', 'off');
    set(handles.dbcao, 'Visible', 'off');
    set(handles.aktmind, 'Visible', 'off');
    set(handles.aktmaxd, 'Visible', 'off');
    set(handles.aktavgd, 'Visible', 'off');
    set(handles.aktmindinfo, 'Visible', 'off');
    set(handles.aktmaxdinfo, 'Visible', 'off');
    set(handles.aktavgdinfo, 'Visible', 'off');
elseif CHECK(2)==1 & AKTWEZ~=STARTWEZ   
    set(handles.nodedelays, 'Checked', 'on');
    wez_delay(handles);
    set(handles.frame4, 'Visible', 'on');
    set(handles.dbcao, 'Visible', 'on');
    set(handles.aktmind, 'Visible', 'on');
    set(handles.aktmaxd, 'Visible', 'on');
    set(handles.aktavgd, 'Visible', 'on');
    set(handles.aktmindinfo, 'Visible', 'on');
    set(handles.aktmaxdinfo, 'Visible', 'on');
    set(handles.aktavgdinfo, 'Visible', 'on');
end