function varargout = suma_bajt_fwd_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C6 C7 C8 TRACEFORMAT NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    typ=typstart(handles, 5);
    if TRACEFORMAT==1
        wsp=C1=='-' & typ & C8~=-2;
    elseif TRACEFORMAT==2
        wsp=C1=='f' & typ & C7~=-2;
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        x=C2(wsp);
        y=cumsum(C6(wsp));
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('forward event time [sec]','cumulative sum of forwarded bytes', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);