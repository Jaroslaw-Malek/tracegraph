function varargout = size_rttn_max(h, eventdata, handles, varargin)
% trgraph
global NET HIST RTT PAKROZ

RTT=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('sent packet size', h, eventdata, handles);
if czy==0
    [opoz, id, idr, seqs, stime, tr, roz]=netrtt(handles,2);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        op=zeros(length(PAKROZ),1);
        for i=1:length(PAKROZ)
            m=max(opoz(roz==PAKROZ(i)));
            if isempty(m)==0
                op(i)=m;
            end
        end        
        [hplot,pr,op]=rysuj(PAKROZ, op, handles);
        zapisz_wykres([pr, op], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('sent packet size [bytes]','maximal RTT [sec]', hplot, handles);
end
zapisz_wykres_jpg(opis,handles);
RTT=0;