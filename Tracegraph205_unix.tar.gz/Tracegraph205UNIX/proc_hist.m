function varargout = proc_hist(h, eventdata, handles, varargin)
% trgraph
global NUMDELINT NET AKTWEZ STARTWEZ CHECK HIST DC DCONLY HISTINTERVALS

if (strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0) | strcmp(get(handles.usehistint, 'Checked'), 'off')
    DC=1;
    DCONLY=1;
    NET=0; % whole network
    HIST=1;
    czyscosie;
    [czy, opis]=czyopis('processing time', h, eventdata, handles);
    if czy==0
        [opoz,id]=procwsp(handles);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
            HIST=2; % empty graph
        else
            mind=min(opoz);
            maxd=max(opoz);
            if length(opoz)>1
                if mind==maxd
                    [hplot,mind,lopoz]=rysuj(mind, length(opoz), handles);
                    zapisz_wykres([mind, lopoz], opis, handles);    
                else
                    if strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0% uzywa granic przedzialow
                        x=HISTINTERVALS;
                        y=histc(opoz,x);
                        y=y';            
                    else     
                        krok=(maxd-mind)/NUMDELINT;
                        start=mind;
                        y=zeros(1, NUMDELINT);
                        for i=1:NUMDELINT
                            if i==NUMDELINT
                                y(i)=length(opoz(opoz>=start));
                            else
                                y(i)=length(opoz(opoz>=start & opoz<(start+krok)));
                            end
                            start=start+krok;
                        end
                        x=mind:krok:(maxd-krok);
                    end
                    [hplot,x,y]=rysuj(x', y', handles);
                    zapisz_wykres([x,y], opis, handles);
                end
            else
                [hplot,mind,op]=rysuj(mind, 1, handles);
                zapisz_wykres([mind, op], opis, handles);
            end            
        end
        plot_info(opis, eventdata, hplot, handles);
	    xylabel(['processing time at node ', num2str(AKTWEZ), ' [sec]'],...
    	'processing times frequency distribution', hplot, handles);
    end
    DC=0;
    DCONLY=0;
end
zapisz_wykres_jpg(opis,handles);