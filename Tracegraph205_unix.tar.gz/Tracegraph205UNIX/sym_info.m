function varargout = sym_info(h, eventdata, handles, varargin)
% trgraph
% simulation information

if strcmp(get(handles.syminfo, 'Checked'), 'on')
    set(handles.syminfo, 'Checked', 'off');
    set(handles.frame1, 'Visible', 'off');
    set(handles.text1, 'Visible', 'off');
    set(handles.text2, 'Visible', 'off');
    set(handles.text3, 'Visible', 'off');
    set(handles.text4, 'Visible', 'off');
    set(handles.text5, 'Visible', 'off');
    set(handles.text9, 'Visible', 'off');
    set(handles.text10, 'Visible', 'off');
    set(handles.text11, 'Visible', 'off');
    set(handles.text12, 'Visible', 'off');
    set(handles.text47, 'Visible', 'off');    
    set(handles.text49, 'Visible', 'off');    
    set(handles.nofgp, 'Visible', 'off');
    set(handles.nofp, 'Visible', 'off');
    set(handles.nofb, 'Visible', 'off');
    set(handles.nolp, 'Visible', 'off');
    set(handles.wop, 'Visible', 'off');    
    set(handles.slob, 'Visible', 'off');        
    set(handles.tmax, 'Visible', 'off');
    set(handles.lnod, 'Visible', 'off');
    set(handles.lpak, 'Visible', 'off');
    set(handles.lpakd, 'Visible', 'off');
    set(handles.lpakl, 'Visible', 'off');
    set(handles.lnad, 'Visible', 'off');
    set(handles.lodb, 'Visible', 'off');
    set(handles.minpak, 'Visible', 'off');
    set(handles.maxpak, 'Visible', 'off');
    set(handles.srpak, 'Visible', 'off');
    set(handles.bajts, 'Visible', 'off');    
    set(handles.bajtf, 'Visible', 'off');
    set(handles.bajtd, 'Visible', 'off');    
    set(handles.wezlyd, 'Visible', 'off');    
    set(handles.lpakg, 'Visible', 'off');
    set(handles.lpakf, 'Visible', 'off');
else
    set(handles.syminfo, 'Checked', 'on');
    sym_info1(handles);
    set(handles.frame1, 'Visible', 'on');
    set(handles.text1, 'Visible', 'on');
    set(handles.text2, 'Visible', 'on');
    set(handles.text3, 'Visible', 'on');
    set(handles.text4, 'Visible', 'on');
    set(handles.text5, 'Visible', 'on');
    set(handles.text9, 'Visible', 'on');
    set(handles.text10, 'Visible', 'on');
    set(handles.text11, 'Visible', 'on');
    set(handles.text12, 'Visible', 'on');
    set(handles.text47, 'Visible', 'on');    
    set(handles.text49, 'Visible', 'on');    
    set(handles.nofgp, 'Visible', 'on');
    set(handles.nofp, 'Visible', 'on');
    set(handles.nofb, 'Visible', 'on');
    set(handles.nolp, 'Visible', 'on');
    set(handles.slob, 'Visible', 'on');    
    set(handles.wop, 'Visible', 'on');        
    set(handles.tmax, 'Visible', 'on');
    set(handles.lnod, 'Visible', 'on');
    set(handles.lpak, 'Visible', 'on');
    set(handles.lpakg, 'Visible', 'on');
    set(handles.lpakf, 'Visible', 'on');
    set(handles.lpakd, 'Visible', 'on');
    set(handles.lpakl, 'Visible', 'on');
    set(handles.lnad, 'Visible', 'on');
    set(handles.lodb, 'Visible', 'on');
    set(handles.minpak, 'Visible', 'on');
    set(handles.maxpak, 'Visible', 'on');
    set(handles.srpak, 'Visible', 'on');
    set(handles.bajts, 'Visible', 'on');
    set(handles.bajtf, 'Visible', 'on');
    set(handles.bajtd, 'Visible', 'on');        
    set(handles.wezlyd, 'Visible', 'on');    
end
