function varargout = events_rttnet(h, eventdata, handles, varargin)
% trgraph
global NET HIST RTT

RTT=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('send event time', h, eventdata, handles);
if czy==0
    [opoz, id, idr, seqs, stime, rtime, rozs]=netrtt(handles,1);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else
        [hplot,stime,opoz]=rysuj(stime, opoz, handles);
        zapisz_wykres([stime, opoz], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet send time at source node [sec]','RTT [sec]' , hplot, handles);
end
zapisz_wykres_jpg(opis,handles);
RTT=0;