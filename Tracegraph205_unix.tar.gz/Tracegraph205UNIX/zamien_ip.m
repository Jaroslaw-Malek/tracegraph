function czyplik=zamien_ip(plik)
% trgraph
% replaces IPs and creates a new file with changes
global TSTART TEND

czyplik=0;
if TSTART==-1 & TEND==-1
    pliktemp=strcat(plik,'.ip');
elseif TSTART~=-1 & TEND~=-1
    pliktemp=[plik,'-ST_',num2str(TSTART),' ET_',num2str(TEND),'.ip'];
end
if exist(pliktemp)~=0
    try
        disp('Converting IPs to nodes numbers ...');
        [ipfrom, ipto]=textread(pliktemp, '%s%s', 'delimiter', ' ');
        if isempty(ipto{1})
            return;
        end
        roz=size(ipfrom);
        roz=roz(1);
        for i=1:roz
            ipfrom=[ipfrom;{['[',ipfrom{i}]}];
            ipto=[ipto;{['[',ipto{i}]}];
            ipfrom=[ipfrom;{['/',ipfrom{i}]}];
            ipto=[ipto;{['/',ipto{i}]}];
            ipfrom{i}=[' ',ipfrom{i}];
            ipto{i}=[' ',ipto{i}];
        end    
        roz=size(ipfrom);
        roz=roz(1);
        fid=fopen(plik);
        kropa=findstr(plik,'.');
        ekst=plik(kropa(end):end);
        fidw=fopen([plik(1:(kropa(end)-1)),'_no_ip',ekst],'wb');
        fblocksize=10000; %optimal value
        fblock=fread(fid,[1,fblocksize],'*char');
        while isempty(fblock)==0
            lb=length(fblock);
            i=lb;
            while i>1 & fblock(i)~=32 %looking for a space
                i=i-1;
            end
            if i>1 % if i==1 it means the last block has been read
                i=i-1;
                fblock=fblock(1:i);
                fseek(fid,i-lb,0); %back to the end of line                
            end    
            for j=1:roz
                fblock=strrep(fblock,ipfrom{j},ipto{j});
            end
            %fblock=strrep(fblock, char(13), '');
            fwrite(fidw,fblock,'char');
            fblock=fread(fid,[1,fblocksize],'*char');            
        end        
        fclose(fid);
        fclose(fidw);              
        czyplik=1;
    catch
        czyplik=0;
        return;
    end
else
    czyplik=-1; % there's no file
    disp(['File ', pliktemp, ' does not exist! Creating the file ...']);
end