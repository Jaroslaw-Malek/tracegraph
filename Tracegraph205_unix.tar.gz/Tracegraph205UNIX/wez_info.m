function varargout = wez_info(h, eventdata, handles, varargin)
% current node information

if strcmp(get(handles.wezinfo, 'Checked'), 'on')
    set(handles.wezinfo, 'Checked', 'off');
    set(handles.frame2, 'Visible', 'off');
    set(handles.text32, 'Visible', 'off');
    set(handles.text33, 'Visible', 'off');
    set(handles.text36, 'Visible', 'off');
    set(handles.text37, 'Visible', 'off');
    set(handles.text38, 'Visible', 'off');
    set(handles.text39, 'Visible', 'off');
    set(handles.text54, 'Visible', 'off');
    set(handles.text55, 'Visible', 'off');
    set(handles.text56, 'Visible', 'off');
    set(handles.lob, 'Visible', 'off');
    set(handles.aktnogp, 'Visible', 'off');
    set(handles.aktnofp, 'Visible', 'off');
    set(handles.aktnofb, 'Visible', 'off');
    set(handles.aktnolp, 'Visible', 'off');
    set(handles.aktlpak, 'Visible', 'off');
    set(handles.aktlpakg, 'Visible', 'off');
    set(handles.aktlpakf, 'Visible', 'off');
    set(handles.aktlpakr, 'Visible', 'off');
    set(handles.aktlpakd, 'Visible', 'off');
    set(handles.aktlpakl, 'Visible', 'off');
    set(handles.aktbajts, 'Visible', 'off');
    set(handles.aktbajtf, 'Visible', 'off');
    set(handles.aktbajtr, 'Visible', 'off');
    set(handles.aktbajtd, 'Visible', 'off');
    set(handles.aktminpak, 'Visible', 'off');
    set(handles.aktmaxpak, 'Visible', 'off');
    set(handles.aktsrpak, 'Visible', 'off');
else
    set(handles.wezinfo, 'Checked', 'on');
    wez_info1(handles);
    set(handles.frame2, 'Visible', 'on');
    set(handles.text32, 'Visible', 'on');
    set(handles.text33, 'Visible', 'on');
    set(handles.text36, 'Visible', 'on');
    set(handles.text37, 'Visible', 'on');
    set(handles.text38, 'Visible', 'on');
    set(handles.text39, 'Visible', 'on');
    set(handles.text54, 'Visible', 'on');
    set(handles.text55, 'Visible', 'on');
    set(handles.text56, 'Visible', 'on');
    set(handles.lob, 'Visible', 'on');
    set(handles.aktnogp, 'Visible', 'on');
    set(handles.aktnofp, 'Visible', 'on');
    set(handles.aktnofb, 'Visible', 'on');
    set(handles.aktnolp, 'Visible', 'on');
    set(handles.aktlpak, 'Visible', 'on');
    set(handles.aktlpakg, 'Visible', 'on');
    set(handles.aktlpakf, 'Visible', 'on');
    set(handles.aktlpakr, 'Visible', 'on');
    set(handles.aktlpakd, 'Visible', 'on');
    set(handles.aktlpakl, 'Visible', 'on');
    set(handles.aktbajts, 'Visible', 'on');
    set(handles.aktbajtf, 'Visible', 'on');
    set(handles.aktbajtr, 'Visible', 'on');
    set(handles.aktbajtd, 'Visible', 'on');
    set(handles.aktminpak, 'Visible', 'on');
    set(handles.aktmaxpak, 'Visible', 'on');
    set(handles.aktsrpak, 'Visible', 'on');
end
