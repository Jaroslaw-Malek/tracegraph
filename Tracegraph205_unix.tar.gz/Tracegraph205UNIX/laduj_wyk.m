function laduj_wyk(h, eventdata, handles, varargin)
% trgraph 
% loads data from file and plots a graph
global CZY3D HIST

[plik, katalog]=uigetfile({'*.trg','trg files';'*.*','all files'},'Choose a graph to open');
if plik~=0
    try
        fid=fopen(strcat(katalog, plik));
        l=fgets(fid);
        fclose(fid);
        sp=length(findstr(l,' '));
        if sp~=0
            [x,y,z]=textread(strcat(katalog,plik),'%n%n%n','delimiter',' ');
            plik=strrep(plik,'_',':');
            plik=strrep(plik,'.trg','');                        
                if sp==1 %2D
                    if isempty(CZY3D)
                        CZY3D=0;
                    end    
                    czyscosie;
                    [czy, opis]=czyopis({'',''}, h, eventdata, handles,plik);
                    if czy==0
                        if length(findstr(plik,'frequency distribution'))==0
                            HIST=0;
                        else
                            HIST=1;
                        end    
                        [hplot,x,y]=rysuj(x,y,handles);
                        plot_info(plik, eventdata, hplot, handles);
                    end    
                elseif sp==2 %3D
                    CZY3D=1;
                    [czy, opis]=czyopis({'',''}, h, eventdata, handles,plik);
                    if czy==0
                        hold off;                    
                        lnod=max(x)+1;
                        wyn=zeros(lnod,lnod);
                        for i=1:lnod
                            for j=1:lnod
                                wyn(i,j)=z((i-1)*lnod+j);
                            end
                        end
                        bar3(wyn');
                        set(handles.axes1, 'xTickLabel', 0:lnod);
                        set(handles.axes1, 'yTickLabel', 0:lnod);                
                        title(plik);
                        set(handles.tytul, 'String', plik);
                        rotate3d on;
                        zoom off;
                        axis tight;                
                    end    
                end
                zapisz_wykres_jpg(plik,handles);
        end   
    catch
        disp(lasterr);
        bledy(15);
        return;
    end    
end