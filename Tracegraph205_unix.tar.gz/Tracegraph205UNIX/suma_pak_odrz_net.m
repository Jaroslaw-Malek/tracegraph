function varargout = suma_pak_odrz_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C3 C4 C7 AKTWEZ STARTWEZ CHECK TRACEFORMAT TSTART TEND NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C2(C1=='d' & typstart(handles, 6));
    if isempty(wsp)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=1:length(wsp);
        [hplot,wsp,l]=rysuj(wsp, l', handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('drop event time [sec]','cumulative sum of numbers of dropped packets', hplot, handles);
end    
zapisz_wykres_jpg(opis,handles);