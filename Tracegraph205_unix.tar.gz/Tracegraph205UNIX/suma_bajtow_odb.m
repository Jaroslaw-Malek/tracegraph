function varargout = suma_bajtow_odb(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C6 AKTWEZ NET HIST DC

HIST=0;
NET=0;
DC=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C4==AKTWEZ & C1=='r' & typstart(handles, 'pakr'); % number of received packets
    if isempty(find(wsp)>0)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        x=C2(wsp);
        y=cumsum(C6(wsp));
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('receive event time [sec]',['cumulative sum of received bytes at node ', num2str(AKTWEZ)], hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);