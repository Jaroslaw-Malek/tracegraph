function varargout = hop_nr(handles)
% trgraph
% shows information about number of hops between current and other node
global PREC

[hopr, hopf,id,st,rt]=wezhop(handles,0);
if isempty(hopr)
    set(handles.avghopr, 'String', 'N/A');
else
    hopr=sum(hopr)/length(hopr);
    set(handles.avghopr, 'String', num2str(hopr,PREC));
end
if isempty(hopf)
    set(handles.avghopf, 'String', 'N/A'); 
else     
    hopf=sum(hopf)/length(hopf);
    set(handles.avghopf, 'String', num2str(hopf,PREC)); 
end   
zapisz_info(handles);