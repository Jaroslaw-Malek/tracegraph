function varargout = seq_pak_odrz_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C11 NET HIST

HIST=0;
NET=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C11~=-1 & C1=='d' & typstart(handles, 6);
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=C11(wsp);
        wsp=C2(wsp);
        [hplot,wsp,l]=rysuj(wsp, l, handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('packet drop time [sec]','sequence number of dropped packet', hplot, handles);
end    
zapisz_wykres_jpg(opis,handles);