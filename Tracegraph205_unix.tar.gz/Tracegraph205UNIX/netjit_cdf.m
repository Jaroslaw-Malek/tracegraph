function varargout = netjit_cdf(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C10 C12 NET HIST DELAY

DELAY=1;
HIST=0;
NET=1; % whole network
czyscosie;
[czy, opis]=czyopis('jitter', h, eventdata, handles);
if czy==0
    [opoz,id,st,rt]=netdel(handles,0);
    if isempty(opoz)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else        
        opoz=abs(opoz(2:end)-opoz(1:(end-1))); % jitter(i)=abs((r(i+1)-s(i+1))-(r(i)-s(i)))        
        d=dystemp(opoz);
        x=d(:,1);
        y=d(:,2);
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('Simulation jitter [sec]','jitter cumulative distribution', hplot, handles);
end
DELAY=0;
zapisz_wykres_jpg(opis,handles);