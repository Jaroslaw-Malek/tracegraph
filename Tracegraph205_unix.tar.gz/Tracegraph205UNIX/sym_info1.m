function sym_info1(handles)
% trgraph
% simulation information
global C1 C2 C3 C4 C6 C7 C8 C9 C10 C12 C13 CHECK
global LNOD TRACEFORMAT MAC PLIKINT PREC TSTART TEND
global fig

thandles=guihandles(fig);
w=typstart(handles,0);
f=find(w==1);
if MAC==0
    w1=C1=='d' & w;
else
    w1=C1=='d' & typstart(handles, 6);
end
if CHECK(6)==1
    LPAKD=length(usunpowt(C12(w1)));
else
    LPAKD=sum(w1);
end
BAJTD=sum(C6(w1));
odb=w;
if TRACEFORMAT==1
    LPAKG=sum(C1=='+' & C3==C9 & w); %LPAK; % generated
    LPAK=C1=='-' & C3==C9 & w & C8~=-2; % sent
    fwd1=C1=='-' & C3~=C9 & w & C8~=-2; % forwarded
    if CHECK(6)==1
        LPAKF=length(usunpowt(C12(fwd1))); % forwarded only once (count ID)
    else 
        LPAKF=sum(fwd1);
    end
    BAJTS=sum(C6(LPAK));
    LPAKL=sum(LPAK & C10~=-1)-sum(odb & C1=='r' & C4==C10); % lost packets
    LPAK=sum(LPAK);
    BAJTF=sum(C6(fwd1)); % all the forwarded bytes
elseif TRACEFORMAT==2
    if MAC==1
        wfwd=typstart(handles, 5);
        fwd=C1=='f' & wfwd & C7~=-2;
    else
        fwd=C1=='f' & w & C7~=-2;
    end
    if CHECK(6)==1
        LPAKF=length(usunpowt(C12(fwd)));
    else    
        LPAKF=sum(fwd); % forwarded-lost at the same node during forwarding
    end
    losts=find(w1 & C7==-1);
    if MAC==0
        gen=send_mac_0 & w;
    elseif MAC==1
        gen=C1=='s' & w & C13(:,1)=='M';
    end
    LPAKG=sum(gen);
    LPAK=LPAKG-length(losts); % node drops packets during sending
    if MAC==0
        c13=['end'; C13(1:(end-1),:)];
        c1=['s'; C1(1:(end-1))];
        c4=[-1; C4(1:(end-1))];
        c12=[-1; C12(1:(end-1))];
        odb=odb & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
    end
    BAJTS=sum(C6(gen))-sum(C6(losts));
    BAJTF=sum(C6(fwd));
    LPAKL=sum(gen & C10~=-1)-length(losts)-sum(odb & C1=='r' & C4==C10); % lost packets
end
if LPAKL<0
    LPAKL=0;
end
c=C6(f);
if isempty(c)==0
    MINPAK=min(c);
    MAXPAK=max(c);
    SRPAK=sum(c)/length(c);
else
    MINPAK=0;
    MAXPAK=0;
    SRPAK=0;
end
LNAD=0;
c9min=min(C9(C9>=0));
c9max=max(C9);
for i=c9min:c9max
    if length(find(C9==i & w))
       LNAD=LNAD+1;
    end
end
LODB=0;
c10min=min(C10(C10>=0));
c10max=max(C10);
for i=c10min:c10max
    if length(find(C10==i & w))
       LODB=LODB+1;
    end
end
WEZLYD=sort(usunpowt(C3(C1=='d' & w1))); 
st=min(C2(f));
et=max(C2(f));
TMAX=et-st;
TSTART=st;
TEND=et;

set(thandles.starttime, 'String', num2str(st));
set(thandles.endtime, 'String', num2str(et));
set(handles.tmax, 'String', num2str(TMAX,PREC));
set(handles.lpakg, 'String', num2str(LPAKG));
set(handles.lpakf, 'String', num2str(LPAKF));
set(handles.lpak, 'String', num2str(LPAK));
set(handles.lpakd, 'String', num2str(LPAKD));
set(handles.lpakl, 'String', num2str(LPAKL));
set(handles.lnad, 'String', num2str(LNAD));
set(handles.lodb, 'String', num2str(LODB));
set(handles.minpak, 'String', num2str(MINPAK));
set(handles.maxpak, 'String', num2str(MAXPAK));
set(handles.srpak, 'String', num2str(SRPAK));
set(handles.bajts, 'String', num2str(BAJTS));
set(handles.bajtf, 'String', num2str(BAJTF));
set(handles.bajtd, 'String', num2str(BAJTD));
set(handles.wezlyd, 'String', num2str(WEZLYD'));
zapisz_info(handles);