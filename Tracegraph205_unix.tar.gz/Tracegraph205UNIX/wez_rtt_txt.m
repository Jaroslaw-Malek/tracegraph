function varargout = wez_rtt_txt(h, eventdata, handles, varargin)
% trgraph
% shows text concerning RTTs between 2 nodes (Current and Other node)
global CHECK AKTWEZ STARTWEZ

if strcmp(get(handles.wez_rtt, 'Checked'), 'on')
    set(handles.wez_rtt, 'Checked', 'off');
    set(handles.frame10, 'Visible', 'off');
    set(handles.aktrtttxt, 'Visible', 'off');
    set(handles.aktminrtttxt, 'Visible', 'off');
    set(handles.aktmaxrtttxt, 'Visible', 'off');
    set(handles.aktavgrtttxt, 'Visible', 'off');
    set(handles.aktminrtt, 'Visible', 'off');
    set(handles.aktmaxrtt, 'Visible', 'off');
    set(handles.aktavgrtt, 'Visible', 'off');
elseif CHECK(2)==1 & AKTWEZ~=STARTWEZ       
    set(handles.wez_rtt, 'Checked', 'on');
    wez_rtt(handles);
    set(handles.frame10, 'Visible', 'on');
    set(handles.aktrtttxt, 'Visible', 'on');
    set(handles.aktminrtttxt, 'Visible', 'on');
    set(handles.aktmaxrtttxt, 'Visible', 'on');
    set(handles.aktavgrtttxt, 'Visible', 'on');
    set(handles.aktminrtt, 'Visible', 'on');
    set(handles.aktmaxrtt, 'Visible', 'on');
    set(handles.aktavgrtt, 'Visible', 'on');    
end