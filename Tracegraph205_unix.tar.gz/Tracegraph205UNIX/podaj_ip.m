function out=podaj_ip(plik)
% trgraph
% saves IPs to a file.ip
global TSTART TEND FWDLENGTH AUTOFORMAT
global tab_ip tiprow tab_ip_size

fid=fopen(plik);
l=fgets(fid);
if AUTOFORMAT==1
    l=autoform(plik,[]);
end
fclose('all');
fid=fopen(plik);
tab_ip_size=1000; % optimal value
tab_ip=cell(tab_ip_size,1); % ip table
tiprow=1; % ip table row
out=0;
if length(findstr(l, 'tracegraph'))==0
    disp('Saving IPs to text file ...');
end     
try
    tint=TSTART~=-1 & TEND~=-1;    
if length(findstr(l, 'tracegraph'))
    fclose(fid);
    return;        
elseif length(findstr(l, 'mixed12'))
    fclose(fid);
    fid=fopen(plik);
    l=fgets(fid);
    spacje=0;   
    while l~=-1
        event=l(1);
        if length(findstr(l,'[')) %if wireless
            if l(2)==32 & (event=='r' | event=='s' | event=='f' | event=='D')
                sp=findstr(l,32); % searching for a space
                if length(sp)>15
                    if tint
                        t=str2double(l((sp(1)+1):(sp(2)-1)));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end                
                    spacje=0;
                    if sp(4)~=(sp(5)-1) % if there are 2 spaces between columns c4 and c5
                        sp=[1,sp]; spacje=1;
                    end                
                    if length(findstr(l,'/'))==0 %cut only hop from, hop to, fwd dest
                        if l(sp(14)+1)=='['
                            dodaj_ip(l((sp(14)+2):(sp(15)-1)),l((sp(15)+1):(sp(16)-1)));
                            fwd=l((sp(17)+1):(sp(18)-2));
                            if length(fwd)>FWDLENGTH
                                dodaj_ip(fwd,fwd);
                            end
                        else
                            dodaj_ip(l((sp(15)+2):(sp(16)-1)),l((sp(16)+1):(sp(17)-1)));
                            fwd=l((sp(18)+1):(sp(19)-2));
                            if length(fwd)>FWDLENGTH
                                dodaj_ip(fwd,fwd);
                            end
                        end
                    end
                end
            end
        elseif l(2)==32 & (event=='r' | event=='+' | event=='-' | event=='d') %wired
            sp=findstr(l,32); % searching for a space
            lsp=length(sp);
            if lsp==11 | lsp==15            
                if tint
                    t=str2double(l((sp(1)+1):(sp(2)-1)));
                    if t<TSTART
                        continue;
                    end    
                    if t>TEND
                        break;
                    end                    
                end                
                dodaj_ip(l((sp(8)+1):(sp(9)-1)), l((sp(9)+1):(sp(10)-1)));
            end
        end
        l=fgets(fid);
    end
    fclose(fid);
    zapisz_ip(plik);
elseif length(findstr(l, 'mixed13'))
    fclose(fid);
    fid=fopen(plik);
    l=fgets(fid);
    while l~=-1
        %event, time, CN, AGT_RTR_IFQ_MAC, ID, type, size, ON, hopf, hopto, fwd_node, seq#
        event=l(1);
        if l(2)==32 & (event=='s' | event=='r' | event=='f' | event=='d') & length(findstr(l, '-Is'))
            if tint
                t=str2double(wytnij3(l,'-t',3,32));
                if t<TSTART
                    continue;
                end    
                if t>TEND
                    break;
                end                    
            end                            
            dodaj_ip(wytnij3(l,'-Is',4,32), wytnij3(l,'-Id',4,32));
            fwd=wytnij3(l,'-Hd',4,32);
            if length(fwd)>FWDLENGTH
                dodaj_ip(fwd,fwd);
            end
        elseif l(2)==32 & (event=='+' | event=='r' | event=='-' | event=='d') %wired
            sp=findstr(l,32); % searching for a space
            lsp=length(sp);
            if lsp==11 | lsp==15
                if tint
                    t=str2double(l((sp(1)+1):(sp(2)-1)));
                    if t<TSTART
                        continue;
                    end    
                    if t>TEND
                        break;
                    end                    
                end
                dodaj_ip(l((sp(8)+1):(sp(9)-1)), l((sp(9)+1):(sp(10)-1)));
            end    
        end   
        l=fgets(fid);
    end
    fclose(fid); 
    zapisz_ip(plik);
else    %other formats
    if AUTOFORMAT==0
        while l(1)~='r' & l~=-1
            l=fgets(fid);
            if (l(1)=='+' | l(1)=='-') & l(2)==32
                break;
            end
        end     
    end    
    fclose(fid);
    if length(findstr(l,'-t')) % new trace
        fid=fopen(plik);
        l=fgets(fid);
        while l~=-1
            %event, time, CN, AGT_RTR_IFQ_MAC, ID, type, size, ON, hopf, hopto, fwd_node, seq#
            if l(2)==32 & (l(1)=='s' | l(1)=='r' | l(1)=='f' | l(1)=='d') & length(findstr(l, '-Is'))
                if tint
                    t=str2double(wytnij3(l,'-t',3,32));
                    if t<TSTART
                        continue;
                    end    
                    if t>TEND
                        break;
                    end                    
                end 
                dodaj_ip(wytnij3(l,'-Is',4,32), wytnij3(l,'-Id',4,32));
                fwd=wytnij3(l,'-Hd',4,32);
                if length(fwd)>FWDLENGTH
                    dodaj_ip(fwd,fwd);
                end
            end   
            l=fgets(fid);
        end
        fclose(fid);
        zapisz_ip(plik);
    elseif length(findstr(l,' '))==11 | length(findstr(l,' '))==15 %wired
        fid=fopen(plik);
        l=fgets(fid);
        while l~=-1
            %event, time, CN, AGT_RTR_IFQ_MAC, ID, type, size, ON, hopf, hopto, fwd_node, seq#
            if l(2)==32 & (l(1)=='+' | l(1)=='r' | l(1)=='-' | l(1)=='d')
                sp=findstr(l,32); % searching for a space
                lsp=length(sp);
                if lsp==11 | lsp==15
                    if tint
                        t=str2double(l((sp(1)+1):(sp(2)-1)));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end                    
                    dodaj_ip(l((sp(8)+1):(sp(9)-1)), l((sp(9)+1):(sp(10)-1)));
                end    
            end   
            l=fgets(fid);
        end
        fclose(fid);
        zapisz_ip(plik);
    else %old wireless
        fid=fopen(plik);
        l=fgets(fid);
        spacje=0;
        if TSTART==-1 & TEND==-1
            t=0;
        end
        while l~=-1
            event=l(1);
            if l(2)==32 & (event=='r' | event=='s' | event=='f' | event=='D')
                sp=findstr(l,32); % searching for a space
                if length(sp)>15
                    if tint
                        t=str2double(l((sp(1)+1):(sp(2)-1)));
                        if t<TSTART
                            continue;
                        end    
                        if t>TEND
                            break;
                        end                    
                    end                            
                    spacje=0;
                    if sp(4)~=(sp(5)-1) % if there are 2 spaces between columns c4 and c5
                        sp=[1,sp]; spacje=1;
                    end
                    if length(findstr(l,'/'))==0 % cut only hop from, hop to, fwd dest
                        if l(sp(14)+1)=='['
                            dodaj_ip(l((sp(14)+2):(sp(15)-1)),l((sp(15)+1):(sp(16)-1)));
                            fwd=l((sp(17)+1):(sp(18)-2));
                            if length(fwd)>FWDLENGTH
                                dodaj_ip(fwd,fwd);
                            end
                        else
                            dodaj_ip(l((sp(15)+2):(sp(16)-1)),l((sp(16)+1):(sp(17)-1)));
                            fwd=l((sp(18)+1):(sp(19)-2));
                            if length(fwd)>FWDLENGTH
                                dodaj_ip(fwd,fwd);
                            end
                        end                
                    end
                end
            end    
            l=fgets(fid);
        end
        fclose(fid);
        zapisz_ip(plik);
    end
end
catch
    disp(lasterr);
    bledy(7);
end

%---------------------------------------
function dodaj_ip(hf, ht)
% appends IP hf, ht to the table tab_ip of size roz
global tab_ip tiprow tab_ip_size

if tiprow>=tab_ip_size
    emptyip=cellfun('isempty',tab_ip);
    tab_ip=tab_ip(~emptyip);
    tab_ip=unique(tab_ip);
    tiprow=length(tab_ip)+1;
    tab_ip=[tab_ip; cell(tab_ip_size-tiprow+1,1)];
end    
tab_ip{tiprow}=hf;
tab_ip{tiprow+1}=ht;
tiprow=tiprow+2;

%----------------------------------
function zapisz_ip(plik)
% saves IP table to a file plik
global tab_ip TSTART TEND

if TSTART==-1 & TEND==-1
    plik=strcat(plik,'.ip');
elseif TSTART~=-1 & TEND~=-1
    plik=[plik,'-ST_',num2str(TSTART),' ET_',num2str(TEND),'.ip'];
end
fidw=fopen(plik,'wt');
emptyip=cellfun('isempty',tab_ip);
tab_ip=tab_ip(~emptyip);
tab_ip=unique(tab_ip);
tab_ip=sort(tab_ip');
for i=1:length(tab_ip)
    fprintf(fidw, '%s', [tab_ip{i},10]);
end
fclose(fidw);
disp(['IPs have been saved in ', plik,'.']);

%-----------------------------
function s=wytnij3(l,x,lx,stop)
% trgraph
% to cut data after -x w traceformat=3
% stop character - space (32) or dot (46)

poz=findstr(l,x)+lx;
pozk=poz;
while l(pozk)~=stop
    pozk=pozk+1;
end    
s=l(poz:pozk-1);