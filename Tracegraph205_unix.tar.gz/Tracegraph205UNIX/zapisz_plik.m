function zapisz_plik(h, eventdata, handles, varargin)
%trgraph
%saves trace file in .mat format
global C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 C12 C13 
global LNOD PAKIETY TRACEFORMAT pole MAC PLIKINT FID PAKROZ rozpak

if isempty(varargin)
    [plik, katalog]=uiputfile('*.mat', 'Choose a mat file to save');
    if plik~=0
        try
            save([katalog,plik],'C1','C2','C3','C4','C5','C6','C7','C8','C9','C10','C11','C12','C13', ...
                'LNOD','PAKIETY','TRACEFORMAT','pole','MAC','PLIKINT','FID','PAKROZ','rozpak');
        catch
            bledy(8);
        end
    end    
else
    try
        global plik katalog

        if isempty(findstr(plik,'.mat'))
            kropa=findstr(plik,'.');
            p=[plik(1:(kropa(end)-1)),'.mat'];
            save([katalog,p],'C1','C2','C3','C4','C5','C6','C7','C8','C9','C10','C11','C12','C13', ...
                'LNOD','PAKIETY','TRACEFORMAT','pole','MAC','PLIKINT','FID','PAKROZ','rozpak');
        end
    catch
        bledy(8);
    end
end