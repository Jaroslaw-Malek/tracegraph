function varargout = suma_bajt_odb_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C6 C10 C12 C13 AKTWEZ TRACEFORMAT MAC NET HIST DC fig

thandles=guihandles(fig);
HIST=0;
NET=2; % to include DC in the description
DC=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=typstart(handles, 0); % number of received packets
    if TRACEFORMAT==2 & MAC==0
        c13=['end'; C13(1:(end-1),:)];
        c1=['s'; C1(1:(end-1))];
        c4=[-1; C4(1:(end-1))];
        c12=[-1; C12(1:(end-1))];
        wsp=wsp & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
    end
    if strcmp(get(thandles.directcon, 'Checked'),'on')
        wsp=wsp & C1=='r';
    else
        wsp=wsp & C4==C10 & C1=='r';
    end
    if isempty(find(wsp))
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        x=C2(wsp);
        y=cumsum(C6(wsp));
        [hplot,x,y]=rysuj(x, y, handles);
        zapisz_wykres([x, y], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('receive event time [sec]','cumulative sum of received bytes', hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);