function linia=autoform(plik,katalog)
% trgraph
% automatically recognizes trace file format
global MAXLINIA HEX

% trace formats
linia=[];
wired=0; % wired
bez=0; % wireless
nowy=0; % new trace
heks=0; % hexadecimal node numbers
ip=0; % ip addresses
tg=0; % Trace graph format
koniec=0;
lkrop=5; % number of dots for IP
minip=1024; % minimum node number to take it as a part of IP address
try
    if isempty(katalog)
        fid=fopen(plik);
    else
        fid=fopen(strcat(katalog, plik));
    end    
    l=fgets(fid);
    i=1;
    while koniec==0 & l~=-1 & i<MAXLINIA
        if l(2)==32
            event=l(1);
            if event=='+' | event=='-' % wired
                wired=1;
                if length(findstr(l,'.'))>lkrop
                    ip=1;
                end    
                if (bez==1 | nowy==1) & heks==1 & ip==1 %ip==1 2.05
                    koniec=1;
                end
            elseif (event=='r' | event=='s' | event=='f' | event=='D') & length(findstr(l,'['))>1 %wireless
                bez=1;              
                if wired==1 & heks==1 & ip==1 %ip==1 2.05
                    koniec=1;
                end
                sp=findstr(l, 32); % search for a space
                if sp(4)~=(sp(5)-1) % if there are 2 spaces between columns c4 i c5
                    sp=[1,sp];
                end            
                if heks==0                
                    nr=l((sp(11)+1):(sp(12)-1)); % number to check for hex
                    if length(findstr(nr,'a')) | length(findstr(nr,'b')) | length(findstr(nr,'c')) | length(findstr(nr,'d')) | ...
                            length(findstr(nr,'e')) | length(findstr(nr,'f')) % is hex
                        heks=1;
                        HEX=1;
                    end
                end    
                if ip==0 & (length(findstr(l,'/'))==0 | length(sp)>15)
                    sp1=findstr(l,':'); % node nr:port nr
                    if isempty(sp1)==0
                        if l(sp(14)+1)~='['
                            sp=[sp(1:13),sp(15:end)];
                        end
                        sn=str2double(l((sp(14)+2):(sp1(1)-1))); % send node
                        rn=str2double(l((sp(15)+1):(sp1(2)-1))); % receive node
                        if sn>minip | rn>minip
                            ip=1;
                        end
                    elseif length(findstr(l,'.'))>3
                        ip=1;                    
                    end    
                end                    
            elseif length(findstr(l,'-t')) & length(findstr(l, '-Is')) %new trace
                if (event=='r' | event=='s' | event=='f' | event=='d')
                    nowy=1;
                    if wired==1 & heks==1 & ip==1 %ip==1 2.05
                        koniec=1;
                    end
                    if heks==0
                        nr=wytnij1(l,'-Ms',4,32);
                        if length(findstr(nr,'a')) | length(findstr(nr,'b')) | length(findstr(nr,'c')) | length(findstr(nr,'d')) | ...
                                length(findstr(nr,'e')) | length(findstr(nr,'f')) % is hex
                            heks=1;
                            HEX=1;
                        end
                    end
                    if ip==0                    
                        if length(findstr(wytnij1(l,'-Is',4,32),'.'))>2 | length(findstr(wytnij1(l,'-Id',4,32),'.'))>2
                            ip=1;
                        else    
                            sn=str2double(wytnij1(l,'-Is',4,46));
                            rn=str2double(wytnij1(l,'-Id',4,46));
                            if sn>minip | rn>minip
                                ip=1;
                            end
                        end    
                    end                    
                end    
            elseif wired==0 & (event=='d' | event=='r') % wired
                sp=length(findstr(l,32));            
                if sp==11 | sp==15
                    kr=length(findstr(l,'.'));
                    if kr>1
                        wired=1;
                        if kr>lkrop
                            ip=1;
                        end    
                        if (bez==1 | nowy==1) & heks==1 & ip==1 %ip==1 2.05
                            koniec=1;
                        end                
                    end    
                end   
            elseif length(findstr(l,'.'))==1 & length(findstr(l,'_'))==0 % Trace graph format
                if wired==0 & bez==0 & nowy==0 & (event=='r' | event=='s' | event=='f' | event=='d')
                    tg=1;
                    if length(findstr(l,'.'))>lkrop
                        ip=1;
                    end
                    if heks==0                
                        sp=findstr(l, 32); % search for a space
                        sp=sp(end:-1:1);
                        nr=[l((sp(3)+1):(sp(2)-1)), l((sp(5)+1):(sp(4)-1))]; % number to check for hex
                        if length(findstr(nr,'a')) | length(findstr(nr,'b')) | length(findstr(nr,'c')) | length(findstr(nr,'d')) | ...
                                length(findstr(nr,'e')) | length(findstr(nr,'f')) % is hex
                            heks=1;
                            HEX=1;
                        end
                    end      
                    if heks==1
                        koniec=1;
                    end    
                end    
            end
        end
        l=fgets(fid);        
        i=i+1;
    end
    fclose(fid);
    if i>=MAXLINIA
        disp(['Maximum number of lines (',num2str(MAXLINIA),') to recognize trace format has been processed!']);
    end    
    if wired==1 & bez==1
        linia='mixed12 ';
        disp('wired-wireless format detected');
    elseif wired==1 & nowy==1
        linia='mixed13 ';
        disp('wired-new trace format detected');
    elseif wired==1
        linia=char(zeros(1,11)+32);
        disp('wired format detected');
    elseif bez==1
        linia='wireless ';
        disp('wireless format detected');
    elseif nowy==1
        linia='-t ';
        disp('new trace format detected');
    elseif tg==1
        linia='tracegraph ';
        disp('Trace graph format detected');
    end
    if ip==1
        linia=[linia, 'ip'];
        disp('IP addresses detected. Conversion to nodes numbers needed (see help).');
    end
    if heks==1
        linia=[linia, 'hex'];
        disp('Hexadecimal nodes numbers detected');
    end    
catch
    disp(lasterr);
    bledy(16);
    linia=[];
end    

function s=wytnij1(l,x,lx,stop)
% trgraph
% cuts data after -x if traceformat=3
% stop char - space (32) or dot (46)

poz=findstr(l,x)+lx;
pozk=poz;
while l(pozk)~=stop
    pozk=pozk+1;
end    
s=l(poz-1:pozk-1);