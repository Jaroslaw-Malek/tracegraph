function varargout = procnet_hist(h, eventdata, handles, varargin)
% trgraph
global NUMDELINT NET HIST HISTINTERVALS

if (strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0) | strcmp(get(handles.usehistint, 'Checked'), 'off')
    HIST=1;
    NET=1; % whole network
    czyscosie;
    [czy, opis]=czyopis('processing time', h, eventdata, handles);
    if czy==0
        [opoz,wnr,id]=procnetwsp(handles,0);
        mind=min(opoz);
        maxd=max(opoz);
        if isempty(opoz)
            hplot=wykrespusty(handles);
            zapisz_wykres(0, opis, handles);
            HIST=2; % empty graph
        elseif mind==maxd
            [hplot,mind,lopoz]=rysuj(mind, length(opoz), handles);
            zapisz_wykres([mind, lopoz], opis, handles);
        else
            if strcmp(get(handles.usehistint, 'Checked'), 'on') & isempty(HISTINTERVALS)==0% uses intervals
                x=HISTINTERVALS;
                y=histc(opoz,x);
                y=y';            
            else            
                krok=(maxd-mind)/NUMDELINT;
                start=mind;
                y=zeros(1, NUMDELINT);
                for i=1:NUMDELINT
                    if i==NUMDELINT
                        y(i)=length(opoz(opoz>=start));
                    else
                        y(i)=length(opoz(opoz>=start & opoz<(start+krok)));
                    end
                    start=start+krok;
                end
                x=mind:krok:(maxd-krok);
            end
            [hplot,x,y]=rysuj(x', y', handles);
            zapisz_wykres([x,y], opis, handles);
        end
        plot_info(opis, eventdata, hplot, handles);
        xylabel('processing time [sec]','processing times frequency distribution', hplot, handles);
    end
end
zapisz_wykres_jpg(opis,handles);