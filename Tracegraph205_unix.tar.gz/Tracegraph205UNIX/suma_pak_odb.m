function varargout = suma_pak_odb(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C6 AKTWEZ NET HIST DC

HIST=0;
NET=0;
DC=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=C2(C4==AKTWEZ & C1=='r' & typstart(handles, 'pakr')); % time of receiving packets
    if isempty(wsp)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=1:length(wsp);
        [hplot,wsp,l]=rysuj(wsp, l', handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('receive event time [sec]',['cumulative sum of numbers of received packets at node ', num2str(AKTWEZ)], hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);