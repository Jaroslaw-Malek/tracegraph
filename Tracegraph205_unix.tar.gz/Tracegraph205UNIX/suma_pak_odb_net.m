function varargout = suma_pak_odb_net(h, eventdata, handles, varargin)
% trgraph
global C1 C2 C4 C10 C12 C13 AKTWEZ TRACEFORMAT MAC NET HIST DC fig

thandles=guihandles(fig);
HIST=0;
NET=2; % to include DC in the description
DC=1;
czyscosie;
[czy, opis]=czyopis('time', h, eventdata, handles);
if czy==0
    wsp=typstart(handles, 0); % number of received packets
    if TRACEFORMAT==2 & MAC==0
        c13=['end'; C13(1:(end-1),:)];
        c1=['s'; C1(1:(end-1))];
        c4=[-1; C4(1:(end-1))];
        c12=[-1; C12(1:(end-1))];
        wsp=wsp & C13(:,1)=='R' | (C13(:,1)=='A' & ~(c1=='r' & c4==C4 & c12==C12 & c13(:,1)=='R'));
    end
    if strcmp(get(thandles.directcon, 'Checked'),'on')
        wsp=C2(wsp & C1=='r');
    else
        wsp=C2(wsp & C4==C10 & C1=='r');
    end
    if isempty(wsp)
        hplot=wykrespusty(handles);
        zapisz_wykres(0, opis, handles);
    else    
        l=1:length(wsp);
        [hplot,wsp,l]=rysuj(wsp, l', handles);
        zapisz_wykres([wsp, l], opis, handles);
    end
    plot_info(opis, eventdata, hplot, handles);
	xylabel('receive event time [sec]','cumulative sum of numbers of received packets', hplot, handles);
end
DC=0;
zapisz_wykres_jpg(opis,handles);