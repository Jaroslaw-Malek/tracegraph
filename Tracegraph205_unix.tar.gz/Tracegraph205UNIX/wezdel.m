function [opoz, id, stime, rtime, roz]=wezdel(handles,par)
% trgraph
% calculates delays between 2 nodes
global C1 C2 C3 C4 C6 C9 C10 C12 AKTWEZ STARTWEZ PREC fig DELAY PODZIAL CHECK

thandles=guihandles(fig);
DELAY=1;
opoz=[];
id=[];
stime=[];
rtime=[];
if CHECK(2)==1 & AKTWEZ~=STARTWEZ
    typ=typstart(handles,0); % packet type
    wsp=typstart(handles,4);
    stime=C2(wsp); % send events times
    id=C12(wsp); % sent packet IDs
    if par==2
        roz=C6(wsp);
    else
        roz=[];
    end    
    l=length(id);
    if l
        tr=[];
        if strcmp(get(thandles.directcon, 'Checked'),'on')
            r=C1=='r' & C4==STARTWEZ & C3==AKTWEZ & typ;
        else
            r=C1=='r' & C4==STARTWEZ & C9==AKTWEZ & C10==STARTWEZ & typ;
        end
        c2=C2(r);
        c12=C12(r);
        if CHECK(8)==0
            opoz=zeros(l,1);
            dl=length(c2);
            if dl~=0
                n=ceil(dl/PODZIAL); dl=floor(dl/n);
                poz=1;
                for p=1:n
                    if p==n
                        wsp=poz:length(c2);
                    else
                        wsp=poz:(poz+dl-1);
                    end
                    c2p=c2(wsp);
                    c12p=c12(wsp);        
                    for i=1:l
                        tr=c2p(c12p==id(i)); % receive time for packet id(i)
                        if isempty(tr)==0 & opoz(i)==0
                            opoz(i)=tr(1);        
                        end
                    end
                    poz=poz+dl;
                end
                clear c2 c12 c2p c12p wsp;
                if par==1
                    rtime=opoz;
                else
                    rtime=[];
                end    
                opoz=opoz-stime;
                opnr=find(opoz>0);
                opoz=opoz(opnr);
                id=id(opnr);
                if par==1
                    stime=stime(opnr);
                    rtime=rtime(opnr);
                elseif par==2
                    roz=roz(opnr);
                end            
            end
        else
            try           
                [c12,i]=sort(c12);
                c2=c2(i);
                if id(1)>0
                    c12=c12-id(1);
                end    
                if length(stime)>=c12(end)
                    stime=stime(c12+1);
                    opoz=c2-stime;
                    id=id(c12+1);
                    typ=find(typ(c12+1));
                    opoz=opoz(typ);
                    stime=stime(typ);
                    c2=c2(typ);
                    id=id(typ);
                    if par==2
                        roz=roz(typ);
                    end    
                else
                    l=length(c2);
                    stime=stime(1:l);
                    opoz=c2-stime;
                    id=id(1:l);
                    typ=find(typ(1:l));
                    opoz=opoz(typ);
                    stime=stime(typ);
                    c2=c2(typ);
                    id=id(typ);
                    if par==2
                        roz=roz(typ);
                    end    
                end
                if par==1
                    rtime=c2;
                else
                    rtime=[];
                end
            catch
                bledy(11);
                opoz=[];
                id=[];
                stime=[];
                rtime=[];
                roz=[];
                return;
            end
        end
    end
end       