function varargout = nagraj_tiff(h, eventdata, handles, varargin)
% trgraph
% saves figure to a tiff file

[plik, katalog]=uiputfile('*.tif', 'Choose file name to save');
if plik~=0
   osieoff(handles,0);
   print('-dtiff', [katalog,plik]);
   osieoff(handles,1);
end 