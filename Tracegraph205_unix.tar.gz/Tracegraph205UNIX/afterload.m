function afterload(handles, sciezka)
% trgraph
% shows data after loading a trace file
global C2 C13 BANDI LNOD AKTWEZ STARTWEZ WYKRESY COL WYKRESTAG WYKRESLAB 
global PREC LICZBAWYK CHECK CZY3D pole TSTART TEND PLIKINT TILNUM PKTLIST
global sfig ghandles gfig FID TRACEFORMAT FLOWID TRACELEVEL rozpak SELSIZE PLIKSKRYPT

shandles=guihandles(sfig);
s=min(C2);
e=max(C2);
if TSTART==-1 & TEND==-1
    TSTART=s;
    TEND=e;
end
if PLIKINT==1 | strcmp(get(handles.timeint, 'Checked'), 'on') % if trace file has been loaded with time interval
    if TSTART<s
        TSTART=s;
    end
    if TEND>e
        TEND=e;
    end
end
PKTLIST=strrep(pole,'-','');
PKTLIST=strrep(PKTLIST,'+','');
SELSIZE=0;
AKTWEZ=0;
STARTWEZ=AKTWEZ;
WYKRESY=cell(1);
WYKRESTAG=cell(1);
WYKRESLAB=cell(1);
COL=1;
LICZBAWYK=0;
CZY3D=0;
biez=gcf;
figure(gfig);
axes(ghandles.axes1);
cla reset;
if CHECK(3)
    hold on;
end    
zoom on;
figure(biez);
BANDI=1; % time interval length 1 second
set(handles.listapak, 'Value', 1);
set(handles.listapak, 'String', pole);
set(handles.sentpkt, 'Value', 1);
set(handles.sentpkt, 'String', PKTLIST);
set(handles.ackpkt, 'Value', 1);
set(handles.ackpkt, 'String', PKTLIST);
set(handles.psize, 'Value', 1);
set(handles.psize, 'String', rozpak);
set(shandles.lnod, 'String', num2str(LNOD));
set(handles.nazwa_pliku, 'String', sciezka);
set(handles.nazwa_pliku, 'Visible', 'on');
set(gfig, 'Name', ['Graphs  ', sciezka]);
set(sfig, 'Name', ['Network information  ', sciezka]);
set(handles.zamien, 'Enable', 'on');
set(handles.aktwez, 'Enable', 'on');
set(handles.aktwez, 'String', num2str(AKTWEZ));
set(ghandles.wykresy2d, 'Enable', 'on');
set(ghandles.wykresy3d, 'Enable', 'on');
set(ghandles.histograms, 'Enable', 'on');
set(shandles.info, 'Enable', 'on');
set(handles.startwez, 'Enable', 'on');
set(handles.startwez, 'String', num2str(STARTWEZ));
set(handles.listapak, 'Enable', 'on');
set(handles.sentpkt, 'Enable', 'on');
set(handles.ackpkt, 'Enable', 'on');
set(handles.psize, 'Enable', 'on');
set(handles.selsizebut, 'Enable', 'on');
set(handles.nodran, 'String', ['0-', num2str(LNOD-1)]);
set(handles.nodran, 'Visible', 'on');
set(handles.bandinterval, 'Enable', 'on');
set(handles.bandinterval, 'String', num2str(BANDI,TILNUM));
set(handles.zapisz, 'Enable', 'on');
set(handles.czasmin, 'String', ['>=',num2str(s,PREC)]);
set(handles.czasmax, 'String', ['<=',num2str(e,PREC)]);
set(handles.starttime, 'String', num2str(TSTART,PREC));
set(handles.endtime, 'String', num2str(TEND,PREC));
tl=[];
TRACELEVEL=cell(1);
set(handles.stracelevel, 'Value', 1);
set(handles.dtracelevel, 'Value', 1);
if TRACEFORMAT==1
    FLOWID=min(FID);
    set(handles.fidtxt, 'String', [num2str(FLOWID), '-', num2str(max(FID))]);
    set(handles.flowid, 'Enable', 'on');
    set(handles.flowid, 'String', num2str(FLOWID));
    set(handles.stracelevel, 'String', ' ');
    set(handles.dtracelevel, 'String', ' ');
    set(handles.stracelevel, 'Enable', 'off');
    set(handles.dtracelevel, 'Enable', 'off');
else
    set(handles.flowid, 'Enable', 'off');
    set(handles.flowid, 'String', '');
    set(handles.fidtxt, 'String', 'N/A');
    set(handles.stracelevel, 'Enable', 'on');
    set(handles.dtracelevel, 'Enable', 'on');
    ind=1;
    if length(find(C13(:,1)=='A'))
        TRACELEVEL{1}='AGT';
        tl='AGT';
        ind=2;
    end
    if length(find(C13(:,1)=='R'))
        if isempty(tl)
            tl='RTR';
            TRACELEVEL{1}='RTR';
        else
            ind=3;
            TRACELEVEL{2}='RTR';
            tl=[tl,'|RTR'];
        end
    end    
    if length(find(C13(:,1)=='M'))
        if isempty(tl)
            TRACELEVEL{1}='MAC';
            tl='MAC';
        else
            TRACELEVEL{ind}='MAC';
            tl=[tl,'|MAC'];
        end
    end
    set(handles.stracelevel, 'String', tl);
    set(handles.dtracelevel, 'String', tl);
    FID=-1;
    FLOWID=-1;
end
set(handles.fidtxt, 'Visible', 'on');
check_info(handles, 2);
if isempty(PLIKSKRYPT)==0
    skrypt(handles);
end