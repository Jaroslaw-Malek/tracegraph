function s=send_mac_0
% trgraph
% returns sent events 's' for wireless format, MAC=0
global C1 C7 C13

s=C1=='s';
isagt=sum(s & C13(:,1)=='A');
if isagt~=sum(s)
    s=s & C13(:,1)=='R';
end