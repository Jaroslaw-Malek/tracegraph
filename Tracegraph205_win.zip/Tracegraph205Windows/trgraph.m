function varargout = trgraph(varargin)
%Copyright (c) 2001-2005 by Jaroslaw Malek
%All rights reserved.
%Author contact: wido@o2.pl, jaroslaw_malek@interia.pl
%Using version 2.03 or higher of Trace graph and its documentation
%is allowed for commercial and non-commercial purposes provided that
%licensee has a valid Trace graph license and the above copyright
%notice and this permission appear in all copies and any materials
%related to Trace graph. Trace graph (compiled and source code versions) 
%cannot be distributed, sold, copied or modified without
%Jaroslaw Malek's permission. Any modification of the Trace graph 
%source code has to be sent to Jaroslaw Malek. The source code 
%and compiled version can be used only by one user (the licensee). 
%The licensee can use it only on one computer. If Trace graph 
%(source code or compiled version) needs to be used on more computers 
%or by more users, separate copies (licences) of Trace graph source 
%code has to be bought for each user and computer.
%Trace graph is provided with no warranty. Jaroslaw Malek is not
%responsible for any events and results caused by using Trace graph.
% TRGRAPH Application M-file for trgraph.fig
%    FIG = TRGRAPH launch trgraph GUI.
%    TRGRAPH('callback_name', ...) invoke the named callback.

global C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 C12 C13 C14 C15 C16 % trace file columns
global TMAX % simulation time
global LNOD % number of nodes
global AKTWEZ % current node
global PAKIETY % packet types
global STARTWEZ % other node
global CHECK % if the following option are on: packet types, other node, overlay graphs, 
             % auto refresh graph, auto refresh information, count packets IDs only once, packet sizes, turbo mode
global WYKRESY % graph table
global WYKRESTAG % tags table for graphs
global KOLORY % colors table for graphs
global COL % current color
global WYKRESLAB % graph names table
global LICZBAWYK % number of graphs
global OPLIK % if open a trace file from the command line
global pole % packets list
global TSTART % start time
global TEND % end time
global PLIKINT % if the trace file has been loaded with time interval [TSTART, TEND]
global PREC % num2str precision
global NUMDELINT % number of intervals for histograms
global IDCOUNT % if count packets IDs only once should be included in graphs description
global DC % if direct connection should be included in graphs description
global CZY3D % if the plotted graph is 3D
global FWDLENGTH % lenght of string containing node number to which packets are forwarded (wireless -Hd)
global TILNUM % precision to show TIL (Time Interval Length)
global HISTINTERVALS % histograms intervals
global fig %main window reference
global sfig %simulation information window reference
global gfig %graphs window reference
global shandles % simulation information window references
global ghandles % graphs window references
global DCONLY % equals 1 if only direct connection otherwise 0
global FID % flow id column
global FLOWID % current flow id
global DELAY % equals 1 if delay is calculated
global SELSIZE % equals 1 if all packet sizes are selected select all, 0 if all packet sizes are unselected
global PLIKSKRYPT % Trace graph script file name
global PODZIAL % vector split size during file loading, during calculations of delays, processing times, etc.
global RTT % equals 1 if Round Trip Time is calculated, otherwise 0

OPLIK=0;
FWDLENGTH=4;

try
if length(varargin) == 1 & ischar(varargin{1})
        OPLIK=1;
        if isempty(findstr(varargin{1}, '.mat'))
            TSTART=-1;
            TEND=-1;
        end
        PLIKINT=0;
elseif length(varargin) == 2
    if strcmp(varargin{2}, '-ip')
        if isempty(findstr(varargin{1}, '.mat'))
            TSTART=-1;
            TEND=-1;
            konfig('trgraph.cfg');
            podaj_ip(varargin{1}); % saves IPs to file
        else
            bledy(3);
        end
    else
        bledy(6);
    end
    return;
elseif length(varargin) == 3
    if strcmp(varargin{2}, '-script')
        PLIKSKRYPT=varargin{3};
        OPLIK=1;
        if isempty(findstr(varargin{1}, '.mat'))
            TSTART=-1;
            TEND=-1;
        end
        PLIKINT=0;
    elseif isempty(findstr(varargin{1}, '.mat'))
        OPLIK=1;
        TSTART=str2num(varargin{2});
        TEND=str2num(varargin{3});
        if isempty(TSTART) | isempty(TEND)
            bledy(5);
            return;
        elseif TSTART >= TEND
            bledy(2);
            return;
        elseif TSTART<0
            bledy(4);
            return;
        end
        PLIKINT=1;
    else
        bledy(3);
        return;
    end    
elseif length(varargin) == 4
    if strcmp(varargin{2}, '-ip')
        if isempty(findstr(varargin{1}, '.mat'))
            TSTART=str2num(varargin{3});
            TEND=str2num(varargin{4});
            if isempty(TSTART) | isempty(TEND)
                bledy(5);
                return;
            elseif TSTART >= TEND
                bledy(2);
                return;
            elseif TSTART<0
                bledy(4);
                return;
            end
            konfig('trgraph.cfg');
            podaj_ip(varargin{1}); % saves IPs to file
            return;
        else
            bledy(3);
            return;
        end
    end    
elseif nargin == 0 | PLIKINT ~= 1
    PLIKINT=0;
end
catch
    bledy(6);
end

if nargin == 0 | OPLIK == 1 % LAUNCH GUI
    
    try
        fid=fopen('license.txt','r');
        l=fgets(fid);
        while l~=-1
            l=l(l~=10);
            disp(l);
            l=fgets(fid);        
        end
        fclose(fid);
    catch
        fclose('all');
        bledy(17);
        return;
    end    
    konfig('trgraph.cfg');
    sfig = openfig('stats.fig','new');
    shandles = guihandles(sfig);
	guidata(sfig, shandles);
    gfig = openfig('graphs.fig','new');
    ghandles = guihandles(gfig);
	guidata(gfig, ghandles);
    fig = openfig(mfilename,'new');    
    % Use system color scheme for figure:    % Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);
    NUMDELINT=10;
    set(ghandles.wykresy2d, 'Enable', 'off');
    set(ghandles.wykresy3d, 'Enable', 'off');
    set(ghandles.histograms, 'Enable', 'off');
    set(ghandles.figure1, 'Color', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.info, 'Enable', 'off');
    set(handles.zapisz, 'Enable', 'off');
    set(handles.numdelint, 'String', num2str(NUMDELINT));
    set(handles.figure1, 'Color', get(0,'defaultUicontrolBackgroundColor'));
    set(handles.figure1, 'Name', 'Trace graph 2.05');
    %set(shandles.autozminf, 'Checked', 'on');
    set(shandles.frame1, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));    
    set(shandles.figure1, 'Color', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame2, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame3, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame4, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame5, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame6, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame7, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame8, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame9, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(shandles.frame10, 'BackgroundColor', get(0,'defaultUicontrolBackgroundColor'));
    set(ghandles.kopiuj_do_clip, 'Accelerator', 'c');
    %set(ghandles.kopiuj_do_clip, 'Enable', 'off');
    CHECK=[0,0,0,0,0,0,0,0];
    HISTINTERVALS=[];
    WYKRESY=cell(1);
    WYKRESTAG=cell(1);
    WYKRESLAB=cell(1);
    LICZBAWYK=0;
    SELSIZE=0;
    DELAY=0;
    RTT=0;
    CZY3D=0;
    FID=-1;
    KOLORY='bmcrgky';
    IDCOUNT=0;
    DC=0;
    DCONLY=0;
    TILNUM=6;
    if nargout > 0
		varargout{1} = fig;
	end
    if OPLIK == 1
        otworz_plik(fig, varargin{1}, handles, varargin);
    end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
        bledy(6);
        disp(lasterr);
	end

end

% --------------------------------------------------------------------
function varargout = edit4_Callback(h, eventdata, handles, varargin)
% edit current node number
global AKTWEZ LNOD CZY3D PREC

x=str2num(get(h, 'String'));
x=round(x);
if x>-1 & x<LNOD
    AKTWEZ=x;
    check_info(handles, 0);
    if CZY3D==0
        odrysuj(h, handles, varargin);
    end
else
    set(h,'String',num2str(AKTWEZ,PREC));
end

% --------------------------------------------------------------------
function varargout = startwez_Callback(h, eventdata, handles, varargin)
% edit other node number
global STARTWEZ LNOD CHECK CZY3D PREC

x=str2num(get(h, 'String'));
x=round(x);
if x>-1 & x<LNOD
    STARTWEZ=x;
    if CHECK(2)==1
        check_info(handles, 0);
    end
    if CZY3D==0
        odrysuj(h, handles, varargin);    
    end
else
    set(h,'String',num2str(STARTWEZ,PREC));
end

% --------------------------------------------------------------------
function varargout = pakcheck_Callback(h, eventdata, handles, varargin)
% checks packet type
global CHECK

if CHECK(1)==0
    CHECK(1)=1;
elseif CHECK(1)==1    
    CHECK(1)=0;
end
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = startcheck_Callback(h, eventdata, handles, varargin)
% checks other node
global CHECK CZY3D

if CHECK(2)==0
    CHECK(2)=1;
elseif CHECK(2)==1 
    if strcmp(get(handles.directcon, 'Checked'),'on')
        set(handles.directcon, 'Checked','off');
    end
    CHECK(2)=0;
end
check_info(handles, 0);
if CZY3D==0
    odrysuj(h, handles, varargin);
end

% --------------------------------------------------------------------
function varargout = listapak_Callback(h, eventdata, handles, varargin)
% chooses a packet from the list
global PAKIETY pole CHECK

pak=char(PAKIETY{get(handles.listapak, 'Value')});
if isempty(findstr(pole, ['-',pak]))
    pole=strrep(pole,['+',pak],['-',pak]);
else
    pole=strrep(pole,['-',pak],['+',pak]);    
end
set(handles.listapak, 'String', pole);
if CHECK(1)==1
    check_info(handles, 2);
    odrysuj(h, handles, varargin);
end    

% --------------------------------------------------------------------
function varargout = bandinterval_Callback(h, eventdata, handles, varargin)
% TIL for throughput graphs
global BANDI C2 CZY3D LICZBAWYK WYKRESTAG PREC

x=str2num(get(h, 'String'));
if x>0 & x<max(C2)
    BANDI=x;
    if CZY3D==0 & LICZBAWYK==1 & strcmp(WYKRESTAG{1}, 'bandwidth')
        odrysuj(h, handles, varargin);
    end
else
    set(h,'String',num2str(BANDI,PREC));
end

% --------------------------------------------------------------------
function varargout = timeint(h, eventdata, handles, varargin)
% time interval [TSTART, TEND]

if strcmp(get(h, 'Checked'),'off')
    set(h, 'Checked', 'on');
elseif strcmp(get(h, 'Checked'),'on')
    set(h, 'Checked','off');
end
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = starttime_Callback(h, eventdata, handles, varargin)
% edit TSTART
global TSTART TEND C2 PREC

x=str2num(get(h, 'String'));
if isempty(C2) | (x>=0 & x<TEND)
    TSTART=x;
    if strcmp(get(handles.timeint, 'Checked'),'on')
        check_info(handles, 2);
        odrysuj(h, handles, varargin);
    end
else
    set(h, 'String',num2str(TSTART,PREC));
end

% --------------------------------------------------------------------
function varargout = endtime_Callback(h, eventdata, handles, varargin)
% edit TEND
global TSTART TEND C2 PREC

x=str2num(get(h, 'String'));
if isempty(C2) | (x>=0 & x>TSTART)
    TEND=x;
    if strcmp(get(handles.timeint, 'Checked'),'on')
        check_info(handles, 2);
        odrysuj(h, handles, varargin);
    end
else
    set(h, 'String',num2str(TEND,PREC));
end

% --------------------------------------------------------------------
function varargout = directcon(h, eventdata, handles, varargin)
% Direct Connection option
global CHECK

if CHECK(2)==1 % other node
    if strcmp(get(h, 'Checked'),'off')
        set(h, 'Checked', 'on');
    elseif strcmp(get(h, 'Checked'),'on')
        set(h, 'Checked','off');
    end
    check_info(handles, 0);
    odrysuj(h, handles, varargin);
end

% --------------------------------------------------------------------
function varargout = numdelint_Callback(h, eventdata, handles, varargin)
% number of intervals for histograms
global NUMDELINT PREC

x=str2num(get(h, 'String'));
if x>0
    NUMDELINT=floor(x);
    odrysuj(h, handles, varargin);
else
    set(h, 'String',num2str(NUMDELINT));
end

% --------------------------------------------------------------------
function varargout = liczpakietraz(h, eventdata, handles, varargin)
% Count Packets IDs only once
global CHECK

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
    CHECK(6)=1;
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
    CHECK(6)=0;
end
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = histintervals_Callback(h, eventdata, handles, varargin)
% histograms intervals
global HISTINTERVALS gfig

p=str2num(get(handles.histintervals, 'String'));
if isempty(p)==0
    if length(find(p<0))==0 & sum(sort(p)==p)==length(p)
        HISTINTERVALS=p;
        ghandles=guihandles(gfig);
        if strcmp(get(ghandles.usehistint, 'Checked'), 'on')
            odrysuj(h, handles, varargin);
        end
    end
end

% --------------------------------------------------------------------
function varargout = figure1_CloseRequestFcn(h, eventdata, handles, varargin)
global sfig gfig fig

delete(sfig);
delete(gfig);
delete(fig);

% --------------------------------------------------------------------
function varargout = flowid_Callback(h, eventdata, handles, varargin)
% flow id
global FID FLOWID

fid=str2num(get(h, 'String'));
if fid>=min(FID) & fid<=max(FID)
    FLOWID=fid;
    if strcmp(get(handles.flowidoption, 'Checked'),'on')
        check_info(handles, 2);
        odrysuj(h, handles, varargin);
    end
else
    set(h, 'String',num2str(FLOWID)); 
end

% --------------------------------------------------------------------
function varargout = flowidoption(h, eventdata, handles, varargin)
% check flow id option

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
end
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = stracelevel_Callback(h, eventdata, handles, varargin)
% changes trace level for source nodes
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = dtracelevel_Callback(h, eventdata, handles, varargin)
% changes trace level for destination nodes
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = psizetxt_Callback(h, eventdata, handles, varargin)
% packet size option
global CHECK

if CHECK(7)==0
    CHECK(7)=1;
elseif CHECK(7)==1    
    CHECK(7)=0;
end
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = psize_Callback(h, eventdata, handles, varargin)
% choosing packet size from the list
global PAKROZ rozpak CHECK

pak=num2str(PAKROZ(get(handles.psize, 'Value')));
if isempty(findstr(rozpak, ['-',pak]))
    rozpak=strrep(rozpak,['+',pak],['-',pak]);
else
    rozpak=strrep(rozpak,['-',pak],['+',pak]);    
end
set(handles.psize, 'String', rozpak);
if CHECK(7)==1
    check_info(handles, 2);
    odrysuj(h, handles, varargin);
end    

% --------------------------------------------------------------------
function varargout = selsizebut_Callback(h, eventdata, handles, varargin)
% selects/unselects packet sizes
global rozpak SELSIZE

if SELSIZE==0 %select all
    rozpak=strrep(rozpak,'-','+');
    SELSIZE=1;
else %deselect all
    rozpak=strrep(rozpak,'+','-');    
    SELSIZE=0;
end
set(handles.psize, 'String', rozpak);
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = turbo_Callback(h, eventdata, handles, varargin)
% turbo mode
global CHECK

if strcmp(get(h, 'Checked'), 'off')
    set(h, 'Checked', 'on');
    CHECK(8)=1;
elseif strcmp(get(h, 'Checked'), 'on')
    set(h, 'Checked', 'off');
    CHECK(8)=0;
end
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = zamien_Callback(h, eventdata, handles, varargin)
% changes current node number to other node number and vice versa
global AKTWEZ STARTWEZ

temp=AKTWEZ;
AKTWEZ=STARTWEZ;
STARTWEZ=temp;
set(handles.aktwez,'String',num2str(AKTWEZ));
set(handles.startwez,'String',num2str(STARTWEZ));
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = ackpkt_Callback(h, eventdata, handles, varargin)
%sent packet type for RTT
check_info(handles, 2);
odrysuj(h, handles, varargin);

% --------------------------------------------------------------------
function varargout = sentpkt_Callback(h, eventdata, handles, varargin)
%received packet type for RTT
check_info(handles, 2);
odrysuj(h, handles, varargin);